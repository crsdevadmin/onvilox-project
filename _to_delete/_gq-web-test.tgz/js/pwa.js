// PWA: Service Worker registration + push subscription + install prompt
(function() {
  if (!('serviceWorker' in navigator)) return;

  const VAPID_KEY = 'BP2E-Ogveb92wrIjjciORv_jDJO82jut8m3QSJM_UrwJbVDJCFZdDzSuQZvahxpu_0gw7B-E_bJktm7VKd-qTEo';

  // Register service worker
  // Auto-update: when a newly deployed version takes control, reload the page once so
  // every device always runs the latest code — no manual cache clearing required.
  // Guarded against reload loops; skips the very first install (no existing controller).
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (window.__swReloaded) return;
    if (!navigator.serviceWorker.controller) return;
    window.__swReloaded = true;
    window.location.reload();
  });

  navigator.serviceWorker.register('/sw.js', { scope: '/' }).then(reg => {
    window._swReg = reg;
    // Detect a new deployed version: when one activates while a page is already
    // controlled, reload to pick it up. Also poll for updates periodically and when
    // the tab regains focus, so long-lived store/admin tabs don't stay on old code.
    reg.addEventListener('updatefound', () => {
      const nw = reg.installing;
      if (nw) nw.addEventListener('statechange', () => {
        if (nw.state === 'activated' && navigator.serviceWorker.controller && !window.__swReloaded) {
          window.__swReloaded = true;
          window.location.reload();
        }
      });
    });
    try { reg.update(); } catch (e) {}
    setInterval(() => { try { reg.update(); } catch (e) {} }, 60000);
    window.addEventListener('focus', () => { try { reg.update(); } catch (e) {} });
    // Wait for SW to be active before subscribing
    if (reg.active) {
      _subscribePush(reg);
    } else {
      (reg.installing || reg.waiting).addEventListener('statechange', function() {
        if (this.state === 'activated') _subscribePush(reg);
      });
      reg.addEventListener('updatefound', () => {
        reg.installing.addEventListener('statechange', function() {
          if (this.state === 'activated') _subscribePush(reg);
        });
      });
      // Also try after short delay as fallback
      setTimeout(() => _subscribePush(reg), 2000);
    }
  }).catch(e => console.warn('SW registration failed:', e));

  // PWA install prompt
  let _deferredPrompt = null;
  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    _deferredPrompt = e;
    _showInstallBanner();
  });

  function _isInstalled() {
    return window.navigator.standalone === true ||
      (window.matchMedia && matchMedia('(display-mode: standalone)').matches);
  }
  function _ss(k, v) { try { if (v === undefined) return sessionStorage.getItem(k); sessionStorage.setItem(k, v); } catch (e) { return null; } }

  function _showInstallBanner() {
    if (_isInstalled() || _ss('pwa_install_later')) return;
    if (document.getElementById('pwaInstallBanner')) return;
    if (!document.body) { document.addEventListener('DOMContentLoaded', _showInstallBanner); return; }
    const banner = document.createElement('div');
    banner.id = 'pwaInstallBanner';
    banner.style.cssText = 'position:fixed;bottom:0;left:0;right:0;background:#0e2247;color:#fff;padding:12px 20px;display:flex;align-items:center;justify-content:space-between;z-index:9999;font-size:14px;box-shadow:0 -2px 12px rgba(0,0,0,0.3);';
    banner.innerHTML = `
      <div style="display:flex;align-items:center;gap:12px;">
        <span style="font-size:24px;">📲</span>
        <div>
          <div style="font-weight:700;">Install Gquence App</div>
          <div style="font-size:12px;opacity:0.8;">Add to your home screen for quick access</div>
        </div>
      </div>
      <div style="display:flex;gap:10px;">
        <button onclick="_installPWA()" style="background:#10b981;color:#fff;border:none;border-radius:6px;padding:8px 16px;font-weight:700;cursor:pointer;font-size:13px;">Install</button>
        <button onclick="_dismissInstall()" style="background:transparent;color:#fff;border:1px solid rgba(255,255,255,0.4);border-radius:6px;padding:8px 12px;cursor:pointer;font-size:13px;">Not now</button>
      </div>`;
    document.body.appendChild(banner);
  }

  window._installPWA = function() {
    if (!_deferredPrompt) return;
    _deferredPrompt.prompt();
    _deferredPrompt.userChoice.then(r => {
      if (r.outcome !== 'accepted') _ss('pwa_install_later', '1');
      _deferredPrompt = null;
      const b = document.getElementById('pwaInstallBanner');
      if (b) b.remove();
    });
  };

  window._dismissInstall = function() {
    _ss('pwa_install_later', '1');   // ask again on the next visit
    const b = document.getElementById('pwaInstallBanner');
    if (b) b.remove();
  };

  // iPhone / iPad: Safari never fires 'beforeinstallprompt', so the Install
  // banner above never appears there. Show the manual steps instead
  // (Share → Add to Home Screen). Installing is also what enables push
  // notifications on iOS (16.4+).
  (function iosInstallHint() {
    const ua = navigator.userAgent || '';
    const isIOS = /iPad|iPhone|iPod/.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    const standalone = window.navigator.standalone === true || (window.matchMedia && matchMedia('(display-mode: standalone)').matches);
    if (!isIOS || standalone) return;
    try { if (sessionStorage.getItem('pwa_ios_hint_later')) return; } catch (e) {}
    const show = () => {
      if (document.getElementById('pwaInstallBanner')) return;
      const banner = document.createElement('div');
      banner.id = 'pwaInstallBanner';
      banner.style.cssText = 'position:fixed;bottom:0;left:0;right:0;background:#0e2247;color:#fff;padding:12px 16px calc(12px + env(safe-area-inset-bottom));display:flex;align-items:center;justify-content:space-between;gap:10px;z-index:9999;font-size:14px;box-shadow:0 -2px 12px rgba(0,0,0,0.3);';
      banner.innerHTML = `
        <div style="display:flex;align-items:center;gap:12px;">
          <span style="font-size:24px;">📲</span>
          <div>
            <div style="font-weight:700;">Install the Gquence app</div>
            <div style="font-size:12px;opacity:0.85;">In Safari tap <b>Share</b> <span style="display:inline-block;border:1px solid rgba(255,255,255,.5);border-radius:4px;padding:0 4px;">⬆︎</span> then <b>Add to Home Screen</b>. Needed for notifications.</div>
          </div>
        </div>
        <button id="pwaIosClose" style="background:transparent;color:#fff;border:1px solid rgba(255,255,255,0.4);border-radius:6px;padding:8px 12px;cursor:pointer;font-size:13px;white-space:nowrap;">Got it</button>`;
      document.body.appendChild(banner);
      document.getElementById('pwaIosClose').onclick = () => {
        try { sessionStorage.setItem('pwa_ios_hint_later', '1'); } catch (e) {}
        banner.remove();
      };
    };
    if (document.body) show(); else document.addEventListener('DOMContentLoaded', show);
  })();

  // Subscribe to push notifications — roles that receive workflow alerts:
  // store (production requests), doctors (price approvals) and admins (every
  // status change in the flow).
  const PUSH_ROLES = ['STORE', 'STORE_APPROVER', 'DOCTOR', 'ADMIN', 'SUPER_ADMIN'];
  function _subscribePush(reg) {
    if (!('PushManager' in window)) return;
    const u = (typeof auth !== 'undefined') ? auth.getCurrentUser() : null;
    if (!u || !PUSH_ROLES.includes(u.role)) return;
    Notification.requestPermission().then(permission => {
      if (permission !== 'granted') return;
      reg.pushManager.getSubscription().then(existing => {
        if (existing) return _saveSub(existing, u);
        return reg.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: _urlBase64ToUint8Array(VAPID_KEY)
        }).then(sub => _saveSub(sub, u));
      }).catch(e => console.warn('Push subscribe failed:', e));
    });
  }

  function _saveSub(sub, u) {
    const apiBase = (typeof CONFIG !== 'undefined' && CONFIG.API_BASE_URL) ? CONFIG.API_BASE_URL : '';
    fetch(apiBase + '/api/push/subscribe', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': u.token ? 'Bearer ' + u.token : '' },
      body: JSON.stringify({ subscription: sub })
    }).catch(() => {});
  }

  function _urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    const raw = window.atob(base64);
    return Uint8Array.from([...raw].map(c => c.charCodeAt(0)));
  }
})();
