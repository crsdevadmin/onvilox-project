(function(global){
  const SESSION_KEY = 'session';

  function getCurrentUser(){
    return db.getTable(SESSION_KEY, null);
  }

  function setCurrentUser(u){
    return db.setTable(SESSION_KEY, u);
  }

  function logout(){
    if (db.removeTable) db.removeTable(SESSION_KEY);
    else { try { localStorage.removeItem(db.key(SESSION_KEY)); } catch (e) {} }
    window.location.href = '/login';
  }

  // async: calls server API, returns { ok, route } or { ok:false, error }
  async function login(username, password){
    const apiBase = (typeof CONFIG !== 'undefined' && CONFIG.API_BASE_URL) ? CONFIG.API_BASE_URL : '';
    try {
      const res = await fetch(apiBase + '/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: username, password })
      });

      if (res.ok) {
        const data = await res.json();
        // Store session with JWT token for subsequent API calls
        setCurrentUser({
          id: data.user.id,
          role: data.user.role,
          name: data.user.name,
          hospital_name: data.user.hospital_name,
          storeId: data.user.storeId || null,
          username: username,
          token: data.token,
          // Modules this user may use ([{code,name,role}]) — null if the server
          // could not tell, in which case the legacy role routing applies.
          modules: Array.isArray(data.modules) ? data.modules : null
        });
        // If the browser refused to keep the session, every page would send the
        // user straight back here. Say so instead of looping silently.
        if (!getCurrentUser()) {
          return { ok: false, error: 'This browser is blocking storage, so the login cannot be kept. '
            + 'On iPad/iPhone: turn off Private Browsing, or Settings → Safari → Clear History and Website Data, then try again.' };
        }
        return { ok: true, route: data.landing || routeForRole(data.user.role) };
      }

      const errData = await res.json().catch(() => ({}));
      return { ok: false, error: errData.error || 'Invalid credentials' };

    } catch (e) {
      // Network error — fall back to localStorage users for offline/dev mode
      console.warn('Server login failed, trying localStorage fallback:', e.message);
      const users = db.getTable('users', []);
      const user = users.find(u => (u.username || u.email || '').toLowerCase() === (username || '').toLowerCase() && u.password === password);
      if (!user) return { ok: false, error: 'Server unavailable and no local user found' };
      setCurrentUser({ id: user.id, role: user.role, username: user.username || user.email, name: user.name, storeId: user.storeId || null, token: null });
      return { ok: true, route: routeForRole(user.role) };
    }
  }

  function routeForRole(role){
    if(role === 'SUPER_ADMIN' || role === 'ADMIN') return '/admin';
    if(role === 'DOCTOR' || role === 'ASSISTANT') return '/dashboard';
    if(role === 'STORE' || role === 'STORE_APPROVER') return '/store';
    if(role === 'COORDINATOR') return '/coordinator';
    return '/login';
  }

  // Oncology pages are the legacy module. A user whose Oncology access was
  // removed (known from the session saved at login) is sent to the module
  // shell instead of a page whose API calls would all be refused.
  function hasModule(code){
    const u = getCurrentUser();
    if(!u || !Array.isArray(u.modules)) return true;   // older session: unknown → allow
    if(u.role === 'ADMIN' || u.role === 'SUPER_ADMIN') return true;
    return u.modules.some(m => m.code === code);
  }

  function requireRole(allowedRoles){
    const u = getCurrentUser();
    if(!u){ window.location.href='/login'; return; }
    if(!hasModule('onco')){ window.location.href = '/app/'; return; }
    if(Array.isArray(allowedRoles) && allowedRoles.length){
      if(!allowedRoles.includes(u.role)){
        window.location.href = routeForRole(u.role);
        return;
      }
    }
  }

  global.auth = { getCurrentUser, login, logout, requireRole, routeForRole, hasModule };
})(window);
