// manufacturing.js — API-backed manufacturing job service with localStorage fallback

(function(global){

  const _cache = { jobs: null };

  function _apiBase() {
    return (typeof CONFIG !== 'undefined' && CONFIG.API_BASE_URL) ? CONFIG.API_BASE_URL : '';
  }

  function _headers() {
    const u = (typeof auth !== 'undefined') ? auth.getCurrentUser() : null;
    const h = { 'Content-Type': 'application/json' };
    if (u && u.token) h['Authorization'] = 'Bearer ' + u.token;
    return h;
  }

  async function initJobs() {
    try {
      const res = await fetch(_apiBase() + '/api/manufacturing-jobs', { headers: _headers() });
      if (res.ok) {
        const rows = await res.json();
        applyServerJobs(rows);
      }
    } catch(e) {
      console.warn('initJobs: server unreachable, using localStorage');
      _cache.jobs = db.getTable('manufacturing_jobs', []);
    }
  }

  // Replace the in-memory job cache with freshly-fetched server rows.
  // Used by initJobs and by the dashboard's live poll so render() always
  // reflects server truth (e.g. an approval made on another device).
  function applyServerJobs(rows) {
    _cache.jobs = (rows || []).map(_mapRow);
    db.setTable('manufacturing_jobs', _cache.jobs);
    return _cache.jobs;
  }
  function _mapRow(r) {
    return ({
      id: r.id,
      patientId: r.patient_id || r.patientId,
      storeId: r.store_id || r.storeId,
      doctorId: r.doctor_id || r.doctorId,
      status: r.status,
      history: r.history || [],
      batchNo: r.batch_no || r.batchNo || null,
      mfgDate: r.mfg_date || r.mfgDate || null,
      expDate: r.exp_date || r.expDate || null,
      // Pricing — the server only sends the fields this role may see.
      priceStatus:  r.price_status || null,
      storePrice:   r.store_price  != null ? Number(r.store_price)  : null,
      markupPct:    r.markup_pct   != null ? Number(r.markup_pct)   : null,
      basePrice:    r.base_price   != null ? Number(r.base_price)   : null,
      doctorPct:    r.doctor_pct   != null ? Number(r.doctor_pct)   : null,
      doctorAmount: r.doctor_amount!= null ? Number(r.doctor_amount): null,
      finalPrice:   r.final_price  != null ? Number(r.final_price)  : null,
      defaultMarkupPct: r.default_markup_pct != null ? Number(r.default_markup_pct) : null,
      priceNote:    r.price_note || null,
      storePricedAt:   r.store_priced_at || null,
      priceApprovedAt: r.price_approved_at || null,
      createdAt: r.created_at || r.createdAt,
      updatedAt: r.updated_at || r.updatedAt,
      // Withdrawal travels with the job so the store can never be the last
      // place still working on a patient who has left the programme.
      patientWithdrawn: !!(r.patientWithdrawn || r.patient_withdrawn),
      withdrawnReason: r.withdrawnReason || r.withdrawn_reason || null,
      withdrawnLabel: r.withdrawnLabel || r.withdrawn_label || null,
      withdrawnAt: r.withdrawnAt || r.withdrawn_at || null
    });
  }

  // Assign/refresh batch number + manufacturing & expiry dates for a job.
  // Returns { ok, batchNo, mfgDate, expDate } or { ok:false, error }.
  async function assignBatch(jobId, mfgDate) {
    try {
      const res = await fetch(_apiBase() + '/api/manufacturing-jobs/' + jobId + '/batch', {
        method: 'POST', headers: _headers(), body: JSON.stringify({ mfgDate })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return { ok: false, error: data.error || 'Server error assigning batch' };
      // update local cache
      const jobs = getJobs();
      const job = jobs.find(j => j.id == jobId); // == handles number/string mismatch from DB
      if (job) { job.batchNo = data.batch_no; job.mfgDate = data.mfg_date; job.expDate = data.exp_date; }
      return { ok: true, batchNo: data.batch_no, mfgDate: data.mfg_date, expDate: data.exp_date };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  }

  function getJobs() {
    return _cache.jobs || db.getTable('manufacturing_jobs', []);
  }

  async function createJob({patientId, storeId, doctorId}) {
    const job = {
      id: db.uid('job'),
      patientId, storeId, doctorId,
      status: 'APPROVED',
      history: [{ status: 'APPROVED', at: new Date().toISOString() }],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (_cache.jobs) _cache.jobs.push(job);
    else { const jobs = db.getTable('manufacturing_jobs', []); jobs.push(job); db.setTable('manufacturing_jobs', jobs); }
    db.setTable('manufacturing_jobs', getJobs());

    try {
      const res = await fetch(_apiBase() + '/api/manufacturing-jobs', {
        method: 'POST', headers: _headers(), body: JSON.stringify(job)
      });
      if (!res.ok) {
        const err = await res.text().catch(() => '');
        console.error('createJob: server rejected job (status ' + res.status + '). It will not reach the store. ', err);
      }
    } catch(e) { console.warn('createJob: server unreachable'); }

    return job;
  }

  async function updateJobStatus(jobId, status, actor) {
    const jobs = getJobs();
    const job = jobs.find(j => j.id == jobId); // == handles number/string mismatch from DB
    if (!job) return null;
    job.status = status;
    job.updatedAt = new Date().toISOString();
    job.history = job.history || [];
    const entry = { status, at: job.updatedAt };
    if (actor) {
      if (actor.by) entry.by = actor.by;
      if (actor.role) entry.role = actor.role;
      if (actor.action) entry.action = actor.action;
    }
    job.history.push(entry);

    if (_cache.jobs) _cache.jobs = jobs;
    db.setTable('manufacturing_jobs', jobs);

    try {
      const res = await fetch(_apiBase() + '/api/manufacturing-jobs/' + jobId, {
        method: 'PUT', headers: _headers(),
        body: JSON.stringify({ status, history: job.history })
      });
      if (!res.ok) {
        // The server refused (e.g. price not approved yet) — undo the optimistic
        // change by reloading server truth, and say why.
        const data = await res.json().catch(() => ({}));
        await initJobs();
        if (typeof alert === 'function') alert(data.error || ('Could not update the job (' + res.status + ').'));
        return null;
      }
    } catch(e) { console.warn('updateJobStatus: server unreachable'); }

    return job;
  }

  // Store records that a dispatched product reached the patient.
  // delivery = { date: 'YYYY-MM-DD', receivedBy, note }. Returns { ok, error }.
  async function markDelivered(jobId, delivery, actor) {
    const jobs = getJobs();
    const job = jobs.find(j => j.id == jobId);
    if (!job) return { ok: false, error: 'Job not found' };
    const history = (job.history || []).concat([{
      status: 'DELIVERED', at: new Date().toISOString(), action: 'deliver',
      by: actor && actor.by, role: actor && actor.role
    }]);
    try {
      const res = await fetch(_apiBase() + '/api/manufacturing-jobs/' + encodeURIComponent(jobId), {
        method: 'PUT', headers: _headers(),
        body: JSON.stringify({ status: 'DELIVERED', history, delivery: delivery || {} })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return { ok: false, error: data.error || ('Server error (' + res.status + ')') };
      const i = jobs.findIndex(j => j.id == jobId);
      if (i >= 0) {
        const prev = jobs[i];
        jobs[i] = Object.assign(_mapRow(data), {
          patientWithdrawn: prev.patientWithdrawn || false, withdrawnReason: prev.withdrawnReason || null,
          withdrawnLabel: prev.withdrawnLabel || null, withdrawnAt: prev.withdrawnAt || null });
        _cache.jobs = jobs; db.setTable('manufacturing_jobs', jobs);
      }
      return { ok: true };
    } catch (e) { return { ok: false, error: e.message }; }
  }
  // Delivery details recorded on the job (latest DELIVERED history entry), or null.
  function deliveryInfo(j) {
    const h = (j && j.history) || [];
    for (let i = h.length - 1; i >= 0; i--) if ((h[i].status || '').toUpperCase() === 'DELIVERED') return h[i];
    return null;
  }

  // ── Pricing ────────────────────────────────────────────────────────────────
  // Store price → +platform markup → doctor % → final price (label MRP).
  // Each call returns { ok, job } or { ok:false, error } and refreshes the cache.
  async function _pricePost(jobId, path, body) {
    try {
      const res = await fetch(_apiBase() + '/api/manufacturing-jobs/' + encodeURIComponent(jobId) + '/' + path, {
        method: 'POST', headers: _headers(), body: JSON.stringify(body || {})
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return { ok: false, error: data.error || ('Server error (' + res.status + ')') };
      const jobs = getJobs();
      const i = jobs.findIndex(j => j.id == jobId);
      const prev = i >= 0 ? jobs[i] : {};
      // Keep withdrawal flags the list endpoint adds; take everything else from the server.
      const mapped = Object.assign(_mapRow(data), {
        patientWithdrawn: prev.patientWithdrawn || false, withdrawnReason: prev.withdrawnReason || null,
        withdrawnLabel: prev.withdrawnLabel || null, withdrawnAt: prev.withdrawnAt || null });
      if (i >= 0) jobs[i] = mapped; else jobs.push(mapped);
      _cache.jobs = jobs;
      db.setTable('manufacturing_jobs', jobs);
      return { ok: true, job: mapped };
    } catch (e) { return { ok: false, error: e.message }; }
  }
  function setStorePrice(jobId, price)   { return _pricePost(jobId, 'store-price',  { price }); }
  function approvePrice(jobId, finalPrice){ return _pricePost(jobId, 'doctor-price', { finalPrice }); }
  function adminMarkup(jobId, markupPct) { return _pricePost(jobId, 'admin-markup', { markupPct }); }
  function queryPrice(jobId, note)       { return _pricePost(jobId, 'price-query',  { note }); }
  // A job may enter production only once its price is approved.
  function isPriced(j) { return !!j && (j.priceStatus || j.price_status) === 'APPROVED'; }
  function priceLabel(j) {
    const s = j && (j.priceStatus || j.price_status);
    if (s === 'APPROVED')        return 'Price approved';
    if (s === 'AWAITING_ADMIN')  return 'Price with admin';
    if (s === 'AWAITING_DOCTOR') return 'Price with doctor';
    if (s === 'QUERIED')         return 'Price sent back';
    return 'Price needed';
  }

  function getJobsForStore(storeId) {
    if (!storeId) return [];
    const sid = String(storeId);
    return getJobs().filter(j => {
      const jid = j.storeId || j.store_id;
      return jid != null && String(jid) === sid;
    });
  }

  function getJobByPatient(patientId) {
    return getJobs().find(j => (j.patientId || j.patient_id) === patientId) || null;
  }

  // ── Store approval workflow ────────────────────────────────────────────────
  // Two-step sign-off: the Store Manager REQUESTS a transition (job enters a
  // PENDING_* state); the Store Approver then APPROVES (advances) or REJECTS
  // (reverts to the prior state).
  const WORKFLOW = {
    // When a manager requests the next step, the job moves to this pending state.
    requestNext: {
      APPROVED:   'PENDING_PROCESSING',
      PROCESSING: 'PENDING_DISPATCH'
    },
    // What each pending state resolves to on approve / reject.
    pending: {
      PENDING_PROCESSING: { approve: 'PROCESSING',  reject: 'APPROVED',   label: 'Processing' },
      PENDING_DISPATCH:   { approve: 'DISPATCHED',  reject: 'PROCESSING', label: 'Dispatch' }
    },
    isPending: function(status){
      return !!WORKFLOW.pending[(status || '').toUpperCase()];
    },
    // The transition a manager can request from the current status (or null).
    requestFor: function(status){
      const s = (status || 'APPROVED').toUpperCase();
      const next = WORKFLOW.requestNext[s];
      if (!next) return null;
      return { next: next, label: WORKFLOW.pending[next].label };
    },
    // Human-friendly label for any status.
    statusLabel: function(status){
      const s = (status || 'APPROVED').toUpperCase();
      if (s === 'PENDING_PROCESSING') return 'Pending Processing Approval';
      if (s === 'PENDING_DISPATCH')   return 'Pending Dispatch Approval';
      return s.charAt(0) + s.slice(1).toLowerCase();
    },
    // CSS badge class (reuses existing .pending / .processing / etc.).
    badgeClass: function(status){
      const s = (status || 'APPROVED').toUpperCase();
      if (WORKFLOW.isPending(s)) return 'pending';
      return s.toLowerCase();
    }
  };

  global.manufacturingService = { initJobs, applyServerJobs, getJobs, createJob, updateJobStatus, assignBatch, getJobsForStore, getJobByPatient, WORKFLOW,
    setStorePrice, approvePrice, adminMarkup, queryPrice, isPriced, priceLabel, markDelivered, deliveryInfo };
})(window);
