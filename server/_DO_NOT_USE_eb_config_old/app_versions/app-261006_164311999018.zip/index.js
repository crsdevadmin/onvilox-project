const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
// Shared MUST screen — one implementation for the baseline and discharge ends,
// so the change between them is a real difference and not two formulas drifting.
const { computeMust, mustInputs, MUST_PATIENT_COLUMNS } = require('./must');
const ProteinPlans = require('../js/protein-plans');
require('dotenv').config();

// Push keys: prefer the environment. The hard-coded pair is kept only as a
// fallback so existing browser subscriptions keep working until the keys are
// rotated (set VAPID_PUBLIC_KEY / VAPID_PRIVATE_KEY; users then re-allow push).
const VAPID_PUBLIC  = process.env.VAPID_PUBLIC_KEY  || 'BP2E-Ogveb92wrIjjciORv_jDJO82jut8m3QSJM_UrwJbVDJCFZdDzSuQZvahxpu_0gw7B-E_bJktm7VKd-qTEo';
const VAPID_PRIVATE = process.env.VAPID_PRIVATE_KEY || 'of-_1IjWZ415k3XDDwbpbgtNDpm0d-Hcxkz1eCNfbk0';
const _pushSubs = {};
let webpush = null;
try {
  webpush = require('web-push');
  webpush.setVapidDetails('mailto:admin@gquence.com', VAPID_PUBLIC, VAPID_PRIVATE);
  console.log('web-push loaded OK');
} catch(e) {
  console.warn('web-push unavailable — push notifications disabled:', e.message);
}

const path = require('path');

// gzip every response. The app ships ~300 KB of HTML/CSS/JS per page load and the
// JSON payloads are large too; text compresses ~70%. Wrapped in try/catch so a
// missing module degrades to "uncompressed" rather than taking the server down.
let compression = null;
try { compression = require('compression'); }
catch(e) { console.warn('compression unavailable — responses will be sent uncompressed:', e.message); }

const app = express();
const corsOptions = {
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Claude-Context']
};
app.use(cors(corsOptions));
app.options('*', cors(corsOptions));
if (compression) app.use(compression());
app.use(express.json({ limit: '2mb' }));

// Serve frontend static files (HTML, JS, CSS) from the project root.
// HTML, the service worker, and app JS/CSS are served with no-cache so every
// deploy is picked up automatically — users never need to clear cache. (Static
// assets that rarely change, like images/fonts, may still be cached by the browser.)
// Never serve working files, decks, QA folders or personal documents from the
// project root — express.static would otherwise publish everything deployed.
const _PRIVATE_PATHS = /^\/(claude(%20| )outputs|_deck_qa|_hos_qa|_inv_qa|server|node_modules|web|app-dist|\.(?!well-known)[^/]*)(\/|$)|\.(md|pptx|pdf|mp4|bak[^/]*|ps1|py|sql|log|zip)$/i;
app.use((req, res, next) => {
  let p = req.path;
  try { p = decodeURIComponent(p); } catch (e) {}
  if (_PRIVATE_PATHS.test(p) || _PRIVATE_PATHS.test(req.path)) return res.status(404).send('Not found');
  next();
});

// Caching:
//  - HTML and the service worker: never cached, so a deploy shows up at once.
//  - JS / CSS: the browser revalidates every time (cheap 304 via ETag), but
//    Cloudflare may keep a copy for 2 minutes (s-maxage). That takes most of
//    the static-file traffic off this server — previously every page view sent
//    ~25 uncached requests here, which is what was timing out (Cloudflare 520/522).
//    After a deploy, new JS/CSS reaches everyone within 2 minutes.
//  - Images / fonts / icons: cached for a day.
app.use(express.static(path.join(__dirname, '..'), {
  etag: true,
  setHeaders: (res, filePath) => {
    if (/\.html$/i.test(filePath) || /sw\.js$/i.test(filePath)) {
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
    } else if (/\.(js|css)$/i.test(filePath)) {
      res.setHeader('Cache-Control', 'public, max-age=0, s-maxage=120, must-revalidate');
    } else if (/\.(png|jpe?g|gif|svg|webp|ico|woff2?|ttf)$/i.test(filePath)) {
      res.setHeader('Cache-Control', 'public, max-age=86400');
    }
  }
}));

// Database Connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
  // Default was 10 connections with no wait limit: when the dashboards' heavier
  // queries held them, a small INSERT (e.g. saving a plan) queued for 20–50 s
  // and Cloudflare gave up with a 520. More room, and fail fast instead of hanging.
  max: parseInt(process.env.PG_POOL_MAX, 10) || 20,
  connectionTimeoutMillis: 15000,
  idleTimeoutMillis: 30000
});

// Log any API request slower than 3 s, so slowness shows up in web.stdout.log
// with the endpoint that caused it instead of only as a 520 in the browser.
app.use('/api', (req, res, next) => {
  const t0 = Date.now();
  res.on('finish', () => {
    const ms = Date.now() - t0;
    if (ms > 3000) console.warn(`SLOW ${ms}ms ${req.method} ${req.originalUrl.split('?')[0]} → ${res.statusCode} `
      + `(db pool: ${pool.totalCount} open, ${pool.idleCount} idle, ${pool.waitingCount} waiting)`);
  });
  next();
});

// ── Weekly data completeness gate ───────────────────────────────────────────
// A weekly prescription is a clinical instruction to manufacture and dispense.
// The target engine will produce a confident-looking plan from weight alone,
// which means a week with every lab blank used to arrive in the doctor's queue
// looking identical to a fully worked-up one. These are the values a doctor
// needs in front of them to sign the week off; without them the prescription is
// still generated and still visible, but it cannot be approved.
//
// CRP is deliberately NOT here: it is not consumed by the target calculation.
const WEEKLY_REQUIRED_FIELDS = [
  { key: 'weight',     label: 'Weight (kg)' },
  { key: 'ecog',       label: 'ECOG' },
  { key: 'oralIntake', label: 'Oral Intake %' },
  { key: 'compliance', label: 'Supp Compliance %' },
  { key: 'albumin',    label: 'Albumin (g/dL)' },
  { key: 'glucose',    label: 'Blood Glucose (mg/dL)' },
  { key: 'creatinine', label: 'Creatinine (mg/dL)' },
  { key: 'urea',       label: 'Urea (mg/dL)' }
];

// ECOG 0, oral intake 0 and compliance 0 are all real, meaningful readings, so
// presence is tested against null/blank/NaN — never falsiness.
function missingWeeklyFields(data) {
  let d = data || {};
  if (typeof d === 'string') { try { d = JSON.parse(d); } catch (e) { d = {}; } }
  return WEEKLY_REQUIRED_FIELDS
    .filter(f => {
      const v = d[f.key];
      if (v === null || v === undefined || v === '') return true;
      return isNaN(parseFloat(v));
    })
    .map(f => f.label);
}

// Auth Middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.sendStatus(401);

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

// ── Platform core + clinical modules ────────────────────────────────────────
// Module access (Oncology / Fertility), the /api/access admin API, the Fertility
// module's API and the /app web shell. Registered BEFORE the legacy routes below
// so the Oncology access guard sits in front of all of them. See server/platform.js.
const { registerPlatform } = require('./platform');
// notify: phone/desktop push to user ids (notifyUsers is defined further down; hoisted).
const platform = registerPlatform(app, { pool, authenticateToken, notify: (ids, title, body, url) => notifyUsers(ids, title, body, url) });

// --- ROUTES ---

// Push notification helpers
app.get('/api/push/vapid-public-key', (req, res) => res.json({ key: VAPID_PUBLIC }));
app.post('/api/push/subscribe', authenticateToken, async (req, res) => {
  const { subscription } = req.body;
  if (!subscription) return res.status(400).json({ error: 'subscription required' });
  _pushSubs[req.user.id] = subscription;
  try {
    await pool.query(
      `INSERT INTO push_subscriptions (user_id, subscription, updated_at)
       VALUES ($1, $2, NOW())
       ON CONFLICT (user_id) DO UPDATE SET subscription=$2, updated_at=NOW()`,
      [req.user.id, JSON.stringify(subscription)]
    );
  } catch(e) { console.warn('push sub save:', e.message); }
  res.json({ ok: true });
});
// Send a push to a specific set of user IDs (one per active subscription).
async function notifyUsers(userIds, title, body, url) {
  if (!webpush || !userIds || !userIds.length) return;
  const payload = JSON.stringify({ title, body, url });
  for (const uid of userIds) {
    const sub = _pushSubs[uid];
    if (!sub) continue;
    try {
      await webpush.sendNotification(sub, payload);
    } catch(e) {
      await dropPushSubscription(uid, e);
    }
  }
}

// A push failure used to drop the subscription from the in-memory cache no
// matter what went wrong. That meant a single transient error — a network
// blip, a 5xx from the push service — permanently silenced that user's
// notifications until someone happened to restart the server, and nothing
// anywhere said so. The row stayed in push_subscriptions, so cache and table
// quietly disagreed.
//
// Only 404 and 410 mean the subscription is genuinely gone (the browser
// revoked it). Everything else is treated as temporary and left alone.
async function dropPushSubscription(uid, err) {
  const code = err && (err.statusCode || err.status);
  if (code !== 404 && code !== 410) {
    console.warn('push send failed for', uid, '— keeping subscription:', (err && err.message) || code);
    return false;
  }
  delete _pushSubs[uid];
  try {
    await pool.query('DELETE FROM push_subscriptions WHERE user_id=$1', [uid]);
    console.log('push: subscription for', uid, 'was revoked by the browser — removed');
  } catch(e) { console.warn('push sub delete:', e.message); }
  return true;
}

// Resolve the user IDs belonging to a store, optionally filtered by role.
async function storeUserIds(storeId, roles) {
  if (!storeId) return [];
  try {
    const r = roles && roles.length
      ? await pool.query('SELECT id FROM users WHERE store_id=$1 AND role = ANY($2)', [storeId, roles])
      : await pool.query('SELECT id FROM users WHERE store_id=$1', [storeId]);
    return r.rows.map(x => x.id);
  } catch(e) { console.warn('storeUserIds:', e.message); return []; }
}

// Notify only the users mapped to a given store (default: store roles).
async function notifyStore(storeId, title, body, url, roles) {
  const ids = await storeUserIds(storeId, roles || ['STORE', 'STORE_APPROVER']);
  return notifyUsers(ids, title, body, url);
}

// ── Admin activity feed ────────────────────────────────────────────────────
// Every status change in the patient → plan → price → production → dispatch
// flow is recorded here and pushed to all admins. The admin dashboard shows
// the feed (GET /api/admin/events); phones get a push notification.
async function adminUserIds() {
  try {
    const r = await pool.query("SELECT id FROM users WHERE role IN ('ADMIN','SUPER_ADMIN')");
    return r.rows.map(x => x.id);
  } catch (e) { return []; }
}
async function _nameOf(table, id) {
  if (!id) return null;
  try {
    const r = await pool.query(`SELECT name FROM ${table} WHERE id=$1`, [id]);
    return r.rows[0] ? r.rows[0].name : null;
  } catch (e) { return null; }
}
// evt: { type, title, body, patientId, jobId, user (req.user), url }
// Never throws — a failed notification must not fail the action itself.
async function recordEvent(evt) {
  try {
    const actorName = evt.user ? await _nameOf('users', evt.user.id) : null;
    const patientName = evt.patientName || (evt.patientId ? await _nameOf('patients', evt.patientId) : null);
    const body = String(evt.body || '')
      .replace(/\{patient\}/g, patientName || 'A patient')
      .replace(/\{actor\}/g, actorName || (evt.user && evt.user.role ? evt.user.role.toLowerCase().replace('_', ' ') : 'Someone'));
    await pool.query(
      `INSERT INTO activity_events (type, title, body, patient_id, job_id, actor_id, actor_role)
       VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [evt.type, evt.title, body, evt.patientId || null, evt.jobId || null,
       evt.user ? evt.user.id : null, evt.user ? evt.user.role : null]);
    const ids = (await adminUserIds()).filter(id => !evt.user || id !== evt.user.id);
    notifyUsers(ids, evt.title, body, evt.url || '/admin').catch(() => {});
  } catch (e) { console.warn('recordEvent:', e.message); }
}
function _stageLabel(s) {
  return ({ APPROVED: 'Approved', PENDING_PROCESSING: 'Processing requested', PROCESSING: 'Processing',
            PENDING_DISPATCH: 'Dispatch requested', DISPATCHED: 'Dispatched', DELIVERED: 'Delivered',
            CREATED: 'Created' })[String(s || '').toUpperCase()] || s;
}

// In-memory copy of the assistant → doctor map (loaded at startup, kept in
// step on every change) so request handlers can resolve ownership cheaply.
const _asstMap = {};
function _mappedDoctor(id) { return (id && _asstMap[id]) || null; }
// The map is cached in memory, but the database is the truth: with more than
// one server instance (or a mapping saved before a restart finished loading),
// the cache on the instance answering a request could be stale — an assistant
// who IS linked was then treated as unlinked. So refresh it from the database:
// for every assistant request (one indexed lookup), and fully once a minute.
async function _refreshAsstMap(assistantId) {
  if (assistantId) {
    const r = await pool.query('SELECT doctor_id FROM doctor_assistant_map WHERE assistant_id=$1 AND doctor_id IS NOT NULL LIMIT 1', [assistantId]);
    if (r.rows[0]) _asstMap[assistantId] = r.rows[0].doctor_id; else delete _asstMap[assistantId];
    return;
  }
  const r = await pool.query('SELECT assistant_id, doctor_id FROM doctor_assistant_map WHERE doctor_id IS NOT NULL');
  Object.keys(_asstMap).forEach(k => delete _asstMap[k]);
  r.rows.forEach(x => { _asstMap[x.assistant_id] = x.doctor_id; });
}
setInterval(() => { _refreshAsstMap().catch(() => {}); }, 60000);
app.use('/api', (req, res, next) => {
  const h = req.headers['authorization'] || '';
  const tok = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!tok) return next();
  let u = null;
  try { u = jwt.verify(tok, process.env.JWT_SECRET); } catch (e) { return next(); }
  if (!u || u.role !== 'ASSISTANT') return next();
  _refreshAsstMap(u.id).then(() => next(), () => next());
});
// The doctor a record created by this request belongs to.
function _ownerDoctorFor(req, requested) {
  const u = req.user || {};
  if (u.role === 'ASSISTANT') return _mappedDoctor(u.id) || _mappedDoctor(requested) || requested || u.id;
  if (u.role === 'DOCTOR') return _mappedDoctor(requested) || requested || u.id;
  // A record pointed at an assistant (older data) belongs to that assistant's doctor.
  return _mappedDoctor(requested) || requested || null;
}
// Move patients and drafts an assistant created (or that were pinned to the
// assistant) onto their doctor. Returns how many patients moved.
async function _reassignAssistantPatients(assistantId, doctorId) {
  const r = await pool.query(
    `UPDATE patients
        SET assigned_doctor_id = $2::text,
            full_data = jsonb_set(COALESCE(full_data,'{}'::jsonb), '{assignedDoctorId}', to_jsonb($2::text))
      WHERE assigned_doctor_id = $1::text
         OR full_data->>'assignedDoctorId' = $1::text
         OR ((assigned_doctor_id IS NULL OR assigned_doctor_id = '')
             AND (created_by_user_id = $1::text OR created_by_id = $1::text OR full_data->>'createdByUserId' = $1::text))`,
    [assistantId, doctorId]);
  await pool.query('UPDATE patient_drafts SET doctor_id=$2 WHERE doctor_id=$1', [assistantId, doctorId]).catch(() => {});
  if (r.rowCount) console.log(`assistant mapping: moved ${r.rowCount} patient(s) from ${assistantId} to doctor ${doctorId}`);
  return r.rowCount;
}
(async () => {
  try {
    await pool.query(`CREATE TABLE IF NOT EXISTS doctor_assistant_map (
      assistant_id TEXT PRIMARY KEY, doctor_id TEXT, updated_at TIMESTAMPTZ DEFAULT NOW())`);
    await pool.query('ALTER TABLE doctor_assistant_map ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW()').catch(() => {});
    await pool.query('CREATE UNIQUE INDEX IF NOT EXISTS uq_doctor_assistant_map_asst ON doctor_assistant_map(assistant_id)').catch(e =>
      console.warn('doctor_assistant_map unique index:', e.message));
    const m = await pool.query('SELECT assistant_id, doctor_id FROM doctor_assistant_map WHERE doctor_id IS NOT NULL');
    console.log('doctor_assistant_map rows:', JSON.stringify(m.rows));
    for (const row of m.rows) {
      _asstMap[row.assistant_id] = row.doctor_id;
      await _reassignAssistantPatients(row.assistant_id, row.doctor_id).catch(e => console.warn('reassign:', e.message));
    }
    console.log(`doctor_assistant_map ready (${m.rowCount} mapping(s))`);
  } catch (e) { console.error('doctor_assistant_map migration:', e.message); }
})();

app.get('/api/admin/events', authenticateToken, async (req, res) => {
  const role = req.user && req.user.role;
  if (role !== 'ADMIN' && role !== 'SUPER_ADMIN') return res.status(403).json({ error: 'Admin only' });
  const limit = Math.min(200, Math.max(1, parseInt(req.query.limit, 10) || 50));
  const since = parseInt(req.query.since, 10) || 0;
  try {
    const r = await pool.query(
      `SELECT e.*, u.name AS actor_name, p.name AS patient_name
         FROM activity_events e
         LEFT JOIN users u ON u.id = e.actor_id
         LEFT JOIN patients p ON p.id = e.patient_id
        WHERE e.id > $1 ORDER BY e.id DESC LIMIT $2`, [since, limit]);
    res.json(r.rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Who is signed in — shown in the top bar so staff always know whose
// workspace they are in (an assistant sees which doctor they work for).
app.get('/api/me', authenticateToken, async (req, res) => {
  try {
    const u = (await pool.query('SELECT id, name, email, role, store_id FROM users WHERE id=$1', [req.user.id])).rows[0];
    if (!u) return res.status(404).json({ error: 'User not found' });
    const out = { id: u.id, name: u.name, email: u.email, role: u.role, doctor: null, store: null };
    if (u.role === 'ASSISTANT') {
      const docId = _mappedDoctor(u.id);
      if (docId) {
        const d = (await pool.query('SELECT id, name FROM users WHERE id=$1', [docId])).rows[0];
        if (d) out.doctor = { id: d.id, name: d.name };
      }
    }
    if (u.store_id) {
      try { const st = (await pool.query('SELECT id, name FROM stores WHERE id=$1', [u.store_id])).rows[0]; if (st) out.store = st; } catch (e) {}
    }
    res.json(out);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Health Check
app.get('/health', (req, res) => res.json({ status: 'ok' }));
// Database round-trip + connection pool state — open /health/db to see whether
// slowness is the database (high ms) or the pool (waiting > 0).
app.get('/health/db', async (req, res) => {
  const t0 = Date.now();
  try {
    await pool.query('SELECT 1');
    res.json({ db: 'ok', ms: Date.now() - t0, pool: { open: pool.totalCount, idle: pool.idleCount, waiting: pool.waitingCount } });
  } catch (e) {
    res.status(500).json({ db: 'error', error: e.message, ms: Date.now() - t0,
      pool: { open: pool.totalCount, idle: pool.idleCount, waiting: pool.waitingCount } });
  }
});

// Indexes for the lookups every dashboard load makes (by patient / doctor).
// Without them each lookup scanned whole tables — and nutrition_plans rows are
// large (full plan JSON), so those scans were expensive.
(async () => {
  const idx = [
    'CREATE INDEX IF NOT EXISTS idx_nutrition_plans_patient_ver ON nutrition_plans(patient_id, version DESC)',
    'CREATE INDEX IF NOT EXISTS idx_manufacturing_jobs_patient ON manufacturing_jobs(patient_id)',
    'CREATE INDEX IF NOT EXISTS idx_manufacturing_jobs_store ON manufacturing_jobs(store_id)',
    'CREATE INDEX IF NOT EXISTS idx_monitoring_logs_patient_type ON monitoring_logs(patient_id, type)',
    'CREATE INDEX IF NOT EXISTS idx_patients_assigned_doctor ON patients(assigned_doctor_id)',
    "CREATE INDEX IF NOT EXISTS idx_patients_fd_doctor ON patients((full_data->>'assignedDoctorId'))",
    'CREATE INDEX IF NOT EXISTS idx_patients_created_at ON patients(created_at DESC)'
  ];
  for (const q of idx) {
    try { await pool.query(q); } catch (e) { console.warn('index:', e.message); }
  }
  console.log('performance indexes ready');
})();

// Test push — send a test notification to the calling user
app.post('/api/push/test', authenticateToken, async (req, res) => {
  const sub = _pushSubs[req.user.id];
  if (!sub) return res.status(404).json({ error: 'No subscription found for this user. Make sure notifications are enabled and you have visited the store dashboard.' });
  if (!webpush) return res.status(503).json({ error: 'web-push not loaded on server' });
  try {
    await webpush.sendNotification(sub, JSON.stringify({
      title: '✅ Gquence Test Notification',
      body: 'Push notifications are working correctly! Tap to open store.',
      url: '/store'
    }));
    res.json({ ok: true, message: 'Test notification sent' });
  } catch(e) {
    // Same rule as notifyUsers: a failed test send is not proof the
    // subscription is dead, so don't silently disable the user's notifications.
    const removed = await dropPushSubscription(req.user.id, e);
    res.status(500).json({ error: e.message, subscriptionRemoved: removed });
  }
});

// Turning notifications off should clear the stored subscription too,
// otherwise the next server start reloads it and pushes resume.
app.post('/api/push/unsubscribe', authenticateToken, async (req, res) => {
  delete _pushSubs[req.user.id];
  try {
    await pool.query('DELETE FROM push_subscriptions WHERE user_id=$1', [req.user.id]);
  } catch(e) { return res.status(500).json({ error: e.message }); }
  res.json({ ok: true });
});

// Auth: Login
app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    const user = result.rows[0];
    if (!user) return res.status(400).json({ error: 'User not found' });

    const validPassword = await bcrypt.compare(password, user.password_hash);
    if (!validPassword) return res.status(400).json({ error: 'Invalid password' });

    const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET);
    // Which modules this user may use, and where they land. If the access
    // lookup fails, login still succeeds and the browser falls back to the
    // legacy role-based route (Oncology) — exactly the behaviour before modules.
    let modules = null, landing = null;
    try {
      const a = await platform.access.forUser(user.id, { fresh: true });
      if (a) { modules = a.modules; landing = a.landing; }
    } catch (e) { console.warn('login: module access lookup failed:', e.message); }
    res.json({ token, modules, landing,
      user: { id: user.id, name: user.name, role: user.role, hospital_name: user.hospital_name, storeId: user.store_id || null } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Patients: Get All
// Doctors and assistants only ever work with their own caseload, but every
// page load used to download EVERY patient (and every plan version) in the
// system. Scope those two roles to their doctor's patients; admin / store /
// coordinator keep the full list.
function _caseloadScope(req) {
  const u = req.user || {};
  if (u.role === 'DOCTOR')    return { doctorId: u.id, selfId: u.id };
  if (u.role === 'ASSISTANT') return { doctorId: _mappedDoctor(u.id) || u.id, selfId: u.id };
  return null;
}
const _CASELOAD_SQL = `(p.assigned_doctor_id = $1 OR p.full_data->>'assignedDoctorId' = $1
                        OR p.created_by_id = $2 OR p.created_by_user_id = $2)`;

app.get('/api/patients', authenticateToken, async (req, res) => {
  try {
    const scope = _caseloadScope(req);
    const result = scope
      ? await pool.query(`SELECT p.* FROM patients p WHERE ${_CASELOAD_SQL} ORDER BY p.created_at DESC`, [scope.doctorId, scope.selfId])
      : await pool.query('SELECT * FROM patients ORDER BY created_at DESC');
    const patients = result.rows.map(r => {
      const p = r.full_data || {};
      if (r.feeding_method != null) p.feedingMethod = r.feeding_method;
      if (r.reduced_food_intake != null) p.reducedFoodIntake = r.reduced_food_intake;
      if (r.weight != null) p.weight = r.weight;
      if (r.status != null) p.status = r.status;
      // Ensure assigned doctor is always present under the camelCase key the frontend uses
      if (!p.assignedDoctorId && r.assigned_doctor_id) p.assignedDoctorId = r.assigned_doctor_id;
      if (!p.id && r.id) p.id = r.id;
      // Some records (e.g. ones activated from a draft) never got a createdAt in
      // full_data; the dashboards sort on it, so those sank to the bottom.
      if (!p.createdAt && r.created_at) p.createdAt = new Date(r.created_at).toISOString();
      return p;
    });
    res.json(patients);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Patients: Create
app.post('/api/patients', authenticateToken, async (req, res) => {
  const p = req.body;
  p.assignedDoctorId = _ownerDoctorFor(req, p.assignedDoctorId || p.assigned_doctor_id || null);
  if (p.assigned_doctor_id) p.assigned_doctor_id = p.assignedDoctorId;
  try {
    await pool.query(
      `INSERT INTO patients (
        id, uhic, name, age, sex, height, weight, usual_weight, albumin, crp, muac,
        feeding_method, gi_issues, assigned_doctor_id, created_by_id, status,
        cancer, regimen, sodium, potassium, urea, hba1c, weight_loss_percent,
        reduced_food_intake, hand_grip, smi, allergies, side_effects, comorbidities,
        genomic_markers, created_date, created_by_user_id, full_data,
        creatinine, egfr, alt, ast, bilirubin, blood_sugar, tsh, hemoglobin,
        prealbumin, vit_d, vit_b12, folate, zinc, magnesium, ecog_status,
        cancer_stage, tumor_burden, metastasis_sites, treatment_types, activity_level,
        bsa, lean_body_mass, sarcopenia_status, fat_percent, is_vegetarian,
        cultural_preferences, existing_supplements, store_id, palliative_stage
      ) VALUES (
        $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,
        $17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,
        $34,$35,$36,$37,$38,$39,$40,$41,$42,$43,$44,$45,$46,$47,$48,$49,$50,
        $51,$52,$53,$54,$55,$56,$57,$58,$59,$60,$61,$62
      )
      ON CONFLICT (id) DO UPDATE SET full_data = EXCLUDED.full_data`,
      [
        p.id, p.uhic, p.name, p.age, p.sex, p.height, p.weight,
        p.usualWeight || p.usual_weight, p.albumin, p.crp, p.muac,
        p.feedingMethod || p.feeding_method, !!(p.giIssues || p.gi_issues),
        p.assignedDoctorId || p.assigned_doctor_id, req.user.id,
        p.status || 'CREATED',
        p.cancer, p.regimen, p.sodium, p.potassium, p.urea, p.hba1c,
        p.weightLossPercent || p.weight_loss_percent,
        p.reducedFoodIntake || p.reduced_food_intake,
        p.handGrip || p.hand_grip, p.smi,
        Array.isArray(p.allergies) ? JSON.stringify(p.allergies) : p.allergies,
        Array.isArray(p.sideEffects) ? JSON.stringify(p.sideEffects) : (Array.isArray(p.side_effects) ? JSON.stringify(p.side_effects) : p.side_effects),
        Array.isArray(p.comorbidities) ? JSON.stringify(p.comorbidities) : p.comorbidities,
        Array.isArray(p.genomicMarkers) ? JSON.stringify(p.genomicMarkers) : (Array.isArray(p.genomic_markers) ? JSON.stringify(p.genomic_markers) : p.genomic_markers),
        p.createdDate || p.created_date, p.createdByUserId || req.user.id,
        JSON.stringify(p),
        p.creatinine, p.egfr, p.alt, p.ast, p.bilirubin,
        p.bloodSugar || p.blood_sugar, p.tsh, p.hemoglobin, p.prealbumin,
        p.vitD || p.vit_d, p.vitB12 || p.vit_b12, p.folate, p.zinc, p.magnesium,
        p.ecogStatus || p.ecog_status, p.cancerStage || p.cancer_stage,
        p.tumorBurden || p.tumor_burden,
        Array.isArray(p.metastasisSites) ? JSON.stringify(p.metastasisSites) : p.metastasis_sites,
        Array.isArray(p.treatmentTypes) ? JSON.stringify(p.treatmentTypes) : p.treatment_types,
        p.activityLevel || p.activity_level, p.bsa,
        p.leanBodyMass || p.lean_body_mass,
        p.sarcopeniaStatus || p.sarcopenia_status,
        p.fatPercent || p.fat_percent,
        !!(p.vegetarian || p.is_vegetarian),
        p.culturalPreferences || p.cultural_preferences,
        Array.isArray(p.existingSupplements) ? JSON.stringify(p.existingSupplements) : p.existing_supplements,
        p.storeId || p.store_id, p.palliativeStage || p.palliative_stage
      ]
    );
    res.status(201).json(p);
    recordEvent({ type: 'patient_created', title: '🆕 New patient',
      body: `{patient} was registered by {actor}.`, patientId: p.id, patientName: p.name, user: req.user });
  } catch (err) {
    console.error('Patient create error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// Patients: Get by ID
app.get('/api/patients/:id', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM patients WHERE id = $1', [req.params.id]);
    if (!result.rows[0]) return res.status(404).json({ error: 'Not found' });
    const row = result.rows[0];
    // Merge dedicated DB columns into full_data so stale blobs never hide updated fields
    const patientData = row.full_data || {};
    if (row.feeding_method != null) patientData.feedingMethod = row.feeding_method;
    if (row.reduced_food_intake != null) patientData.reducedFoodIntake = row.reduced_food_intake;
    if (row.weight != null) patientData.weight = row.weight;
    if (row.usual_weight != null) patientData.usualWeight = row.usual_weight;
    if (row.height != null) patientData.height = row.height;
    if (row.sex    != null) patientData.sex    = row.sex;
    if (row.albumin    != null) patientData.albumin    = row.albumin;
    if (row.crp        != null) patientData.crp        = row.crp;
    if (row.creatinine != null) patientData.creatinine = row.creatinine;
    if (row.urea       != null) patientData.urea       = row.urea;
    if (row.sodium     != null) patientData.sodium     = row.sodium;
    if (row.potassium  != null) patientData.potassium  = row.potassium;
    if (row.blood_sugar != null) patientData.bloodSugar = row.blood_sugar;
    if (row.hemoglobin != null) patientData.hemoglobin = row.hemoglobin;
    if (row.alt        != null) patientData.alt        = row.alt;
    if (row.ast        != null) patientData.ast        = row.ast;
    if (row.bilirubin  != null) patientData.bilirubin  = row.bilirubin;
    if (row.status     != null) patientData.status     = row.status;
    res.json(patientData);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Patients: Update
app.put('/api/patients/:id', authenticateToken, async (req, res) => {
  const p = req.body;
  {
    const want = p.assignedDoctorId || p.assigned_doctor_id || null;
    const fixed = _ownerDoctorFor(req, want);
    if (fixed && fixed !== want) { p.assignedDoctorId = fixed; if (p.assigned_doctor_id) p.assigned_doctor_id = fixed; }
  }
  try {
    let _prevStatus = null;
    try {
      const pr = await pool.query('SELECT status FROM patients WHERE id=$1', [req.params.id]);
      _prevStatus = pr.rows[0] ? pr.rows[0].status : null;
    } catch (e) {}
    await pool.query(
      `UPDATE patients SET
        name=$1, age=$2, sex=$3, height=$4, weight=$5, usual_weight=$6,
        albumin=$7, crp=$8, muac=$9, feeding_method=$10, gi_issues=$11,
        status=$12, cancer=$13, regimen=$14, sodium=$15, potassium=$16,
        urea=$17, hba1c=$18, weight_loss_percent=$19, reduced_food_intake=$20,
        hand_grip=$21, smi=$22, allergies=$23, side_effects=$24, comorbidities=$25,
        genomic_markers=$26, full_data=$27, creatinine=$28, alt=$29, ast=$30,
        bilirubin=$31, blood_sugar=$32, tsh=$33, hemoglobin=$34, prealbumin=$35,
        vit_d=$36, vit_b12=$37, folate=$38, zinc=$39, magnesium=$40,
        ecog_status=$41, cancer_stage=$42, tumor_burden=$43,
        metastasis_sites=$44, treatment_types=$45, activity_level=$46,
        bsa=$47, lean_body_mass=$48, sarcopenia_status=$49, fat_percent=$50,
        is_vegetarian=$51, cultural_preferences=$52, existing_supplements=$53,
        store_id=$54, assigned_doctor_id=$55
      WHERE id=$56`,
      [
        p.name, p.age, p.sex, p.height, p.weight,
        p.usualWeight || p.usual_weight, p.albumin, p.crp, p.muac,
        p.feedingMethod || p.feeding_method, !!(p.giIssues || p.gi_issues),
        p.status || 'CREATED', p.cancer, p.regimen, p.sodium, p.potassium,
        p.urea, p.hba1c, p.weightLossPercent || p.weight_loss_percent,
        p.reducedFoodIntake || p.reduced_food_intake,
        p.handGrip || p.hand_grip, p.smi,
        Array.isArray(p.allergies) ? JSON.stringify(p.allergies) : p.allergies,
        Array.isArray(p.sideEffects) ? JSON.stringify(p.sideEffects) : (Array.isArray(p.side_effects) ? JSON.stringify(p.side_effects) : p.side_effects),
        Array.isArray(p.comorbidities) ? JSON.stringify(p.comorbidities) : p.comorbidities,
        Array.isArray(p.genomicMarkers) ? JSON.stringify(p.genomicMarkers) : (Array.isArray(p.genomic_markers) ? JSON.stringify(p.genomic_markers) : p.genomic_markers),
        JSON.stringify(p), p.creatinine, p.alt, p.ast, p.bilirubin,
        p.bloodSugar || p.blood_sugar, p.tsh, p.hemoglobin, p.prealbumin,
        p.vitD || p.vit_d, p.vitB12 || p.vit_b12, p.folate, p.zinc, p.magnesium,
        p.ecogStatus || p.ecog_status, p.cancerStage || p.cancer_stage,
        p.tumorBurden || p.tumor_burden,
        Array.isArray(p.metastasisSites) ? JSON.stringify(p.metastasisSites) : p.metastasis_sites,
        Array.isArray(p.treatmentTypes) ? JSON.stringify(p.treatmentTypes) : p.treatment_types,
        p.activityLevel || p.activity_level, p.bsa,
        p.leanBodyMass || p.lean_body_mass,
        p.sarcopeniaStatus || p.sarcopenia_status,
        p.fatPercent || p.fat_percent,
        !!(p.vegetarian || p.is_vegetarian),
        p.culturalPreferences || p.cultural_preferences,
        Array.isArray(p.existingSupplements) ? JSON.stringify(p.existingSupplements) : p.existing_supplements,
        p.storeId || p.store_id,
        p.assignedDoctorId || p.assigned_doctor_id,
        req.params.id
      ]
    );
    // Push notification when patient is approved — only the store's manager(s)
    if ((p.status === 'APPROVED') && p.storeId) {
      notifyStore(p.storeId,
        '✅ New Patient Approved',
        `${p.name || 'A patient'} is ready for production. Tap to view plan.`,
        `/patients/profile?id=${req.params.id}&store=1`,
        ['STORE']
      ).catch(() => {});
    }
    res.json(p);
    const _newStatus = p.status || 'CREATED';
    if (_prevStatus && _newStatus !== _prevStatus) {
      recordEvent({
        type: 'patient_status',
        title: _newStatus === 'APPROVED' ? '✅ Plan approved' : 'Patient status changed',
        body: _newStatus === 'APPROVED'
          ? `{actor} approved the nutrition plan for {patient}. It goes to the store for pricing.`
          : `{patient}: ${_stageLabel(_prevStatus)} → ${_stageLabel(_newStatus)} (by {actor}).`,
        patientId: req.params.id, patientName: p.name, user: req.user });
    }
  } catch (err) {
    console.error('Patient update error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// Patients: Delete
app.delete('/api/patients/:id', authenticateToken, async (req, res) => {
  try {
    await pool.query('DELETE FROM patients WHERE id = $1', [req.params.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Assessments: Add to patient
app.post('/api/patients/:id/assessments', authenticateToken, async (req, res) => {
  const a = req.body;
  try {
    const result = await pool.query(
      `INSERT INTO assessments (
        id, patient_id, assessment_date, weight, albumin, crp, muac, creatinine,
        alt, ast, bilirubin, blood_sugar, tsh, hemoglobin, prealbumin, vit_d,
        vit_b12, folate, zinc, magnesium, bsa, lean_body_mass, fat_percent,
        gi_issues, reduced_food_intake, notes
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26)
      RETURNING *`,
      [
        a.id, req.params.id, a.date || new Date().toISOString().split('T')[0],
        a.weight, a.albumin, a.crp, a.muac, a.creatinine,
        a.alt, a.ast, a.bilirubin, a.bloodSugar || a.blood_sugar,
        a.tsh, a.hemoglobin, a.prealbumin, a.vitD || a.vit_d,
        a.vitB12 || a.vit_b12, a.folate, a.zinc, a.magnesium,
        a.bsa, a.leanBodyMass || a.lean_body_mass, a.fatPercent || a.fat_percent,
        !!(a.giIssues || a.gi_issues), a.reducedFoodIntake || a.reduced_food_intake,
        a.notes || ''
      ]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Nutrition Plans: Get all (optionally filtered by patient)
app.get('/api/nutrition-plans', authenticateToken, async (req, res) => {
  try {
    // Only the latest version of each patient's plan is used by the pages
    // (getLatestPlanForPatient / next version number), so don't ship the history.
    const scope = _caseloadScope(req);
    const result = await pool.query(
      `SELECT DISTINCT ON (np.patient_id) np.*
         FROM nutrition_plans np
         ${scope ? `JOIN patients p ON p.id = np.patient_id WHERE ${_CASELOAD_SQL}` : ''}
        ORDER BY np.patient_id, np.version DESC NULLS LAST, np.generated_at DESC`,
      scope ? [scope.doctorId, scope.selfId] : []);
    result.rows.sort((a, b) => new Date(b.generated_at || 0) - new Date(a.generated_at || 0));
    const plans = result.rows.map(r => {
      const plan = r.full_data || {
        id: r.id, patientId: r.patient_id, version: r.version,
        generatedAt: r.generated_at, generatedBy: r.generated_by,
        inputsSnapshot: r.inputs_snapshot, engineOutput: r.engine_output,
        overrides: r.overrides, finalPlan: r.final_plan,
        rationale: r.rationale, overrideNotes: r.override_notes
      };
      // claude_insights column is authoritative — always overwrite full_data's value
      if (r.claude_insights) plan.claudeInsights = r.claude_insights;
      return plan;
    });
    res.json(plans);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Nutrition Plans: Get for a patient
app.get('/api/nutrition-plans/patient/:patientId', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM nutrition_plans WHERE patient_id = $1 ORDER BY version DESC',
      [req.params.patientId]
    );
    const plans = result.rows.map(r => {
      const plan = r.full_data || {
        id: r.id, patientId: r.patient_id, version: r.version,
        generatedAt: r.generated_at, generatedBy: r.generated_by,
        inputsSnapshot: r.inputs_snapshot, engineOutput: r.engine_output,
        overrides: r.overrides, finalPlan: r.final_plan,
        rationale: r.rationale, overrideNotes: r.override_notes
      };
      if (r.claude_insights) plan.claudeInsights = r.claude_insights;
      return plan;
    });
    res.json(plans);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Nutrition Plans: Create
app.post('/api/nutrition-plans', authenticateToken, async (req, res) => {
  const pl = req.body;
  try {
    await pool.query(
      `INSERT INTO nutrition_plans (id, patient_id, version, inputs_snapshot, engine_output, overrides, final_plan, rationale, override_notes, generated_by, claude_insights, full_data)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
       ON CONFLICT (id) DO UPDATE SET full_data = EXCLUDED.full_data, final_plan = EXCLUDED.final_plan, overrides = EXCLUDED.overrides, override_notes = EXCLUDED.override_notes,
         claude_insights = COALESCE(EXCLUDED.claude_insights, nutrition_plans.claude_insights)`,
      [
        pl.id, pl.patientId || pl.patient_id, pl.version,
        pl.inputsSnapshot ? JSON.stringify(pl.inputsSnapshot) : null,
        pl.engineOutput ? JSON.stringify(pl.engineOutput) : null,
        pl.overrides ? JSON.stringify(pl.overrides) : null,
        pl.finalPlan ? JSON.stringify(pl.finalPlan) : null,
        pl.rationale || [],
        pl.overrideNotes || '',
        pl.generatedBy || 'ENGINE',
        pl.claudeInsights ? JSON.stringify(pl.claudeInsights) : null,
        JSON.stringify(pl)
      ]
    );
    res.status(201).json(pl);
  } catch (err) {
    console.error('Plan create error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// Nutrition Plans: Update
app.put('/api/nutrition-plans/:id', authenticateToken, async (req, res) => {
  const pl = req.body;
  try {
    await pool.query(
      `UPDATE nutrition_plans SET
        overrides=$1, final_plan=$2, override_notes=$3,
        claude_insights = COALESCE($4::jsonb, claude_insights),
        full_data=$5
       WHERE id=$6`,
      [
        pl.overrides ? JSON.stringify(pl.overrides) : null,
        pl.finalPlan ? JSON.stringify(pl.finalPlan) : null,
        pl.overrideNotes || '',
        pl.claudeInsights ? JSON.stringify(pl.claudeInsights) : null,
        JSON.stringify(pl),
        req.params.id
      ]
    );
    res.json(pl);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Nutrition Plans: Save only claude_insights (lightweight — avoids sending full plan payload)
app.patch('/api/nutrition-plans/:id/insights', authenticateToken, async (req, res) => {
  const { insights } = req.body;
  if (insights === undefined) return res.status(400).json({ error: 'insights required' });
  try {
    const result = await pool.query(
      `UPDATE nutrition_plans SET claude_insights = $1 WHERE id = $2`,
      [insights ? JSON.stringify(insights) : null, req.params.id]
    );
    // rowCount tells client whether the plan existed in DB (0 = plan missing, needs POST first)
    res.json({ ok: true, rowCount: result.rowCount });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Patient Monitoring Logs
// ── Weekly Prescription calculation ───────────────────────────────────────
// ── Weekly Recipe Ingredient Calculator ───────────────────────────────────
// Derives a deterministic ingredient breakdown from supplement kcal + protein targets.
// Glutamine (16 g) is a clinical adjunct added on top of suppKcal — consistent with
// how the initial prescription handles it.
// proteinOpts = { plan: 'P1'…'P5', soyFree: bool } — the protein blend (js/protein-plans.js).
// Without a plan (old callers) GI/Hydrolyzed → P3, otherwise P1.
function calcWeeklyRecipe(suppKcal, suppProtein, formulation, proteinOpts) {
  if (!suppKcal || !suppProtein || suppKcal <= 0 || suppProtein <= 0) return null;

  const isHydrolyzed = formulation === 'Hydrolyzed';
  const isDiabetic   = formulation === 'Diabetic';
  const isAntiInflam = formulation === 'Anti-inflammatory';

  // Protein source — blend from the protein formulation plan
  const po = proteinOpts || {};
  const planCode = ProteinPlans.normCode(po.plan) || (isHydrolyzed ? 'P3' : 'P1');
  const blend = ProteinPlans.build(planCode, suppProtein, !!po.soyFree);
  const protDeliv = blend.protein;

  // Macro targets from suppKcal (standard oncology ratios)
  // Diabetic: lower carbs (25 %), more fat (57 %)   Standard/other: 37 % C / 45 % F
  const fatPct  = isDiabetic ? 0.57 : 0.45;
  const carbPct = isDiabetic ? 0.25 : 0.37;

  // MCT Powder (70 % fat, 30 % carb carrier)
  const fatGrams = Math.max(0, suppKcal * fatPct / 9 - blend.fat);
  const mctGrams = Math.max(0, Math.round(fatGrams / 0.70));
  const mctFat   = Math.round(mctGrams * 0.70 * 10) / 10;
  const mctCarbs = Math.round(mctGrams * 0.30 * 10) / 10;

  // Omega-3 Powder (higher dose for anti-inflammatory)
  const omega3Grams    = isAntiInflam ? 6 : 3.9;
  const omega3Fat      = Math.round(omega3Grams * 0.5 * 10) / 10;
  const omega3Carbs    = Math.round(omega3Grams * 0.5 * 10) / 10;
  const omega3Rationale = isAntiInflam
    ? 'High EPA/DHA (6 g/day) to downregulate pro-inflammatory cytokines and stabilize lean mass.'
    : 'Anti-inflammatory / EPA support.';

  // Carb source (palatinose for diabetic, maltodextrin otherwise)
  const carbGramsTotal   = suppKcal * carbPct / 4;
  const carbSourceGrams  = Math.max(0, Math.round((carbGramsTotal - mctCarbs - omega3Carbs - blend.carbs) * 10) / 10);
  const carbName         = isDiabetic ? 'Palatinose (Slow Release)' : 'Maltodextrin (DE 19)';
  const carbId           = isDiabetic ? 'palatinose' : 'maltodextrin';
  const carbRationale    = isDiabetic
    ? 'Slow-release carbohydrate to maintain stable blood glucose levels in diabetic oncology patients.'
    : 'Complex carbohydrate with low osmolality for sustained energy release and GI comfort.';

  // Glutamine — fixed clinical adjunct (mucosal protection, not counted in suppKcal)
  const glutGrams = 16;

  // Batch totals
  const totalPowder  = Math.round((blend.grams + carbSourceGrams + mctGrams + omega3Grams + glutGrams) * 10) / 10;
  const totalProtein = Math.round((protDeliv + glutGrams) * 10) / 10; // glutamine = 1 g protein/g
  const totalCarbs   = Math.round((blend.carbs + mctCarbs + omega3Carbs + carbSourceGrams) * 10) / 10;
  const totalFat     = Math.round((blend.fat + mctFat + omega3Fat) * 10) / 10;

  return {
    servingsPerDay: 3,
    proteinPlan: { code: blend.code, name: blend.name, soyFree: blend.soyFree, label: blend.label, blendText: blend.blendText },
    ingredients: blend.rows.map(r => ({
        id: r.id, name: r.name, pct: r.pct, grams: r.grams, deliveredProtein: r.deliveredProtein,
        rationale: r.rationale, contrib: r.contrib })).concat([
      { id: carbId, name: carbName, grams: carbSourceGrams, rationale: carbRationale,
        contrib: { protein: 0, carbs: carbSourceGrams, fat: 0 } },
      { id: 'mct_powder', name: 'MCT Powder (70%)', grams: mctGrams,
        rationale: 'Metabolic energy without glycemic load',
        contrib: { protein: 0, carbs: mctCarbs, fat: mctFat } },
      { id: 'omega3_powder', name: 'Omega-3 Powder', grams: omega3Grams,
        rationale: omega3Rationale,
        contrib: { protein: 0, carbs: omega3Carbs, fat: omega3Fat } },
      { id: 'glutamine', name: 'L-Glutamine powder', grams: glutGrams,
        rationale: 'Mucosal protection.',
        contrib: { protein: glutGrams, carbs: 0, fat: 0 } }
    ]),
    totals: { powder: totalPowder, protein: totalProtein, carbs: totalCarbs, fat: totalFat },
    proteinBreakdown: `${blend.code} blend ${protDeliv}g + Glutamine ${glutGrams}g`
  };
}

// Helper: fetch engine_formulas from DB and return as { id: value } map
async function loadFormulaConstants(pool) {
  try {
    const r = await pool.query('SELECT id, value FROM engine_formulas');
    const map = {};
    r.rows.forEach(row => { map[row.id] = row.value; });
    return map;
  } catch(e) {
    console.warn('loadFormulaConstants failed, using hardcoded defaults:', e.message);
    return {};
  }
}

function calcWeeklyRxTargets(baseline, mon, formulas) {
  // formulas = rows from engine_formulas keyed by id (e.g. formulas.kcal_cachexia = 35)
  const F = formulas || {};
  const fd = baseline || {};

  // ── STATIC — always from patient's saved baseline record, never re-entered ─
  const height      = fd.height              || null;   // patient.height (cm)
  const sex         = fd.sex                 || 'M';    // patient.sex
  const weightBasis = fd.weightBasisOverride || 'ibw';  // patient.weightBasisOverride
  const giIssues    = fd.giIssues            || false;  // patient.giIssues (hydrolyzed?)

  // ── DYNAMIC — from weekly monitoring; fall back to last saved baseline value ─
  const weight     = mon.weight      != null ? mon.weight      : (fd.weight      || null);
  const ecog       = parseInt(mon.ecog != null ? mon.ecog      : (fd.ecogStatus  || '0'), 10);
  const albumin    = mon.albumin     != null ? mon.albumin     : (fd.albumin     || null);
  const crp        = mon.crp         != null ? mon.crp         : (fd.crp         || null);
  const glucose    = mon.glucose     != null ? mon.glucose     : (fd.bloodSugar  || null);
  const creatinine = mon.creatinine  != null ? mon.creatinine  : (fd.creatinine  || null);
  const urea       = mon.urea        != null ? mon.urea        : (fd.urea        || null);

  // ── Feeding route — preserved from initial plan ──
  // Read from finalPlan.feedingMethod first, then patient-level fields
  const _fp0 = fd.finalPlan || fd.engineOutput || {};
  const feedingRoute = _fp0.feedingMethod || _fp0.prescribedRoute
                    || fd.prescribedRoute  || fd.feedingMethod || '';
  // isTubeFeed based on saved plan's feeding route — but monitoring oralIntake overrides this.
  // If the doctor records oralIntake > 0 in the monitoring form, the patient IS eating orally.
  const _savedRouteIsTube = /enteral|tube|ng[- ]?tube|peg|jej|parenteral|tpn/i.test(feedingRoute);
  const isTubeFeed = (mon.oralIntake != null)
    ? (Number(mon.oralIntake) === 0)   // monitoring is ground truth: 0% oral = tube, >0 = partial oral
    : _savedRouteIsTube;

  // oralIntake from monitoring is 0–100 %; baseline stores reducedFoodIntake (deficit %)
  const oralPct = (mon.oralIntake != null)
    ? Number(mon.oralIntake)   // monitoring entry is always the ground truth
    : (isTubeFeed ? 0 : (fd.reducedFoodIntake != null ? 100 - fd.reducedFoodIntake : 60));

  if (!weight) return null; // need at least weight

  // IBW (Hamwi) — use saved value from finalPlan first (same number doctor approved),
  // recalculate from height only as a fallback.
  // Sanity-check: if saved IBW is < 40% of actual weight it was computed from wrong
  // height data (e.g. height entered in metres instead of cm) — discard and recalculate.
  let calcWeight = weight;
  let ibw = null;
  let bsa = null;
  const isFemaleIBW = sex && (sex.toLowerCase() === 'female' || sex.toLowerCase() === 'f');
  if (_fp0.ibw) {
    const candidateIbw = Math.round(_fp0.ibw * 10) / 10;
    // Plausibility gate: saved IBW must be at least 40% of the monitoring weight.
    // If not, the saved IBW was computed from bad height data — recalculate instead.
    const ibwIsPlausible = !weight || (candidateIbw >= weight * 0.4 && candidateIbw <= weight * 1.5);
    if (ibwIsPlausible) {
      ibw = candidateIbw;
    }
  }
  if (!ibw && height) {
    // Recalculate Hamwi from stored height
    const heightIn = height / 2.54;
    ibw = isFemaleIBW
      ? Math.max(30, 45.5 + 2.2 * (heightIn - 60))
      : Math.max(30, 48   + 2.7 * (heightIn - 60));
    ibw = Math.round(ibw * 10) / 10;
  }
  calcWeight = (weightBasis === 'ibw' && ibw) ? ibw : weight;
  if (height) bsa = Math.round(Math.sqrt(height * weight / 3600) * 100) / 100;

  // ── Read base kcal/kg and protein/kg from the patient's saved initial prescription ──
  // Try finalPlan first, then engineOutput, then top-level fd fields.
  const fp = fd.finalPlan || fd.engineOutput || {};

  // kcal/kg: stored value → derive from baseEnergy/calcWeight → cachexia default
  const _fpKcalPerKg = fp.kcalPerKg
    || (fp.baseEnergy && fp.calcWeight ? Math.round(fp.baseEnergy / fp.calcWeight) : null)
    || fd.kcalPerKg
    || null;
  // Formula grid defaults (from engine_formulas table, admin-configurable)
  const fKcalCachexia       = parseFloat(F.kcal_cachexia)           || 35;
  const fKcalModerate       = parseFloat(F.kcal_moderate_risk)      || 30;
  const fKcalStable         = parseFloat(F.kcal_stable)             || 25;
  const fProtCachexia       = parseFloat(F.protein_cachexia)        || 1.8;
  const fProtBaseline       = parseFloat(F.protein_baseline)        || 1.4;
  const fProtHighCatab      = parseFloat(F.protein_high_catabolism) || 2.0;
  const fProtRenal          = parseFloat(F.protein_renal)           || 0.8;  // KDIGO cap
  const fCreatinineRenal    = parseFloat(F.creatinine_renal_danger) || 1.3;
  const fUreaHigh           = parseFloat(F.urea_high)               || 45;

  // Doctor override from monitoring entry takes highest priority
  const baseKcalPerKg = mon.kcalPerKg || _fpKcalPerKg || fKcalCachexia;

  // protein/kg: stored value → derive from totalDailyProtein/calcWeight → stored dailyProtein/calcWeight → default
  const _fpProtPerKg = fp.proteinPerKg
    || (fp.totalDailyProtein && fp.calcWeight ? Math.round(fp.totalDailyProtein / fp.calcWeight * 10) / 10 : null)
    || (fp.dailyProtein && fp.calcWeight      ? Math.round((fp.dailyProtein / fp.calcWeight) * 2 * 10) / 10 : null)
    || fd.proteinPerKg
    || null;
  // Doctor override from monitoring entry takes highest priority
  const baseProteinPerKg = mon.proteinPerKg || _fpProtPerKg || fProtBaseline;

  // ECOG adjustment: step down if status has deteriorated from baseline
  const baseEcog = parseInt(fd.ecogStatus || '0', 10);
  let kcalPerKg = baseKcalPerKg;
  if      (ecog >= 3 && baseEcog < 3) kcalPerKg = Math.max(fKcalStable,    baseKcalPerKg - 7);
  else if (ecog >= 2 && baseEcog < 2) kcalPerKg = Math.max(fKcalModerate - 2, baseKcalPerKg - 4);

  const totalKcal = Math.round(calcWeight * kcalPerKg);

  // Protein: albumin-driven, then hard-capped by renal safety rule
  const fAlbuminLow  = parseFloat(F.albumin_low_threshold)      || 3.5;
  const fAlbuminCrit = parseFloat(F.albumin_critical_threshold) || 3.0;
  let proteinPerKg = (!albumin || albumin >= fAlbuminLow)
    ? baseProteinPerKg
    : albumin >= fAlbuminCrit
      ? Math.max(baseProteinPerKg, fProtCachexia)
      : Math.max(baseProteinPerKg, fProtHighCatab);

  // KDIGO renal safety cap — highest priority, overrides all other protein targets.
  // Triggered when creatinine ≥ 1.3 mg/dL OR urea ≥ 50 mmol/L.
  const hasRenalFlag = (creatinine != null && creatinine >= fCreatinineRenal)
                    || (urea       != null && urea       >= fUreaHigh);
  if (hasRenalFlag) proteinPerKg = Math.min(proteinPerKg, fProtRenal);

  const totalProtein = Math.round(calcWeight * proteinPerKg * 10) / 10; // one decimal to show cap clearly

  // Supplement portion
  const oralKcal    = Math.round(totalKcal    * (oralPct / 100));
  const suppKcal    = Math.max(0, totalKcal   - oralKcal);
  const suppProtein = Math.max(0, Math.round((totalProtein * (1 - oralPct / 100)) * 10) / 10);

  // Formulation flags
  const isAntiInflam = crp     != null && crp     >= 10;
  const isDiabetic   = glucose != null && glucose >  200;
  const isHydrolyzed = giIssues; // set at baseline, persists unless doctor changes it
  const formulation  = isDiabetic ? 'Diabetic'
                     : isAntiInflam ? 'Anti-inflammatory'
                     : isHydrolyzed ? 'Hydrolyzed'
                     : 'Standard';

  const flags = [];
  if (hasRenalFlag) {
    const renalReason = (creatinine != null && creatinine >= fCreatinineRenal)
      ? `Creatinine ${creatinine} mg/dL (≥${fCreatinineRenal})`
      : `Urea ${urea} mmol/L (≥${fUreaHigh})`;
    flags.push(`⚠️ RENAL: ${renalReason} — KDIGO protocol applied, protein capped to ${fProtRenal} g/kg (${totalProtein}g/day)`);
  }
  if (albumin && albumin < 3.5 && !hasRenalFlag) flags.push(`Low albumin (${albumin} g/dL) → protein target increased to ${proteinPerKg} g/kg`);
  if (isAntiInflam) flags.push(`High CRP (${crp} mg/L) → anti-inflammatory formulation`);
  if (isDiabetic)   flags.push(`High glucose (${glucose} mg/dL) → diabetic formulation`);
  if (ecog >= 3)    flags.push(`ECOG ${ecog} → reduced calorie target (${kcalPerKg} kcal/kg)`);

  // Protein formulation plan (P1–P5). Weekly signals (renal labs, diarrhoea,
  // nausea / appetite on this entry) are OR-ed with the baseline profile.
  const _yes = v => v === true || v === 'true' || (typeof v === 'number' && v > 0)
                 || (typeof v === 'string' && /^(yes|y|mild|moderate|severe|[1-4])$/i.test(v.trim()));
  const planSel = ProteinPlans.select(fd, {
    renal: hasRenalFlag,
    gi: giIssues || _yes(mon.diarrhea) || _yes(mon.diarrhoea) || /diarr/i.test(String(mon.bowel || '')),
    lowVolume: _yes(mon.nausea) || _yes(mon.vomiting) || _yes(mon.poorAppetite) || _yes(mon.earlySatiety)
  });
  const _fpPlan = (fd.finalPlan && fd.finalPlan.proteinPlan) || null;
  // A doctor's explicit choice on the initial plan carries forward; otherwise auto.
  const proteinPlan = (_fpPlan && _fpPlan.overridden && ProteinPlans.normCode(_fpPlan.code)) || planSel.code;
  const proteinSoyFree = planSel.soyFree;
  flags.push(`Protein plan ${ProteinPlans.label(proteinPlan, proteinSoyFree)} — ${planSel.reasons.join('; ')}`
    + (planSel.soyFreeReason ? ` (${planSel.soyFreeReason})` : ''));

  const recipe = calcWeeklyRecipe(suppKcal, suppProtein, formulation, { plan: proteinPlan, soyFree: proteinSoyFree });

  return { calcWeight: Math.round(calcWeight*10)/10, ibw: ibw ? Math.round(ibw*10)/10 : null, bsa,
           totalKcal, kcalPerKg, totalProtein, proteinPerKg,
           oralKcal, suppKcal, suppProtein, formulation, flags,
           proteinPlan, proteinPlanAuto: planSel.code, proteinSoyFree,
           proteinDairyFree: planSel.dairyFree, proteinPlanReasons: planSel.reasons,
           ecog, albumin, crp, glucose, oralPct, weight, height,
           baseKcalPerKg, baseProteinPerKg,
           feedingRoute, isTubeFeed,
           recipe };
}

app.post('/api/patients/:id/monitoring', authenticateToken, async (req, res) => {
  const { type, data } = req.body;
  if (!type || !data) return res.status(400).json({ error: 'type and data required' });
  try {
    const result = await pool.query(
      `INSERT INTO monitoring_logs (patient_id, type, recorded_by, data) VALUES ($1, $2, $3, $4) RETURNING *`,
      [req.params.id, type, req.user.id, JSON.stringify(data)]
    );
    const log = result.rows[0];

    // Auto-generate weekly prescription when type='weekly'
    let weeklyRx = null;
    let weeklyRxSkipped = null;
    // A weekly weight is the input the whole prescription turns on. The target
    // engine will happily fall back to the baseline weight recorded at intake,
    // which silently produces a full, confident-looking prescription from a
    // number that may be months stale — and puts it in the doctor's approval
    // queue as though it were fresh clinical data. Refuse instead: the log is
    // still saved, but no prescription is generated without a weight measured
    // at this visit.
    const _weeklyWeight = (type === 'weekly') ? parseFloat(data.weight) : null;
    const _hasWeeklyWeight = _weeklyWeight != null && !isNaN(_weeklyWeight) && _weeklyWeight > 0;
    if (type === 'weekly' && !_hasWeeklyWeight) {
      weeklyRxSkipped = {
        reason: 'WEIGHT_REQUIRED',
        message: 'Entry saved, but no prescription was generated: this week\'s weight is missing. '
               + 'Targets are calculated per kg, so add the weight and save again to generate one.'
      };
    }
    if (type === 'weekly' && _hasWeeklyWeight) {
      try {
        const patRow = await pool.query('SELECT full_data, name, height, sex FROM patients WHERE id=$1', [req.params.id]);
        const baseline = patRow.rows[0] ? (patRow.rows[0].full_data || {}) : {};
        // Dedicated columns override stale full_data blob (same merge as GET /api/patients/:id)
        if (patRow.rows[0] && patRow.rows[0].height != null) baseline.height = patRow.rows[0].height;
        if (patRow.rows[0] && patRow.rows[0].sex    != null) baseline.sex    = patRow.rows[0].sex;
        // Pull finalPlan from nutrition_plans (it's NOT in patients.full_data)
        const planRow = await pool.query(
          'SELECT final_plan, engine_output FROM nutrition_plans WHERE patient_id=$1 ORDER BY version DESC LIMIT 1',
          [req.params.id]
        );
        if (planRow.rowCount) {
          baseline.finalPlan   = planRow.rows[0].final_plan   || baseline.finalPlan;
          baseline.engineOutput = planRow.rows[0].engine_output || baseline.engineOutput;
        }
        const formulaConstants = await loadFormulaConstants(pool);
        const targets  = calcWeeklyRxTargets(baseline, data, formulaConstants);
        if (targets) {
          // Batch code: StudyID-Wn-YYMM (fall back to patientId prefix)
          const enr = await pool.query('SELECT study_id FROM trial_enrollments WHERE patient_id=$1', [req.params.id]);
          const studyId = enr.rows[0] ? enr.rows[0].study_id : req.params.id.slice(0,6).toUpperCase();
          const now = new Date();
          const yymm = String(now.getFullYear()).slice(2) + String(now.getMonth()+1).padStart(2,'0');
          const weekNo = data.week || 1;
          // Include last 4 digits of patient ID to prevent batch code collisions
          // when two patients share the same studyId prefix and week number
          const patSuffix = String(req.params.id).replace(/\D/g,'').slice(-4).padStart(4,'0');
          const batchCode = `${studyId}-W${weekNo}-${yymm}-${patSuffix}`;

          // Baseline snapshot for delta comparison (uses correct patient field names)
          const baselineSnap = {
            weight:     baseline.weight                                       || null,
            albumin:    baseline.albumin                                      || null,
            crp:        baseline.crp                                          || null,
            ecog:       baseline.ecogStatus                                   || 0,
            oralIntake: baseline.reducedFoodIntake != null
                          ? 100 - baseline.reducedFoodIntake : null
          };

          // Explicit SELECT → UPDATE or INSERT to avoid batch_code unique constraint conflicts
          const existingRxAuto = await pool.query(
            'SELECT id, status, approved_at FROM weekly_prescriptions WHERE patient_id=$1 AND week_number=$2',
            [req.params.id, weekNo]
          );
          let rxRes;
          if (existingRxAuto.rowCount) {
            // Re-approval, not a fresh review. Editing the log behind an approved
            // week legitimately sends it back — the targets may have moved — but
            // the stale approved_at must go with it, or the row reads as approved
            // while sitting in the pending queue, and supply-cover maths counts an
            // approval that no longer stands.
            const _prevAuto = existingRxAuto.rows[0];
            const _wasApprovedAuto = _prevAuto.status === 'APPROVED';
            rxRes = await pool.query(
              `UPDATE weekly_prescriptions
                 SET monitoring_log_id=$1, batch_code=$2, clinical_params=$3,
                     targets=$4, baseline_snapshot=$5, status='PENDING_REVIEW',
                     approved_at = CASE WHEN $8::bool THEN NULL ELSE approved_at END,
                     approved_by = CASE WHEN $8::bool THEN NULL ELSE approved_by END,
                     previously_approved_at = CASE WHEN $8::bool THEN $9 ELSE previously_approved_at END,
                     reopened_at = CASE WHEN $8::bool THEN NOW() ELSE reopened_at END,
                     updated_at=NOW()
               WHERE patient_id=$6 AND week_number=$7
               RETURNING *`,
              [log.id, batchCode, JSON.stringify(data), JSON.stringify(targets),
               JSON.stringify(baselineSnap), req.params.id, weekNo,
               _wasApprovedAuto, _prevAuto.approved_at]
            );
          } else {
            rxRes = await pool.query(
              `INSERT INTO weekly_prescriptions
                 (patient_id, week_number, monitoring_log_id, batch_code,
                  clinical_params, targets, baseline_snapshot, status, created_by)
               VALUES ($1,$2,$3,$4,$5,$6,$7,'PENDING_REVIEW',$8)
               RETURNING *`,
              [req.params.id, weekNo, log.id, batchCode,
               JSON.stringify(data), JSON.stringify(targets),
               JSON.stringify(baselineSnap), req.user.id]
            );
          }
          weeklyRx = rxRes.rows[0];
        }
      } catch(rxErr) { console.error('weekly_rx auto-gen:', rxErr.message); }
    }

    res.json({ ...log, weeklyRx, weeklyRxSkipped });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Generate prescription from an existing monitoring log (for entries saved before the feature)
app.post('/api/patients/:id/generate-weekly-rx', authenticateToken, async (req, res) => {
  const { monitoringLogId, weekNumber } = req.body;
  if (!monitoringLogId) return res.status(400).json({ error: 'monitoringLogId required' });
  try {
    const patId = req.params.id;
    const logRow = await pool.query('SELECT * FROM monitoring_logs WHERE id=$1 AND patient_id=$2', [monitoringLogId, patId]);
    if (!logRow.rowCount) return res.status(404).json({ error: 'Monitoring log not found' });
    const data = logRow.rows[0].data || {};

    const patRow = await pool.query('SELECT full_data, height, sex FROM patients WHERE id=$1', [patId]);
    if (!patRow.rowCount) return res.status(404).json({ error: 'Patient not found' });
    const baseline = patRow.rows[0].full_data || {};
    // Dedicated columns override stale full_data blob (same merge as GET /api/patients/:id)
    if (patRow.rows[0].height != null) baseline.height = patRow.rows[0].height;
    if (patRow.rows[0].sex    != null) baseline.sex    = patRow.rows[0].sex;
    // Pull finalPlan from nutrition_plans (it's NOT in patients.full_data)
    const planRow2 = await pool.query(
      'SELECT final_plan, engine_output FROM nutrition_plans WHERE patient_id=$1 ORDER BY version DESC LIMIT 1',
      [patId]
    );
    if (planRow2.rowCount) {
      baseline.finalPlan    = planRow2.rows[0].final_plan    || baseline.finalPlan;
      baseline.engineOutput = planRow2.rows[0].engine_output || baseline.engineOutput;
    }
    const formulaConstants2 = await loadFormulaConstants(pool);
    // Same rule as the auto-generate path: the weight must come from this
    // week's log, not from the baseline the engine would otherwise fall back to.
    const _regenWeight = parseFloat(data.weight);
    if (_regenWeight == null || isNaN(_regenWeight) || _regenWeight <= 0) {
      return res.status(422).json({
        error: 'No weight recorded on this weekly entry. Targets are calculated per kg, '
             + 'so add the weight to the entry and try again.',
        reason: 'WEIGHT_REQUIRED'
      });
    }
    const targets  = calcWeeklyRxTargets(baseline, data, formulaConstants2);
    if (!targets) return res.status(422).json({ error: 'Cannot calculate — patient weight missing from profile or monitoring entry' });

    const enr = await pool.query('SELECT study_id FROM trial_enrollments WHERE patient_id=$1', [patId]);
    const studyId = enr.rows[0] ? enr.rows[0].study_id : patId.slice(0,6).toUpperCase();
    const now = new Date();
    const yymm = String(now.getFullYear()).slice(2) + String(now.getMonth()+1).padStart(2,'0');
    const weekNo = weekNumber || data.week || 1;
    // Include last 4 digits of patient ID to prevent batch_code collisions across patients
    const patSuffix2 = String(patId).replace(/\D/g,'').slice(-4).padStart(4,'0');
    const batchCode = `${studyId}-W${weekNo}-${yymm}-${patSuffix2}`;

    const baselineSnap = {
      weight:     baseline.weight    || null,
      albumin:    baseline.albumin   || null,
      crp:        baseline.crp       || null,
      ecog:       baseline.ecogStatus || 0,
      oralIntake: baseline.reducedFoodIntake != null ? 100 - baseline.reducedFoodIntake : null
    };

    // Use explicit SELECT → UPDATE or INSERT to avoid ON CONFLICT issues.
    const existing = await pool.query(
      'SELECT * FROM weekly_prescriptions WHERE patient_id=$1 AND week_number=$2',
      [patId, weekNo]
    );

    let rxRes;
    if (existing.rowCount) {
      // Record already exists — UPDATE it in place
      if (existing.rows[0].status === 'APPROVED') {
        // Reset the manufacturing job so store cannot print until re-approved
        await pool.query(
          `UPDATE manufacturing_jobs SET status='APPROVED', batch_no=NULL,
            mfg_date=NULL, exp_date=NULL, ${PRICE_RESET_SQL}, updated_at=NOW()
           WHERE id=$1`,
          ['wxjob_' + patId + '_w' + weekNo]
        ).catch(() => {});
      }
      const _wasApprovedRegen = existing.rows[0].status === 'APPROVED';
      rxRes = await pool.query(
        `UPDATE weekly_prescriptions
           SET monitoring_log_id=$1, batch_code=$2, clinical_params=$3,
               targets=$4, baseline_snapshot=$5, status='PENDING_REVIEW',
               approved_at = CASE WHEN $8::bool THEN NULL ELSE approved_at END,
               approved_by = CASE WHEN $8::bool THEN NULL ELSE approved_by END,
               previously_approved_at = CASE WHEN $8::bool THEN $9 ELSE previously_approved_at END,
               reopened_at = CASE WHEN $8::bool THEN NOW() ELSE reopened_at END,
               updated_at=NOW()
         WHERE patient_id=$6 AND week_number=$7
         RETURNING *`,
        [monitoringLogId, batchCode, JSON.stringify(data), JSON.stringify(targets),
         JSON.stringify(baselineSnap), patId, weekNo,
         _wasApprovedRegen, existing.rows[0].approved_at]
      );
    } else {
      // No record yet — INSERT fresh
      rxRes = await pool.query(
        `INSERT INTO weekly_prescriptions
           (patient_id, week_number, monitoring_log_id, batch_code,
            clinical_params, targets, baseline_snapshot, status, created_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,'PENDING_REVIEW',$8)
         RETURNING *`,
        [patId, weekNo, monitoringLogId, batchCode,
         JSON.stringify(data), JSON.stringify(targets),
         JSON.stringify(baselineSnap), req.user.id]
      );
    }
    res.json(rxRes.rows[0]);
  } catch(e) { console.error('[generate-weekly-rx] Error:', e); res.status(500).json({ error: e.message }); }
});

// Weekly prescriptions — list for a patient
app.get('/api/patients/:id/weekly-prescriptions', authenticateToken, async (req, res) => {
  try {
    const r = await pool.query(
      `SELECT * FROM weekly_prescriptions WHERE patient_id=$1 ORDER BY week_number ASC`,
      [req.params.id]
    );
    res.json(r.rows);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// Doctor adjusts targets (still PENDING_REVIEW)
app.put('/api/weekly-prescriptions/:id', authenticateToken, async (req, res) => {
  const { targets, notes } = req.body;
  // Merge, never replace. The edit panel posts only the fields a doctor can
  // change; a wholesale replace silently dropped every other key the engine had
  // computed — oralKcal, suppKcal, suppProtein, oralPct — and with them any
  // ability to report what was actually delivered. Keys the client did send
  // still win, so an edit still edits.
  let prevTargets = {};
  try {
    const prev = await pool.query('SELECT targets FROM weekly_prescriptions WHERE id=$1', [req.params.id]);
    if (prev.rowCount && prev.rows[0].targets) {
      prevTargets = typeof prev.rows[0].targets === 'string'
        ? JSON.parse(prev.rows[0].targets) : prev.rows[0].targets;
    }
  } catch (e) { prevTargets = {}; }
  const updatedTargets = Object.assign({}, prevTargets, targets || {});
  if (updatedTargets.suppKcal && updatedTargets.suppProtein) {
    updatedTargets.recipe = calcWeeklyRecipe(
      updatedTargets.suppKcal, updatedTargets.suppProtein, updatedTargets.formulation || 'Standard',
      { plan: updatedTargets.proteinPlan, soyFree: updatedTargets.proteinSoyFree }
    );
  }
  try {
    const r = await pool.query(
      `UPDATE weekly_prescriptions SET targets=$1, notes=$2, updated_at=NOW()
       WHERE id=$3 RETURNING *`,
      [JSON.stringify(updatedTargets), notes || null, req.params.id]
    );
    if (!r.rowCount) return res.status(404).json({ error: 'Not found' });
    res.json(r.rows[0]);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// Doctor approves → status APPROVED → creates manufacturing job
app.post('/api/weekly-prescriptions/:id/approve', authenticateToken, async (req, res) => {
  try {
    const rxRes = await pool.query('SELECT * FROM weekly_prescriptions WHERE id=$1', [req.params.id]);
    if (!rxRes.rowCount) return res.status(404).json({ error: 'Not found' });
    const rx = rxRes.rows[0];

    // The queue disables the Approve button on an incomplete week, but the UI is
    // not the enforcement point — a stale tab, a second browser or a direct call
    // would otherwise still push an unworked-up week into manufacturing.
    // Validate against the LIVE weekly entry, not the copy stored on the
    // prescription when it was generated. The stored copy goes stale the moment
    // the doctor edits the entry, which made a filled-in value still read as
    // missing. Prefer the linked log, else the newest weekly log for that week.
    let _liveParams = rx.clinical_params;
    try {
      const lg = (await pool.query(
        `SELECT data FROM monitoring_logs
          WHERE (id = $1 OR (patient_id = $2 AND type='weekly'))
          ORDER BY (id = $1) DESC, recorded_at DESC`,
        [rx.monitoring_log_id || -1, rx.patient_id])).rows
        .map(r => (typeof r.data === 'string' ? (() => { try { return JSON.parse(r.data); } catch (e) { return {}; } })() : (r.data || {})))
        .find(d => rx.monitoring_log_id ? true : parseInt(d.week, 10) === rx.week_number);
      if (lg && Object.keys(lg).length) {
        _liveParams = lg;
        // Keep the prescription's copy in step so the queue and reports agree.
        if (JSON.stringify(lg) !== JSON.stringify(rx.clinical_params)) {
          await pool.query('UPDATE weekly_prescriptions SET clinical_params=$1, updated_at=NOW() WHERE id=$2',
            [JSON.stringify(lg), rx.id]).catch(() => {});
        }
      }
    } catch (e) { console.warn('live weekly params lookup:', e.message); }
    const _missing = missingWeeklyFields(_liveParams);
    if (_missing.length) {
      return res.status(400).json({
        error: 'INCOMPLETE_WEEKLY_DATA',
        missingFields: _missing,
        message: 'This week cannot be approved yet — ' + _missing.join(', ')
               + (_missing.length === 1 ? ' is' : ' are') + ' missing from the weekly entry.'
      });
    }

    // Mark approved
    await pool.query(
      `UPDATE weekly_prescriptions
          SET status='APPROVED', approved_at=NOW(), approved_by=$1,
              reopened_at=NULL, updated_at=NOW()
        WHERE id=$2`,
      [req.user.id, rx.id]
    );

    // Get store_id for this patient from their original manufacturing job
    const jobRow = await pool.query(
      `SELECT store_id, doctor_id FROM manufacturing_jobs WHERE patient_id=$1 ORDER BY created_at ASC LIMIT 1`,
      [rx.patient_id]
    );
    const storeId  = jobRow.rows[0] ? jobRow.rows[0].store_id  : null;
    const doctorId = jobRow.rows[0] ? jobRow.rows[0].doctor_id : req.user.id;

    // Insert as manufacturing job with weekly batch code
    const jobId = 'wxjob_' + rx.patient_id + '_w' + rx.week_number;
    await pool.query(
      `INSERT INTO manufacturing_jobs (id, patient_id, store_id, doctor_id, status, batch_no, history)
       VALUES ($1,$2,$3,$4,'APPROVED',$5,$6)
       ON CONFLICT (id) DO UPDATE SET status='APPROVED', batch_no=$5, ${PRICE_RESET_SQL}, updated_at=NOW()`,
      [jobId, rx.patient_id, storeId, doctorId, rx.batch_code,
       JSON.stringify([{ status:'APPROVED', at: new Date().toISOString(), note: `Week ${rx.week_number} prescription` }])]
    );

    res.json({ success: true, batchCode: rx.batch_code, jobId });
    recordEvent({ type: 'rx_approved', title: '✅ Weekly prescription approved',
      body: `{actor} approved Week ${rx.week_number} for {patient}. It goes to the store for pricing.`,
      patientId: rx.patient_id, jobId, user: req.user });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// Admin: all weekly prescriptions across all patients
app.get('/api/weekly-prescriptions', authenticateToken, async (req, res) => {
  const role = req.user && req.user.role;
  if (!['ADMIN','SUPER_ADMIN'].includes(role)) return res.status(403).json({ error: 'Admin only' });
  try {
    const r = await pool.query(
      `SELECT wp.*, p.name AS patient_name,
              te.study_id
       FROM weekly_prescriptions wp
       LEFT JOIN patients p ON p.id = wp.patient_id
       LEFT JOIN trial_enrollments te ON te.patient_id = wp.patient_id
       ORDER BY wp.patient_id, wp.week_number ASC`
    );
    res.json(r.rows);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── Doctor's weekly work queue ────────────────────────────────────────────
// Answers "what needs me this week?" in ONE request. Previously the dashboard
// had no weekly signal at all and the only way to find out was to open each
// patient profile in turn; doing that from the client would mean two requests
// per patient, so the aggregation lives here: three queries total regardless
// of how many patients the doctor has.
//
// Shape is deliberately flat and pre-computed — the dashboard renders it
// directly without re-deriving weeks, due dates or warnings client-side.
app.get('/api/doctor/weekly-queue', authenticateToken, async (req, res) => {
  try {
    const role = req.user && req.user.role;
    const isAdmin = ['ADMIN', 'SUPER_ADMIN'].includes(role);
    // Assistants act on behalf of their doctor; the client passes ?doctorId=.
    const docId = req.query.doctorId || req.user.id;

    const patRes = isAdmin && !req.query.doctorId
      ? await pool.query(
          `SELECT id, name, uhic, cancer, weight, full_data, created_date FROM patients`)
      : await pool.query(
          `SELECT id, name, uhic, cancer, weight, full_data, created_date
             FROM patients
            WHERE assigned_doctor_id = $1 OR full_data->>'assignedDoctorId' = $1`, [docId]);

    const patients = patRes.rows;
    if (!patients.length) return res.json({ patients: [], generatedAt: new Date().toISOString() });

    const ids = patients.map(p => p.id);
    const now0 = Date.now();
    // A closed patient must leave the queue. Nagging about someone who was
    // discharged three weeks ago is how staff learn to ignore the queue, and
    // an ignored queue is worse than no queue.
    const [logRes, rxRes, closureRes, settingsRes, jobRes] = await Promise.all([
      pool.query(
        `SELECT patient_id, type, recorded_at, data FROM monitoring_logs
          WHERE patient_id = ANY($1) ORDER BY recorded_at ASC`, [ids]),
      pool.query(
        `SELECT id, patient_id, week_number, status, batch_code, targets, notes,
                monitoring_log_id, created_at, approved_at, clinical_params,
                reopened_at, previously_approved_at
           FROM weekly_prescriptions
          WHERE patient_id = ANY($1) ORDER BY week_number ASC`, [ids]),
      pool.query(
        `SELECT patient_id, reason, note, closed_by, closed_by_role, closed_at, confirmed_at
           FROM patient_closures
          WHERE patient_id = ANY($1) AND reopened_at IS NULL`, [ids]),
      pool.query('SELECT lost_threshold_days FROM pilot_settings WHERE id=1'),
      pool.query('SELECT patient_id, status, history FROM manufacturing_jobs WHERE patient_id = ANY($1)', [ids])
    ]);

    // When the patient's first product left the store. Monitoring only makes
    // sense once they are on the supplement: Week 1 is due 7 days after that,
    // daily logs from that day. A patient created today is not "due" anything.
    const firstDispatchBy = {};
    jobRes.rows.forEach(j => {
      const h = Array.isArray(j.history) ? j.history : [];
      let at = null;
      h.forEach(e => { if (e && ['DISPATCHED', 'DELIVERED'].includes(String(e.status || '').toUpperCase()) && e.at) {
        const t = new Date(e.at).getTime(); if (!isNaN(t) && (at === null || t < at)) at = t; } });
      if (at === null && ['DISPATCHED', 'DELIVERED'].includes(String(j.status || '').toUpperCase())) at = now0;
      if (at !== null && (firstDispatchBy[j.patient_id] == null || at < firstDispatchBy[j.patient_id])) firstDispatchBy[j.patient_id] = at;
    });

    const closedBy = {};
    closureRes.rows.forEach(c => { closedBy[c.patient_id] = c; });
    // The hospital's own definition of "this patient may be lost" already
    // exists as a setting; use it rather than inventing a second threshold.
    const lostThreshold = (settingsRes.rows[0] && settingsRes.rows[0].lost_threshold_days) || 14;

    // `data` is JSONB but older rows were written as a JSON string — the profile
    // page carries the same guard. Parse defensively rather than trusting the type.
    const asObj = d => {
      if (!d) return {};
      if (typeof d === 'string') { try { return JSON.parse(d); } catch (e) { return {}; } }
      return d;
    };
    const num = v => {
      if (v === null || v === undefined || v === '') return null;
      const n = parseFloat(v);
      return isNaN(n) ? null : n;
    };

    const weeklyBy = {}, dailyBy = {}, rxBy = {};
    logRes.rows.forEach(l => {
      const bucket = (l.type === 'daily') ? dailyBy : weeklyBy;
      (bucket[l.patient_id] = bucket[l.patient_id] || []).push({ at: l.recorded_at, d: asObj(l.data) });
    });
    rxRes.rows.forEach(r => { (rxBy[r.patient_id] = rxBy[r.patient_id] || []).push(r); });

    const DAY = 86400000;
    const now = Date.now();
    const SUPPLY_DAYS = 7;   // one weekly batch = 7 days of cover
    // Review cycle: the first assessment is due 5 days after the product is
    // dispatched, and each next one 5 days after the previous entry — so the
    // new batch can be prescribed before the 7-day supply runs out.
    // Admin-configurable via engine_formulas.review_interval_days.
    let REVIEW_DAYS = 5;
    try {
      const rf = await pool.query("SELECT value FROM engine_formulas WHERE id='review_interval_days'");
      const v = rf.rows[0] ? parseInt(rf.rows[0].value, 10) : NaN;
      if (v >= 1 && v <= 30) REVIEW_DAYS = v;
    } catch (e) {}

    const out = patients.map(p => {
      const closure = closedBy[p.id] || null;
      const fd      = p.full_data || {};
      const weeks   = weeklyBy[p.id] || [];
      const dailies = dailyBy[p.id]  || [];
      const rxs     = rxBy[p.id]     || [];

      // ── Week history, one entry per weekly log ──
      // week_number is doctor-typed and carries no uniqueness or contiguity
      // guarantee, so fall back to the log's ordinal position when it's absent.
      const history = weeks.map((w, i) => ({
        wk:      num(w.d.week) != null ? num(w.d.week) : (i + 1),
        at:      w.at,
        weight:  num(w.d.weight),
        bmi:     num(w.d.bmi),
        muac:    num(w.d.muac),
        ecog:    num(w.d.ecog),
        grip:    num(w.d.handGrip),
        albumin: num(w.d.albumin),
        crp:     num(w.d.crp),
        glucose: num(w.d.glucose),
        creatinine: num(w.d.creatinine),
        urea:    num(w.d.urea),
        oral:    num(w.d.oralIntake),
        adh:     num(w.d.compliance),
        kcalkg:  num(w.d.kcalPerKg),
        protkg:  num(w.d.proteinPerKg)
      }));

      const lastWeekly = weeks.length ? weeks[weeks.length - 1] : null;
      const lastWeeklyAt = lastWeekly ? lastWeekly.at : null;
      const daysSinceWeekly = lastWeeklyAt
        ? Math.floor((now - new Date(lastWeeklyAt).getTime()) / DAY) : null;
      const currentWeek = history.length
        ? history.reduce((m, h) => Math.max(m, h.wk || 0), 0) : 0;

      const lastDaily = dailies.length ? dailies[dailies.length - 1] : null;
      const daysSinceDaily = lastDaily
        ? Math.floor((now - new Date(lastDaily.at).getTime()) / DAY) : null;

      // ── Prescription state ──
      const approvedRows = rxs.filter(r => r.status === 'APPROVED');
      const lastApproved = approvedRows.length
        ? approvedRows[approvedRows.length - 1] : null;

      // A pending week that a LATER week has already overtaken is dead weight.
      // Nothing expires from this queue on its own, so an unapproved week 3 sits
      // there for months after week 4 was approved and dispensed — the patient is
      // not actually waiting on anything, and the count says otherwise. Approving
      // it now would manufacture a batch from month-old measurements.
      // Only a week that nothing newer has replaced is a real approval.
      const _wkNo = r => {
        const n = parseFloat(r.week_number);
        return isNaN(n) ? -Infinity : n;
      };
      const maxApprovedWeek = approvedRows.length
        ? Math.max(...approvedRows.map(_wkNo)) : -Infinity;

      const pendingAll = rxs.filter(r => r.status === 'PENDING_REVIEW')
                            .sort((a, b) => _wkNo(b) - _wkNo(a));
      const pendingLive = pendingAll.filter(r => _wkNo(r) > maxApprovedWeek);
      // Kept visible in the payload rather than silently dropped: the rows are
      // still PENDING_REVIEW in the database, and staff should be able to see
      // that they were skipped rather than wonder where they went.
      const supersededWeeks = pendingAll
        .filter(r => _wkNo(r) <= maxApprovedWeek)
        .map(r => r.week_number);

      const pendingRow = pendingLive[0] || null;

      // ── Warnings shown inline on the queue row ──
      // The doctor approves from the row, so anything that should give them
      // pause has to be visible there. Thresholds follow the same ESPEN/GLIM
      // logic the risk panel uses.
      const warnings = [];
      const h1 = history[history.length - 1], h0 = history[history.length - 2];
      if (h1 && h0 && h1.weight != null && h0.weight != null) {
        const drop = h0.weight - h1.weight;
        const pct  = h0.weight ? (drop / h0.weight) * 100 : 0;
        if (drop >= 2 || pct >= 5) {
          warnings.push({ level: 'high', label: 'WEIGHT',
            detail: `down ${drop.toFixed(1)} kg (${pct.toFixed(1)}%) since week ${h0.wk}` });
        }
      }
      if (h1 && h1.adh != null && h1.adh < 70) {
        warnings.push({ level: 'high', label: 'ADHERENCE', detail: `${h1.adh}%` });
      } else if (h1 && h0 && h1.adh != null && h0.adh != null && (h0.adh - h1.adh) >= 15) {
        warnings.push({ level: 'watch', label: 'ADHERENCE',
          detail: `${h1.adh}%, down from ${h0.adh}%` });
      }
      if (h1 && h0 && h1.ecog != null && h0.ecog != null && h1.ecog > h0.ecog) {
        warnings.push({ level: 'watch', label: 'ECOG', detail: `${h0.ecog} → ${h1.ecog}` });
      }
      // Same renal thresholds the client-side fallback in the profile applies.
      if (h1 && ((h1.creatinine != null && h1.creatinine >= 1.3) || (h1.urea != null && h1.urea >= 50))) {
        warnings.push({ level: 'high', label: 'RENAL',
          detail: [h1.creatinine != null ? `creatinine ${h1.creatinine}` : null,
                   h1.urea != null ? `urea ${h1.urea}` : null].filter(Boolean).join(', ') });
      }
      if (h1 && h1.oral != null && h1.oral <= 30) {
        warnings.push({ level: 'high', label: 'INTAKE', detail: `oral ${h1.oral}%` });
      }
      const t = pendingRow && pendingRow.targets;
      if (t && t.manuallyAdjusted) {
        warnings.push({ level: 'watch', label: 'ADJUSTED', detail: 'targets manually changed' });
      }

      // ── Supply cover, for the "no product going out" case ──
      const lastApprovedAt = lastApproved
        ? (lastApproved.approved_at || lastApproved.created_at) : null;
      const supplyDaysLeft = lastApprovedAt
        ? SUPPLY_DAYS - Math.floor((now - new Date(lastApprovedAt).getTime()) / DAY)
        : null;

      return {
        id: p.id,
        name: p.name,
        uhic: p.uhic || fd.uhic || null,
        cancer: p.cancer || fd.cancer || null,
        currentWeek,
        history,
        lastWeeklyAt,
        daysSinceWeekly,
        // No due-date column exists; a week of cover from the last log is the
        // same rule the profile page's overdue banner already uses.
        dueAt: lastWeeklyAt
          ? new Date(new Date(lastWeeklyAt).getTime() + REVIEW_DAYS * DAY).toISOString() : null,
        weeklyOverdue: daysSinceWeekly == null ? false : daysSinceWeekly >= REVIEW_DAYS,
        reviewIntervalDays: REVIEW_DAYS,
        neverMonitored: weeks.length === 0,
        firstDispatchAt: firstDispatchBy[p.id] != null ? new Date(firstDispatchBy[p.id]).toISOString() : null,
        week1DueAt: firstDispatchBy[p.id] != null ? new Date(firstDispatchBy[p.id] + REVIEW_DAYS * DAY).toISOString() : null,
        // Week 1 is due only once the patient has been on the supplement for 7 days.
        week1Due: weeks.length === 0 && firstDispatchBy[p.id] != null && now >= firstDispatchBy[p.id] + REVIEW_DAYS * DAY,
        // Daily logs are expected only after the product has been dispatched.
        dailyExpected: firstDispatchBy[p.id] != null,
        daysSinceDaily,
        dailyGap: daysSinceDaily == null ? null : daysSinceDaily,
        pendingRx: pendingRow ? {
          id: pendingRow.id,
          weekNumber: pendingRow.week_number,
          status: pendingRow.status,
          batchCode: pendingRow.batch_code,
          targets: pendingRow.targets || {},
          notes: pendingRow.notes,
          createdAt: pendingRow.created_at,
          // Set only when this week had already been approved and the log was
          // then edited. The row reads as re-approval rather than first review.
          reopenedAt: pendingRow.reopened_at || null,
          previouslyApprovedAt: pendingRow.previously_approved_at || null,
          // Which required weekly values are still blank. Empty means approvable.
          // Same rule as the approve endpoint: judge completeness on the live
          // weekly entry for that week, not the copy stored when generated.
          missingFields: missingWeeklyFields(
            (weeks.find(w => parseInt((w.d || {}).week, 10) === pendingRow.week_number) || {}).d
            || pendingRow.clinical_params),
          // The values already captured for this week, so the dashboard can
          // reopen a half-finished entry with what was entered still in place
          // rather than making the nurse retype it.
          clinicalParams: asObj(pendingRow.clinical_params)
        } : null,
        lastApproved: lastApproved ? {
          weekNumber: lastApproved.week_number,
          batchCode: lastApproved.batch_code,
          approvedAt: lastApproved.approved_at
        } : null,
        // Weeks still PENDING_REVIEW that a later approved week has overtaken.
        supersededWeeks,
        supplyDaysLeft,
        warnings,
        // Closure state travels with the row so the dashboard can drop the
        // patient from the queue and, when an assistant recorded it, surface
        // it to the doctor for confirmation instead of silently accepting it.
        closed: !!closure,
        closure: closure ? {
          reason: closure.reason,
          label: (CLOSURE_REASONS[closure.reason] || {}).label || closure.reason,
          note: closure.note,
          closedBy: closure.closed_by,
          closedByRole: closure.closed_by_role,
          closedAt: closure.closed_at,
          needsConfirmation: !closure.confirmed_at
        } : null,
        // Past this, the queue stops merely nagging and asks whether the
        // patient is still active at all.
        askIfStillActive: !closure && daysSinceWeekly !== null && daysSinceWeekly >= lostThreshold,
        lostThresholdDays: lostThreshold
      };
    });

    res.json({
      patients: out.filter(p => !p.closed),
      // Returned separately so the doctor can still see and confirm or reopen
      // a closure without it sitting in the work queue.
      closed: out.filter(p => p.closed),
      lostThresholdDays: lostThreshold,
      generatedAt: new Date().toISOString()
    });
  } catch (e) {
    console.error('[weekly-queue]', e);
    res.status(500).json({ error: e.message });
  }
});

// ── MUST rescreen: the baseline screen and the latest weekly one ──────────
// The Calculation Trace on the patient report carried a single MUST score,
// computed once from the intake record, so a report printed at discharge still
// showed the patient's risk on the day they joined. This returns both ends
// from the same calculation so the trace can show the rescreen beside it.
//
// The weight-loss component is re-derived against usual weight — captured at
// intake as weight 6 months prior, which is the reference period MUST asks for
// — so the later score is a genuine rescreen and not an approximation over the
// pilot window.
app.get('/api/patients/:id/must', authenticateToken, async (req, res) => {
  try {
    const pid = req.params.id;
    const p = (await pool.query(
      'SELECT ' + MUST_PATIENT_COLUMNS + ' FROM patients WHERE id = $1', [pid])).rows[0];
    if (!p) return res.status(404).json({ error: 'Patient not found' });

    const formulas = await loadFormulaConstants(pool);
    const baseline = computeMust(mustInputs(p), formulas);

    const logs = (await pool.query(
      `SELECT id, recorded_at, data FROM monitoring_logs
        WHERE patient_id = $1 AND type = 'weekly' ORDER BY recorded_at ASC`, [pid])).rows;
    const last = logs.length ? logs[logs.length - 1] : null;
    let data = last ? last.data : null;
    if (typeof data === 'string') { try { data = JSON.parse(data); } catch (_) { data = null; } }

    const latest = last ? computeMust(mustInputs(p, data || {}), formulas) : null;
    const fd = p.full_data || {};

    res.json({
      patientId: pid,
      baseline,
      latest,
      latestAt: last ? last.recorded_at : null,
      latestWeek: last ? ((data && data.week != null) ? data.week : logs.length) : null,
      weeks: logs.length,
      // Flagged so the report can say the sarcopenia input is not fresh rather
      // than presenting a stale measurement as a current one.
      smiCarriedForward: !!(last && (p.smi != null ? p.smi : fd.smi))
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/patients/:id/monitoring', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM monitoring_logs WHERE patient_id = $1 ORDER BY recorded_at DESC LIMIT 90`,
      [req.params.id]
    );
    res.json(result.rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Edit an existing monitoring log entry (doctor correction)
app.put('/api/monitoring/:logId', authenticateToken, async (req, res) => {
  const { data } = req.body;
  if (!data) return res.status(400).json({ error: 'data required' });
  try {
    const result = await pool.query(
      `UPDATE monitoring_logs SET data=$1, recorded_by=$2 WHERE id=$3 RETURNING *`,
      [JSON.stringify(data), req.user.id, req.params.logId]
    );
    if (!result.rowCount) return res.status(404).json({ error: 'Log not found' });
    const log = result.rows[0];
    res.json(log);

    // The weekly prescription keeps its own copy of the week's readings
    // (clinical_params) taken when it was generated. Editing the log left that
    // copy stale, so a value the doctor had just filled in still read as
    // missing and the week could not be approved. Refresh the copy — and the
    // targets, since the readings drive them — for the week still in review.
    if (log.type === 'weekly') {
      (async () => {
        try {
          // Match on the log first, then fall back to this patient's week —
          // an older prescription may have been generated from a different log
          // for the same week, and that is the row the approval check reads.
          const _wk = parseInt((data && data.week) != null ? data.week : NaN, 10);
          const rx = (await pool.query(
            `SELECT id, patient_id, week_number, status FROM weekly_prescriptions
              WHERE monitoring_log_id=$1
                 OR ($2::text IS NOT NULL AND patient_id=$2 AND week_number=$3)
              ORDER BY (monitoring_log_id=$1) DESC, week_number DESC LIMIT 1`,
            [log.id, log.patient_id || null, isNaN(_wk) ? -1 : _wk])).rows[0];
          if (!rx || rx.status === 'APPROVED') return;   // approved weeks keep what was approved
          const patRow = (await pool.query('SELECT full_data, height, sex FROM patients WHERE id=$1', [rx.patient_id])).rows[0];
          const baseline = (patRow && patRow.full_data) || {};
          if (patRow && patRow.height != null) baseline.height = patRow.height;
          if (patRow && patRow.sex    != null) baseline.sex    = patRow.sex;
          const planRow = await pool.query(
            'SELECT final_plan, engine_output FROM nutrition_plans WHERE patient_id=$1 ORDER BY version DESC LIMIT 1', [rx.patient_id]);
          if (planRow.rowCount) {
            baseline.finalPlan    = planRow.rows[0].final_plan    || baseline.finalPlan;
            baseline.engineOutput = planRow.rows[0].engine_output || baseline.engineOutput;
          }
          const targets = calcWeeklyRxTargets(baseline, data, await loadFormulaConstants(pool));
          await pool.query(
            `UPDATE weekly_prescriptions
                SET clinical_params=$1, targets=COALESCE($2, targets),
                    monitoring_log_id=$4, updated_at=NOW()
              WHERE id=$3`,
            [JSON.stringify(data), targets ? JSON.stringify(targets) : null, rx.id, log.id]);
          console.log(`weekly Rx ${rx.id} (patient ${rx.patient_id} week ${rx.week_number}) refreshed from edited log ${log.id}`);
        } catch (e) { console.warn('weekly Rx refresh after log edit:', e.message); }
      })();
    }
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/monitoring/:logId', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      `DELETE FROM monitoring_logs WHERE id=$1 RETURNING id`,
      [req.params.logId]
    );
    if (!result.rowCount) return res.status(404).json({ error: 'Log not found' });
    res.json({ deleted: req.params.logId });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ───────────────────── Early-warning risk panel ───────────────────────────
// Surfaces the patients who are deteriorating RIGHT NOW, so a clinician doesn't
// have to open 40 charts to find the 3 that matter. Thresholds follow ESPEN /
// GLIM malnutrition criteria rather than arbitrary cut-offs:
//   • unintentional loss >2%/week or >5%/month  → malnutrition red flag
//   • albumin falling while CRP rises           → inflammatory catabolism,
//     which nutrition alone will not reverse (needs clinical review)
//   • intake/adherence collapse                 → the plan isn't reaching them
// Every flag returns its own reason string; nothing is a black box.
app.get('/api/risk-panel', authenticateToken, async (req, res) => {
  try {
    const role = req.user && req.user.role;
    const isAdmin = ['ADMIN', 'SUPER_ADMIN'].includes(role);

    // Doctors see their own list; admins see everyone.
    let patRes;
    if (isAdmin) {
      patRes = await pool.query(
        `SELECT id, name, uhic, cancer, weight, albumin, crp, ecog_status, full_data,
                assigned_doctor_id, created_date
           FROM patients`);
    } else {
      const docId = req.user.id;
      patRes = await pool.query(
        `SELECT id, name, uhic, cancer, weight, albumin, crp, ecog_status, full_data,
                assigned_doctor_id, created_date
           FROM patients
          WHERE assigned_doctor_id = $1 OR full_data->>'assignedDoctorId' = $1`, [docId]);
    }
    const patients = patRes.rows;
    if (!patients.length) return res.json({ patients: [] });

    const ids = patients.map(p => p.id);
    // A withdrawn patient must raise no events anywhere on the doctor's
    // dashboard. The weekly queue already drops them; this panel read the
    // patients table directly and kept flagging people who had left the
    // programme — deteriorating numbers they are no longer being treated for.
    const closedRes = await pool.query(
      `SELECT patient_id FROM patient_closures
        WHERE patient_id = ANY($1) AND reopened_at IS NULL`, [ids]);
    const closedIds = new Set(closedRes.rows.map(r => r.patient_id));

    const logRes = await pool.query(
      `SELECT patient_id, type, recorded_at, data FROM monitoring_logs
        WHERE patient_id = ANY($1) ORDER BY recorded_at ASC`, [ids]);

    const weeklyBy = {}, dailyBy = {};
    logRes.rows.forEach(l => {
      const bucket = (l.type === 'daily') ? dailyBy : weeklyBy;
      (bucket[l.patient_id] = bucket[l.patient_id] || []).push({
        at: l.recorded_at, ...(l.data || {})
      });
    });

    // A stored 0 for a lab or anthropometric measure means "not recorded" —
    // CRP is never truly 0 and a MUAC/weight of 0 is impossible. Without this
    // the panel raised "Low albumin 0 g/dL" style flags on missing data.
    const num = (v, key) => {
      if (v === null || v === undefined || v === '') return null;
      const n = parseFloat(v);
      if (isNaN(n)) return null;
      if (n === 0 && key && ['crp','muac','albumin','weight','bmi','handGrip'].includes(key)) return null;
      return n;
    };
    const DAY = 86400000;

    const out = patients.map(p => {
      const fd = p.full_data || {};
      const weeks = weeklyBy[p.id] || [];
      const days  = dailyBy[p.id]  || [];
      const flags = [];
      let score = 0;

      const baseWeight  = num(p.weight,'weight')   != null ? num(p.weight,'weight')   : num(fd.weight,'weight');
      const baseAlbumin = num(p.albumin,'albumin') != null ? num(p.albumin,'albumin') : num(fd.albumin,'albumin');
      const baseCrp     = num(p.crp,'crp')         != null ? num(p.crp,'crp')         : num(fd.crp,'crp');

      const last  = weeks.length ? weeks[weeks.length - 1] : null;
      const prev  = weeks.length > 1 ? weeks[weeks.length - 2] : null;

      // ── Weight trajectory (ESPEN/GLIM) ──
      // Scored by RATE, not cumulative total. Losing 4% over 7 weeks (0.6%/wk)
      // is unremarkable in oncology; losing 4% over 2 weeks (2%/wk) is an
      // emergency. Ranking on the total alone made those look identical and
      // flooded the panel with slow, stable drifters.
      const lastW = last ? num(last.weight,'weight') : null;
      if (lastW != null && baseWeight) {
        // Measure from the earliest known observation, not blindly from
        // created_date: a patient enrolled and weighed the same day yields a
        // 1-day window, which turns a 6% loss into a nonsense "43%/week".
        const firstWeekAt = weeks.length ? weeks[0].at : null;
        const candidates = [p.created_date, firstWeekAt]
          .filter(Boolean)
          .map(d => new Date(d).getTime())
          .filter(t => !isNaN(t));
        const startMs = candidates.length ? Math.min.apply(null, candidates) : null;
        const endMs = last.at ? new Date(last.at).getTime() : null;
        const elapsedDays = (startMs && endMs && endMs > startMs) ? (endMs - startMs) / DAY : null;
        const lossPct = (baseWeight - lastW) / baseWeight * 100;

        if (lossPct > 0) {
          const since = lossPct.toFixed(1) + '% since baseline';
          // Below ~7 days there aren't enough days to extrapolate a weekly rate
          // without wild error, so judge on the absolute loss instead.
          if (elapsedDays == null || elapsedDays < 7) {
            if (lossPct >= 5) {
              score += 30;
              flags.push({ level:'high', label:'Significant weight loss',
                detail: since + (elapsedDays ? ' over ' + Math.round(elapsedDays) + ' days' : '') });
            } else if (lossPct >= 2) {
              score += 12;
              flags.push({ level:'watch', label:'Weight declining', detail: since });
            }
          } else {
            const perWeek = lossPct / (elapsedDays / 7);
            const detail = perWeek.toFixed(1) + '%/week (' + since + ', over '
                         + Math.round(elapsedDays) + ' days)';
            if (perWeek >= 2) {
              score += 45;
              flags.push({ level:'critical', label:'Rapid weight loss',
                detail: detail + ' — exceeds the 2%/week malnutrition threshold' });
            } else if (perWeek >= 1.25) {
              score += 30;
              flags.push({ level:'high', label:'Accelerated weight loss',
                detail: detail + ' — above 5%/month' });
            }
            // Anything slower than 1.25%/week is background drift in an
            // advanced-cancer cohort. A 0.8%/week "watch" tier existed here but
            // produced rows no clinician would act on, so it was removed —
            // the panel should only carry things worth interrupting for.
          }
        }
      }

      // ── Albumin falling while CRP rises = inflammatory catabolism ──
      const lastAlb = last ? num(last.albumin,'albumin') : null;
      const prevAlb = prev ? num(prev.albumin,'albumin') : baseAlbumin;
      const lastCrp = last ? num(last.crp,'crp') : null;
      const prevCrp = prev ? num(prev.crp,'crp') : baseCrp;
      if (lastAlb != null && prevAlb != null && lastCrp != null && prevCrp != null
          && lastAlb < prevAlb && lastCrp > prevCrp) {
        score += 30;
        flags.push({ level:'critical', label:'Inflammatory catabolism',
          detail: 'Albumin ' + prevAlb + '→' + lastAlb + ' g/dL while CRP ' + prevCrp + '→' + lastCrp + ' mg/L — nutrition support alone may not reverse this' });
      } else if (lastAlb != null && lastAlb < 3.0) {
        score += 20;
        flags.push({ level:'high', label:'Low albumin',
          detail: lastAlb + ' g/dL — below 3.0 threshold' });
      }

      if (lastCrp != null && lastCrp > 50) {
        score += 10;
        flags.push({ level:'watch', label:'High inflammation', detail:'CRP ' + lastCrp + ' mg/L' });
      }

      // ── Intake / adherence collapse ──
      const lastOral = last ? num(last.oralIntake,'oralIntake') : null;
      const lastComp = last ? num(last.compliance,'compliance') : null;
      // Only SEVERE intake failure is flagged. In a head & neck / GI cohort,
      // eating 35-40% of requirement is the norm — it's why the patient is on
      // supplements at all — so alerting on it told the doctor nothing they
      // hadn't already assumed, and drowned the genuinely deteriorating cases.
      if (lastOral != null && lastOral < 30) {
        score += 30;
        flags.push({ level:'critical', label:'Severe intake failure',
          detail: lastOral + '% of requirement met orally' });
      }
      if (lastComp != null) {
        if (lastComp < 40)      { score += 20; flags.push({ level:'high',  label:'Supplement not being taken', detail: 'only ' + lastComp + '% consumed' }); }
        else if (lastComp < 60) { score += 10; flags.push({ level:'watch', label:'Low supplement compliance',  detail: lastComp + '% consumed' }); }
      }

      // ── ECOG deterioration ──
      const lastEcog = last ? num(last.ecog,'ecog') : null;
      const prevEcog = prev ? num(prev.ecog,'ecog') : num(p.ecog_status);
      if (lastEcog != null && prevEcog != null && lastEcog > prevEcog) {
        score += 15;
        flags.push({ level:'high', label:'Performance status worsening',
          detail: 'ECOG ' + prevEcog + ' → ' + lastEcog });
      }

      // ── Monitoring lapse ──
      // Kept OUT of the clinical score. Silence is a follow-up failure, not
      // deterioration — mixing them ranked out-of-contact patients above
      // actively deteriorating ones and muddied the clinical signal.
      const lastAnyAt = [last ? last.at : null, days.length ? days[days.length-1].at : null]
        .filter(Boolean).sort().pop();
      const daysSince = lastAnyAt ? Math.floor((Date.now() - new Date(lastAnyAt)) / DAY) : null;
      const lapsed = (daysSince != null && daysSince > 14) || lastAnyAt === null;

      const level = score >= 45 ? 'critical' : score >= 20 ? 'high' : score > 0 ? 'watch' : 'ok';
      return {
        patientId: p.id, name: p.name, uhic: p.uhic, cancer: p.cancer,
        doctorId: p.assigned_doctor_id || fd.assignedDoctorId || null,
        weeksMonitored: weeks.length,
        lastEntryAt: lastAnyAt || null,
        daysSinceLastEntry: daysSince,
        lapsed,
        score, level, flags
      };
    })
    .filter(r => r.flags.length || r.lapsed)
    .filter(r => !closedIds.has(r.patientId))
    .sort((a,b) => b.score - a.score);

    res.json({ patients: out, generatedAt: new Date().toISOString() });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ───────────────────────── Clinical Trials module ─────────────────────────
// Pilot settings (target size, definition of "completed", lost-to-follow-up window)
app.get('/api/pilot-settings', authenticateToken, async (req, res) => {
  try { const r = await pool.query('SELECT * FROM pilot_settings WHERE id=1'); res.json(r.rows[0] || {}); }
  catch (e) { res.status(500).json({ error: e.message }); }
});
app.put('/api/pilot-settings', authenticateToken, requireAdminOnly, async (req, res) => {
  const { target_patients, pilot_weeks, lost_threshold_days } = req.body || {};
  try {
    await pool.query(
      `UPDATE pilot_settings SET target_patients=COALESCE($1,target_patients),
         pilot_weeks=COALESCE($2,pilot_weeks), lost_threshold_days=COALESCE($3,lost_threshold_days) WHERE id=1`,
      [target_patients, pilot_weeks, lost_threshold_days]);
    const r = await pool.query('SELECT * FROM pilot_settings WHERE id=1');
    res.json(r.rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Clinical Trials READ access covers doctors as well as admins — clinicians
// review the whole cohort, not just their own patients. Store roles are still
// excluded: they handle manufacturing and have no need for outcome data.
// Client-side auth.requireRole() only hides the UI; this is the real guard.
// NOTE ON THE NAME: this admits DOCTOR as well as ADMIN and SUPER_ADMIN. It is
// "admin or clinician", not "admin". Nine study-wide endpoints use it, which
// means any doctor can currently read and export the entire pilot cohort —
// including patients who are not theirs. That may be intended for a small
// single-site pilot, but it should be a decision rather than a side effect of
// the name. Use requireAdminOnly for anything that must exclude clinicians.
// Doctors (and their assistants) see only their own caseload in the trial
// pages. Admins see everyone. req.caseload = Set of patient ids, or undefined.
function _scopeIds(req, ids) {
  return req.caseload ? ids.filter(id => req.caseload.has(String(id))) : ids;
}
app.use('/api/trials', authenticateToken, async (req, res, next) => {
  const u = req.user || {};
  if (u.role !== 'DOCTOR' && u.role !== 'ASSISTANT') return next();
  try {
    const docId = u.role === 'ASSISTANT' ? (_mappedDoctor(u.id) || u.id) : u.id;
    const r = await pool.query(
      `SELECT p.id FROM patients p WHERE (p.assigned_doctor_id = $1 OR p.full_data->>'assignedDoctorId' = $1
         OR p.created_by_id = $2 OR p.created_by_user_id = $2)`, [docId, u.id]);
    req.caseload = new Set(r.rows.map(x => String(x.id)));
    next();
  } catch (e) { res.status(500).json({ error: e.message }); }
});

function requireAdmin(req, res, next) {
  const role = req.user && req.user.role;
  // Assistants may VIEW trial data (same as their doctor) but not change it.
  const ok = ['ADMIN', 'SUPER_ADMIN', 'DOCTOR'].includes(role)
          || (role === 'ASSISTANT' && req.method === 'GET');
  if (!ok) {
    return res.status(403).json({ error: role === 'ASSISTANT' ? 'Only the doctor or an admin can change trial records.' : 'Not permitted' });
  }
  next();
}

// Changes that alter study-wide state stay restricted to admins.
function requireAdminOnly(req, res, next) {
  const role = req.user && req.user.role;
  if (!['ADMIN', 'SUPER_ADMIN'].includes(role)) {
    return res.status(403).json({ error: 'Admin only' });
  }
  next();
}

// Manually flag a patient as Withdrawn (the one trial status that can't be auto-derived)
app.post('/api/trials/:patientId/withdraw', authenticateToken, requireAdmin, async (req, res) => {
  if (req.caseload && !req.caseload.has(String(req.params.patientId))) return res.status(404).json({ error: 'Patient not found' });
  const { reason } = req.body || {};
  try {
    await pool.query(
      'UPDATE trial_enrollments SET withdrawn_at=NOW(), withdrawn_reason=$2 WHERE patient_id=$1',
      [req.params.patientId, reason || null]);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
// Un-withdraw (correction)
app.post('/api/trials/:patientId/reinstate', authenticateToken, requireAdmin, async (req, res) => {
  if (req.caseload && !req.caseload.has(String(req.params.patientId))) return res.status(404).json({ error: 'Patient not found' });
  try {
    await pool.query('UPDATE trial_enrollments SET withdrawn_at=NULL, withdrawn_reason=NULL WHERE patient_id=$1', [req.params.patientId]);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Enrollment Log — auto-enrols pilot patients (those approved into production), assigns
// Study IDs, and returns each with a fully-derived trial status + key dates.
app.get('/api/trials', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const settings = (await pool.query('SELECT * FROM pilot_settings WHERE id=1')).rows[0]
      || { pilot_weeks: 6, lost_threshold_days: 14, target_patients: 30 };

    // Pilot cohort = patients who have a manufacturing job (i.e. approved into production).
    const jobsRes = await pool.query('SELECT patient_id, status, history, mfg_date, batch_no, created_at FROM manufacturing_jobs');
    const jobByPatient = {};
    jobsRes.rows.forEach(j => {
      const prev = jobByPatient[j.patient_id];
      if (!prev || new Date(j.created_at) > new Date(prev.created_at)) jobByPatient[j.patient_id] = j;
    });
    const ids = _scopeIds(req, Object.keys(jobByPatient));
    if (!ids.length) return res.json({ settings, patients: [] });

    const patRes = await pool.query('SELECT id, uhic, name, cancer, created_date FROM patients WHERE id = ANY($1)', [ids]);
    const patById = {}; patRes.rows.forEach(p => { patById[p.id] = p; });

    const monRes = await pool.query(
      `SELECT patient_id, COUNT(*)::int AS wk_count, MAX(recorded_at) AS last_at
         FROM monitoring_logs WHERE type='weekly' AND patient_id = ANY($1) GROUP BY patient_id`, [ids]);
    const monByPatient = {}; monRes.rows.forEach(m => { monByPatient[m.patient_id] = m; });

    const trialRes = await pool.query('SELECT * FROM trial_enrollments WHERE patient_id = ANY($1)', [ids]);
    const trialByPatient = {}; trialRes.rows.forEach(t => { trialByPatient[t.patient_id] = t; });

    // created_date is a free-form VARCHAR (could be "6/15/2026", ISO, or junk), so parse
    // it safely — an unparseable date must not crash the endpoint.
    const _ts = (v) => { const d = v ? new Date(v) : null; return d && !isNaN(d.getTime()) ? d.getTime() : 0; };
    const _isoDay = (v) => { const d = v ? new Date(v) : null; return (d && !isNaN(d.getTime()) ? d : new Date()).toISOString().slice(0, 10); };

    // Auto-enrol any pilot patient without a trial record, in created-date order for stable IDs.
    const maxRes = await pool.query(`SELECT COALESCE(MAX((regexp_replace(study_id,'\\D','','g'))::int),0) AS maxn FROM trial_enrollments`);
    let nextN = (maxRes.rows[0].maxn || 0) + 1;
    const missing = ids.filter(id => !trialByPatient[id] && patById[id])
      .map(id => patById[id])
      .sort((a, b) => _ts(a.created_date) - _ts(b.created_date));
    for (const p of missing) {
      const studyId = 'GQ-' + String(nextN).padStart(3, '0');
      const enrollDate = _isoDay(p.created_date);
      try {
        const ins = await pool.query(
          `INSERT INTO trial_enrollments (patient_id, study_id, enrollment_date) VALUES ($1,$2,$3)
             ON CONFLICT (patient_id) DO NOTHING RETURNING *`, [p.id, studyId, enrollDate]);
        if (ins.rows[0]) { trialByPatient[p.id] = ins.rows[0]; nextN++; }
        else {
          const r = await pool.query('SELECT * FROM trial_enrollments WHERE patient_id=$1', [p.id]);
          if (r.rows[0]) trialByPatient[p.id] = r.rows[0];
        }
      } catch (e) { /* skip collisions */ }
    }

    const now = Date.now();
    const histDispatch = (job) => {
      const h = Array.isArray(job.history) ? job.history : [];
      const d = h.find(e => (e.status || '').toUpperCase() === 'DISPATCHED');
      return d ? d.at : (job.mfg_date || null);
    };
    const isDispatched = (job) => {
      if ((job.status || '').toUpperCase() === 'DISPATCHED') return true;
      const h = Array.isArray(job.history) ? job.history : [];
      return h.some(e => (e.status || '').toUpperCase() === 'DISPATCHED');
    };

    const patients = ids.map(id => {
      const p = patById[id], job = jobByPatient[id], t = trialByPatient[id];
      if (!p || !t) return null;
      const mon = monByPatient[id] || { wk_count: 0, last_at: null };
      const wk = mon.wk_count || 0;
      let status;
      if (t.withdrawn_at) status = 'Withdrawn';
      else if (wk >= settings.pilot_weeks) status = 'Completed';
      else if (isDispatched(job) || wk > 0) {
        const lastAt = mon.last_at ? new Date(mon.last_at).getTime() : null;
        status = (wk > 0 && lastAt && (now - lastAt) > settings.lost_threshold_days * 86400000)
          ? 'Lost to Follow-up' : 'Active';
      } else status = 'Enrolled';
      return {
        studyId: t.study_id, patientId: id,
        uhic: p.uhic, name: p.name, diagnosis: p.cancer,
        enrollmentDate: t.enrollment_date,
        supplementStartDate: histDispatch(job),
        batchNo: job.batch_no || null,
        weeklyReviews: wk,
        withdrawnReason: t.withdrawn_reason || null,
        status
      };
    }).filter(Boolean).sort((a, b) => (a.studyId > b.studyId ? 1 : -1));

    res.json({ settings, patients });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Export Pilot Dataset — assembles the full pilot dataset (4 tables) for Excel export.
app.get('/api/trials/export', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const settings = (await pool.query('SELECT * FROM pilot_settings WHERE id=1')).rows[0]
      || { pilot_weeks: 6, lost_threshold_days: 14 };
    const formulas = await loadFormulaConstants(pool);
    const jobsRes = await pool.query('SELECT patient_id, status, history, mfg_date, batch_no, created_at FROM manufacturing_jobs');
    const jobByPatient = {};
    jobsRes.rows.forEach(j => { const prev = jobByPatient[j.patient_id]; if (!prev || new Date(j.created_at) > new Date(prev.created_at)) jobByPatient[j.patient_id] = j; });

    // Denominator is every enrolled patient, not only those with a dispatched
    // product. This used to start from manufacturing_jobs alone, which dropped
    // enrolled patients who never received one — precisely the patients with
    // the shortest time under care, so any "all patients" figure computed from
    // the workbook was biased upward.
    const enrolledRes = await pool.query('SELECT patient_id FROM trial_enrollments');
    const idSet = new Set(Object.keys(jobByPatient));
    enrolledRes.rows.forEach(r => { if (r.patient_id) idSet.add(r.patient_id); });
    const ids = _scopeIds(req, Array.from(idSet));
    const empty = { enrollment: [], baseline: [], weekly: [], final: [], analysis: [], daily: [], summary: [] };
    if (!ids.length) return res.json(empty);

    const pats = (await pool.query(
      `SELECT id, uhic, name, cancer, cancer_stage, palliative_stage, tumor_burden,
              sarcopenia_status, regimen, sex, age, weight, usual_weight, height,
              albumin, crp, muac, hand_grip, smi, hemoglobin,
              weight_loss_percent, reduced_food_intake, created_date, full_data
         FROM patients WHERE id = ANY($1)`, [ids])).rows;
    const patById = {}; pats.forEach(p => { patById[p.id] = p; });
    const trials = (await pool.query('SELECT * FROM trial_enrollments WHERE patient_id = ANY($1)', [ids])).rows;
    const trialByPat = {}; trials.forEach(t => { trialByPat[t.patient_id] = t; });
    const plans = (await pool.query('SELECT patient_id, version FROM nutrition_plans WHERE patient_id = ANY($1) ORDER BY version DESC NULLS LAST', [ids])).rows;
    const verByPat = {}; plans.forEach(pl => { if (verByPat[pl.patient_id] === undefined) verByPat[pl.patient_id] = pl.version; });
    const logs = (await pool.query(`SELECT id, patient_id, recorded_at, data FROM monitoring_logs WHERE type='weekly' AND patient_id = ANY($1) ORDER BY recorded_at ASC`, [ids])).rows;
    const weeklyByPat = {};
    logs.forEach(l => { (weeklyByPat[l.patient_id] = weeklyByPat[l.patient_id] || []).push({ logId: l.id, recordedAt: l.recorded_at, ...(l.data || {}) }); });

    const dailyRows = (await pool.query(
      `SELECT patient_id, recorded_at, data FROM monitoring_logs
        WHERE type='daily' AND patient_id = ANY($1) ORDER BY recorded_at ASC`, [ids])).rows;
    const dailyByPat = {};
    dailyRows.forEach(l => { (dailyByPat[l.patient_id] = dailyByPat[l.patient_id] || []).push(l.data || {}); });

    // Last contact of ANY kind — daily observations count as an entry even in a
    // week with no formal review, so the aggregate spans both log types.
    const lastEntryRows = (await pool.query(
      `SELECT patient_id, MAX(recorded_at) AS last_at FROM monitoring_logs
        WHERE patient_id = ANY($1) GROUP BY patient_id`, [ids])).rows;
    const lastEntryBy = {}; lastEntryRows.forEach(r => { lastEntryBy[r.patient_id] = r.last_at; });

    // Prescribed targets per week, keyed on the monitoring log the week was
    // generated from — an exact link, unlike matching on week number, which
    // drifts whenever a review is entered late or out of order.
    let rxRows = [];
    try {
      rxRows = (await pool.query(
        'SELECT patient_id, week_number, monitoring_log_id, targets FROM weekly_prescriptions WHERE patient_id = ANY($1)', [ids])).rows;
    } catch (_) { rxRows = []; }
    const rxByLog = {}, rxByWeek = {};
    rxRows.forEach(r => {
      if (r.monitoring_log_id != null) rxByLog[r.monitoring_log_id] = r.targets || {};
      rxByWeek[r.patient_id + '#' + r.week_number] = r.targets || {};
    });

    const _d = (v) => { if (!v) return ''; const d = new Date(v); return isNaN(d.getTime()) ? String(v).slice(0, 10) : d.toISOString().slice(0, 10); };
    const _num = (v) => (v === null || v === undefined || v === '' || isNaN(parseFloat(v))) ? null : parseFloat(v);
    const _r1 = (v) => v === null ? null : Math.round(v * 10) / 10;
    const _r0 = (v) => v === null ? null : Math.round(v);
    const diff = (a, b, dp) => (a === null || b === null) ? null
      : (dp === 0 ? Math.round(b - a) : Math.round((b - a) * Math.pow(10, dp)) / Math.pow(10, dp));
    const bmi = (w, h) => { const W = _num(w), H = _num(h); return (W && H) ? Math.round(W / Math.pow(H / 100, 2) * 10) / 10 : null; };
    const histAt = (job, status) => { if (!job) return null; const h = Array.isArray(job.history) ? job.history : []; const e = h.find(x => (x.status || '').toUpperCase() === status); return e ? e.at : null; };
    const isDispatched = (job) => !!job && ((job.status || '').toUpperCase() === 'DISPATCHED' || (Array.isArray(job.history) && job.history.some(e => (e.status || '').toUpperCase() === 'DISPATCHED')));
    const now = Date.now();
    const statusOf = (id) => {
      const t = trialByPat[id], job = jobByPatient[id];
      const wks = weeklyByPat[id] || [];
      if (t && t.withdrawn_at) return 'Withdrawn';
      if (wks.length >= settings.pilot_weeks) return 'Completed';
      if (isDispatched(job) || wks.length > 0) {
        const last = wks.length ? new Date(wks[wks.length - 1].recordedAt).getTime() : null;
        if (wks.length > 0 && last && (now - last) > settings.lost_threshold_days * 86400000) return 'Lost to Follow-up';
        return 'Active';
      }
      return 'Enrolled';
    };

    // Estimated intake for one week. The prescribed split already reflects the
    // oral intake % recorded that week, so only the supplement side is scaled
    // by compliance. Returns nulls unless BOTH the targets and a compliance
    // figure exist — a week with no compliance recorded is not a week of zero
    // intake, and averaging it in as one would understate every patient.
    // Resolves a week's targets into the four numbers everything downstream
    // needs. Weeks a doctor edited before the merge fix lost their
    // oral/supplement split (see PUT /api/weekly-prescriptions/:id); it is
    // recoverable, because it is the same derivation the engine used — the
    // recorded oral intake % of the target, with the remainder carried by the
    // supplement. Only used when the stored value is genuinely absent.
    const resolveSplit = (w, targets) => {
      const t = targets || {};
      const totalKcal = _num(t.totalKcal), totalProt = _num(t.totalProtein);
      let oralKcal = _num(t.oralKcal), suppKcal = _num(t.suppKcal), suppProt = _num(t.suppProtein);
      const oralPct = _num(t.oralPct) !== null ? _num(t.oralPct) : _num((w || {}).oralIntake);
      if (totalKcal !== null && oralPct !== null && (oralKcal === null || suppKcal === null)) {
        const f = Math.max(0, Math.min(100, oralPct)) / 100;
        oralKcal = Math.round(totalKcal * f);
        suppKcal = Math.max(0, totalKcal - oralKcal);
      }
      if (totalProt !== null && oralPct !== null && suppProt === null) {
        const f = Math.max(0, Math.min(100, oralPct)) / 100;
        suppProt = Math.max(0, Math.round(totalProt * (1 - f) * 10) / 10);
      }
      return { totalKcal, totalProt, oralKcal, suppKcal, suppProt };
    };

    const weekIntake = (w, targets) => {
      const sp = resolveSplit(w, targets);
      const totalKcal = sp.totalKcal, totalProt = sp.totalProt;
      const oralKcal = sp.oralKcal, suppKcal = sp.suppKcal, suppProt = sp.suppProt;
      const comp = _num(w.compliance);

      if (comp === null || totalKcal === null || oralKcal === null || suppKcal === null) {
        return { kcal: null, protein: null, pctKcal: null, pctProtein: null, targetKcal: totalKcal, targetProtein: totalProt };
      }
      const f = Math.max(0, Math.min(100, comp)) / 100;
      const kcal = oralKcal + suppKcal * f;
      const protein = (totalProt !== null && suppProt !== null) ? (totalProt - suppProt) + suppProt * f : null;
      return {
        kcal: _r0(kcal),
        protein: _r1(protein),
        pctKcal: totalKcal ? _r1(kcal / totalKcal * 100) : null,
        pctProtein: (protein !== null && totalProt) ? _r1(protein / totalProt * 100) : null,
        targetKcal: totalKcal, targetProtein: totalProt
      };
    };

    const mean = (a) => a.length ? a.reduce((s, v) => s + v, 0) / a.length : null;
    const median = (a) => {
      if (!a.length) return null;
      const s = a.slice().sort((x, y) => x - y), m = Math.floor(s.length / 2);
      return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
    };

    const enrollment = [], baseline = [], weekly = [], final = [], analysis = [], daily = [];
    ids.forEach(id => {
      const p = patById[id]; if (!p) return;
      const t = trialByPat[id], job = jobByPatient[id];
      const fd = p.full_data || {};
      const studyId = t ? t.study_id : '';
      const wks = weeklyByPat[id] || [];
      const lastW = wks.length ? wks[wks.length - 1] : null;
      const enrolledAt = (t && t.enrollment_date) || p.created_date || null;
      const lastEntry = lastEntryBy[id] || null;

      // Duration under nutrition care. Deliberately NOT called length of stay:
      // there is no admission or discharge date in this system, and a reader
      // seeing "length of stay" would take it for inpatient bed days.
      let daysUnderCare = null;
      if (enrolledAt) {
        const start = new Date(enrolledAt).getTime();
        const end = lastEntry ? new Date(lastEntry).getTime() : start;
        if (!isNaN(start) && !isNaN(end)) daysUnderCare = Math.max(0, Math.round((end - start) / 86400000));
      }
      const status = statusOf(id);
      // Anyone without a recorded endpoint is still accruing, so their duration
      // is a floor rather than a result and is kept out of the cohort mean.
      const stillUnderCare = !(t && t.withdrawn_at) && status !== 'Completed';

      enrollment.push({
        'Study ID': studyId, 'UHID': p.uhic || '', 'Patient Name': p.name || '', 'Diagnosis': p.cancer || '',
        'Sex': p.sex || '', 'Age': p.age != null ? p.age : '',
        'Enrolled Date': _d(enrolledAt),
        'Report/Approval Date': _d(histAt(job, 'APPROVED') || (job ? job.created_at : null)),
        'Manufacturing Date': _d(job ? job.mfg_date : null),
        'Dispatch / Start Date': _d(histAt(job, 'DISPATCHED') || (job ? job.mfg_date : null)),
        'Last Entry Date': _d(lastEntry),
        'Days Under Care': daysUnderCare,
        'Still Under Care': stillUnderCare ? 'Yes' : 'No',
        'Status': status, 'Formula Version': verByPat[id] != null ? verByPat[id] : 1,
        'Batch No': (job && job.batch_no) || ''
      });

      // Both ends of the MUST screen go through the same mapper and the same
      // calculation, so the change between them is a real difference.
      const mustBase  = computeMust(mustInputs(p), formulas);
      const mustFinal = lastW ? computeMust(mustInputs(p, lastW), formulas) : null;
      const usualWeight = p.usual_weight != null ? p.usual_weight : fd.usualWeight;

      baseline.push({
        'Study ID': studyId, 'Patient Name': p.name || '',
        'Weight (kg)': _num(p.weight), 'Usual Weight (kg)': _num(usualWeight),
        'Weight Loss %': _num(p.weight_loss_percent), 'Height (cm)': _num(p.height),
        'BMI': bmi(p.weight, p.height), 'MUAC (cm)': _num(p.muac), 'Hand Grip (kg)': _num(p.hand_grip),
        'Albumin (g/dL)': _num(p.albumin), 'CRP (mg/L)': _num(p.crp), 'Hemoglobin (g/dL)': _num(p.hemoglobin),
        'MUST Score': mustBase.total, 'MUST Risk': mustBase.risk || '',
        'MUST Incomplete — Missing': mustBase.complete ? '' : mustBase.missing.join(', ')
      });

      // ── Daily intake ────────────────────────────────────────────────────
      // The daily log records oral intake % and supplement consumed % every
      // day. Converting those to kcal and grams needs the prescription that
      // was in force on that date, so each day is matched to the most recent
      // weekly review on or before it.
      //   oral      = target x that day's oral intake %
      //   supplement = prescribed supplement x that day's consumed %
      //   day total = oral + supplement
      // A day can exceed 100% of target legitimately: a patient eating well
      // who also takes a supplement sized for a larger gap.
      const dayKcalVals = [], dayProtVals = [];
      const wkByDate = wks
        .map((w, i) => ({ w, i, at: new Date(w.recordedAt).getTime(),
                          wkNo: w.week != null ? w.week : (i + 1) }))
        .filter(x => !isNaN(x.at))
        .sort((a, b) => a.at - b.at);
      (dailyByPat[id] || []).forEach(d => {
        const dDate = d.date || null;
        const dAt = dDate ? new Date(dDate).getTime() : NaN;
        // The week in force: latest review on or before this day, else the first.
        let ref = null;
        if (wkByDate.length) {
          ref = wkByDate[0];
          if (!isNaN(dAt)) {
            for (const c of wkByDate) { if (c.at <= dAt) ref = c; else break; }
          }
        }
        const tg = ref ? (rxByLog[ref.w.logId] || rxByWeek[id + '#' + ref.wkNo] || null) : null;
        const sp = resolveSplit(ref ? ref.w : null, tg);
        const oralPctD = _num(d.oralIntake), suppPctD = _num(d.suppConsumed);
        const oF = oralPctD === null ? null : Math.max(0, oralPctD) / 100;
        const sF = suppPctD === null ? null : Math.max(0, suppPctD) / 100;
        const oralK = (sp.totalKcal !== null && oF !== null) ? sp.totalKcal * oF : null;
        const suppK = (sp.suppKcal  !== null && sF !== null) ? sp.suppKcal  * sF : null;
        const oralP = (sp.totalProt !== null && oF !== null) ? sp.totalProt * oF : null;
        const suppP = (sp.suppProt  !== null && sF !== null) ? sp.suppProt  * sF : null;
        const totK = (oralK === null && suppK === null) ? null : (oralK || 0) + (suppK || 0);
        const totP = (oralP === null && suppP === null) ? null : (oralP || 0) + (suppP || 0);
        if (totK !== null) dayKcalVals.push(totK);
        if (totP !== null) dayProtVals.push(totP);
        daily.push({
          'Study ID': studyId, 'Patient Name': p.name || '', 'Date': _d(dDate),
          'Week In Force': ref ? ref.wkNo : '',
          'Oral Intake %': oralPctD, 'Supplement Consumed %': suppPctD,
          'Supplement Prescribed': d.suppPrescribed || '',
          'Target kcal': sp.totalKcal, 'Target Protein (g)': sp.totalProt,
          'Oral kcal': _r0(oralK), 'Supplement kcal': _r0(suppK), 'Day Total kcal': _r0(totK),
          'Oral Protein (g)': _r1(oralP), 'Supplement Protein (g)': _r1(suppP), 'Day Total Protein (g)': _r1(totP),
          '% kcal Target': (totK !== null && sp.totalKcal) ? _r1(totK / sp.totalKcal * 100) : null,
          '% Protein Target': (totP !== null && sp.totalProt) ? _r1(totP / sp.totalProt * 100) : null,
          'Nausea': d.nausea || '', 'Vomiting': d.vomiting || '', 'Mucositis': d.mucositis != null ? d.mucositis : ''
        });
      });

      // Latest recorded albumin and glucose. Taken from the most recent weekly
      // review that actually carries the value, not simply the last review —
      // albumin appears in about half of them, so "the last review" would
      // report blank for most patients. The date says which review it came from.
      const lastRecorded = (key) => {
        for (let i = wks.length - 1; i >= 0; i--) {
          const v = _num(wks[i][key]);
          if (v !== null) return { v, at: wks[i].recordedAt };
        }
        return { v: null, at: null };
      };
      const finalAlb = lastRecorded('albumin');
      const finalGlu = lastRecorded('glucose');

      const kcalVals = [], protVals = [], pctKcalVals = [], pctProtVals = [];
      wks.forEach((w, i) => {
        const wkNo = w.week != null ? w.week : (i + 1);
        const targets = rxByLog[w.logId] || rxByWeek[id + '#' + wkNo] || null;
        const intake = weekIntake(w, targets);
        if (intake.kcal !== null) kcalVals.push(intake.kcal);
        if (intake.protein !== null) protVals.push(intake.protein);
        if (intake.pctKcal !== null) pctKcalVals.push(intake.pctKcal);
        if (intake.pctProtein !== null) pctProtVals.push(intake.pctProtein);
        const mustWk = computeMust(mustInputs(p, w), formulas);
        weekly.push({
          'Study ID': studyId, 'Week': wkNo, 'Date': _d(w.recordedAt),
          'Weight (kg)': _num(w.weight), 'BMI': _num(w.bmi), 'MUAC (cm)': _num(w.muac), 'Hand Grip': _num(w.handGrip),
          'ECOG': w.ecog != null ? w.ecog : '', 'Albumin (g/dL)': _num(w.albumin), 'CRP (mg/L)': _num(w.crp), 'Glucose': _num(w.glucose),
          'Oral Intake %': _num(w.oralIntake), 'Compliance %': _num(w.compliance),
          // Captured every week (None / Dose Delay / Dose Reduction / RT
          // Interruption / Treatment Held / Hospitalisation) and, until now,
          // never exported. These are the outcomes the muscle-mass literature
          // uses as its endpoint, so they belong in the dataset.
          'Treatment Interruption': w.interruptions || '',
          'Target kcal': intake.targetKcal, 'Target Protein (g)': intake.targetProtein,
          'Est. kcal Intake': intake.kcal, 'Est. Protein Intake (g)': intake.protein,
          '% kcal Target': intake.pctKcal, '% Protein Target': intake.pctProtein,
          'MUST Score': mustWk.total, 'MUST Risk': mustWk.risk || ''
        });
      });

      const bW = _num(p.weight), bAlb = _num(p.albumin), bCrp = _num(p.crp);
      const lW = lastW ? _num(lastW.weight) : null, lAlb = lastW ? _num(lastW.albumin) : null, lCrp = lastW ? _num(lastW.crp) : null;
      final.push({
        'Study ID': studyId, 'Patient Name': p.name || '', 'Status': status, 'Weeks Completed': wks.length,
        'Baseline Weight': bW, 'Final Weight': lW, 'Weight Change': diff(bW, lW, 1),
        'Baseline Albumin': bAlb, 'Final Albumin': lAlb, 'Albumin Change': diff(bAlb, lAlb, 2),
        'Baseline CRP': bCrp, 'Final CRP': lCrp, 'CRP Change': diff(bCrp, lCrp, 1)
      });

      const bGrip = _num(p.hand_grip), lGrip = lastW ? _num(lastW.handGrip) : null;
      const bMuac = _num(p.muac), lMuac = lastW ? _num(lastW.muac) : null;
      analysis.push({
        'Study ID': studyId, 'UHID': p.uhic || '', 'Patient Name': p.name || '', 'Diagnosis': p.cancer || '',
        'Sex': p.sex || '', 'Age': p.age != null ? p.age : '', 'Height (cm)': _num(p.height),
        'Status': status, 'Weeks Completed': wks.length,
        'Baseline Weight (kg)': bW, 'Final Weight (kg)': lW, 'Weight Change (kg)': diff(bW, lW, 1),
        'Baseline MUST': mustBase.total, 'Final MUST': mustFinal ? mustFinal.total : null,
        'MUST Change': diff(mustBase.total, mustFinal ? mustFinal.total : null, 0),
        'Baseline MUST Risk': mustBase.risk || '', 'Final MUST Risk': (mustFinal && mustFinal.risk) || '',
        'Baseline Hand Grip (kg)': bGrip, 'Final Hand Grip (kg)': lGrip, 'Hand Grip Change (kg)': diff(bGrip, lGrip, 1),
        'Baseline MUAC (cm)': bMuac, 'Final MUAC (cm)': lMuac, 'MUAC Change (cm)': diff(bMuac, lMuac, 1),
        'Mean Est. kcal Intake': _r0(mean(kcalVals)),
        'Mean % kcal Target': _r1(mean(pctKcalVals)),
        'Mean Est. Protein Intake (g)': _r1(mean(protVals)),
        'Mean % Protein Target': _r1(mean(pctProtVals)),
        'Weeks With Intake Data': kcalVals.length,
        'Mean Daily kcal (oral+supp)': _r0(mean(dayKcalVals)),
        'Mean Daily Protein (g)': _r1(mean(dayProtVals)),
        'Days With Intake Data': dayKcalVals.length,
        'Final Albumin (g/dL)': finalAlb.v,
        'Final Albumin Date': _d(finalAlb.at),
        'Final Glucose (mg/dL)': finalGlu.v,
        'Final Glucose Date': _d(finalGlu.at),
        'Days Under Care': daysUnderCare,
        'Still Under Care': stillUnderCare ? 'Yes' : 'No'
      });
    });

    // ── Cohort summary ────────────────────────────────────────────────────
    // Its own sheet rather than a totals row on the data: a totals row breaks
    // sorting, filtering and pivots the moment anyone touches the analysis
    // sheet. Every line carries its own n, because MUAC and grip are recorded
    // far less consistently than weight and a single average would otherwise
    // hide how thin some of them are.
    const paired = (bKey, fKey) => analysis
      .map(r => ({ b: r[bKey], f: r[fKey] }))
      .filter(x => x.b !== null && x.b !== undefined && x.f !== null && x.f !== undefined);
    const summaryRow = (label, bKey, fKey, dp) => {
      const pr = paired(bKey, fKey);
      const bs = pr.map(x => x.b), fs = pr.map(x => x.f);
      const rd = (v) => v === null ? null : Math.round(v * Math.pow(10, dp)) / Math.pow(10, dp);
      return {
        'Measure': label, 'n (paired)': pr.length,
        'Baseline Mean': rd(mean(bs)), 'Final Mean': rd(mean(fs)),
        'Mean Change': rd(mean(pr.map(x => x.f - x.b))), 'Notes': ''
      };
    };
    const summary = [
      summaryRow('Weight (kg)', 'Baseline Weight (kg)', 'Final Weight (kg)', 1),
      summaryRow('MUST Score', 'Baseline MUST', 'Final MUST', 2),
      summaryRow('Hand Grip (kg)', 'Baseline Hand Grip (kg)', 'Final Hand Grip (kg)', 1),
      summaryRow('MUAC (cm)', 'Baseline MUAC (cm)', 'Final MUAC (cm)', 1)
    ];
    // MUST's bands are coarser than its score: anything from 2 upward reads
    // "high risk", so a patient improving 3 -> 2 keeps the same label and a
    // reader comparing labels alone concludes nothing moved. The note travels
    // with the number rather than living only in whatever email announced it.
    const mustSummary = summary.find(r => r['Measure'] === 'MUST Score');
    if (mustSummary) {
      mustSummary['Notes'] = 'Lower is better. Bands: 0 low, 1 medium, 2+ high — a patient can improve by a point '
        + 'and stay in the high-risk band, so read the change, not the risk label. Recomputed at each end from the '
        + 'same screen; weight loss is measured against usual weight (6 months prior), and SMI is baseline-only and '
        + 'carried forward. Patients whose score could not be computed are excluded — see the Baseline sheet for what was missing.';
    }
    const col = (k) => analysis.map(r => r[k]).filter(v => v !== null && v !== undefined);
    const kc = col('Mean Est. kcal Intake'), pk = col('Mean % kcal Target');
    const pc = col('Mean Est. Protein Intake (g)'), pp = col('Mean % Protein Target');
    summary.push({
      'Measure': 'Estimated Calorie Intake (kcal/day)', 'n (paired)': kc.length,
      'Baseline Mean': '', 'Final Mean': _r0(mean(kc)), 'Mean Change': '',
      'Notes': 'Cohort mean of each patient\'s weekly average'
        + (pk.length ? ' — ' + _r1(mean(pk)) + '% of prescribed target' : '')
        + '. Estimated from prescribed target x recorded compliance; oral intake % is a clinical estimate, not a weighed food record.'
        + ' Where a prescription was edited before 2026-09-06 its oral/supplement split was not retained, so it is re-derived from the recorded oral intake % of that week.'
    });
    summary.push({
      'Measure': 'Estimated Protein Intake (g/day)', 'n (paired)': pc.length,
      'Baseline Mean': '', 'Final Mean': _r1(mean(pc)), 'Mean Change': '',
      'Notes': 'Cohort mean of each patient\'s weekly average'
        + (pp.length ? ' — ' + _r1(mean(pp)) + '% of prescribed target' : '') + '.'
    });
    const dK = col('Mean Daily kcal (oral+supp)'), dP = col('Mean Daily Protein (g)');
    summary.push({
      'Measure': 'Daily Calorie Intake (kcal/day, oral + supplement)', 'n (paired)': dK.length,
      'Baseline Mean': '', 'Final Mean': _r0(mean(dK)), 'Mean Change': '',
      'Notes': 'From the daily log: target x that day\'s oral intake %, plus prescribed supplement x that day\'s consumed %. '
        + 'Finer than the weekly figure above, which uses one compliance number per week.'
    });
    summary.push({
      'Measure': 'Daily Protein Intake (g/day, oral + supplement)', 'n (paired)': dP.length,
      'Baseline Mean': '', 'Final Mean': _r1(mean(dP)), 'Mean Change': '', 'Notes': ''
    });
    const alb = col('Final Albumin (g/dL)'), glu = col('Final Glucose (mg/dL)');
    summary.push({
      'Measure': 'Final Albumin (g/dL)', 'n (paired)': alb.length,
      'Baseline Mean': '', 'Final Mean': _r1(mean(alb)), 'Mean Change': '',
      'Notes': 'Most recent weekly review that recorded it; the date is on the Data Analysis sheet.'
    });
    summary.push({
      'Measure': 'Final Blood Glucose (mg/dL)', 'n (paired)': glu.length,
      'Baseline Mean': '', 'Final Mean': _r0(mean(glu)), 'Mean Change': '', 'Notes': ''
    });
    const closed = analysis.filter(r => r['Still Under Care'] === 'No' && r['Days Under Care'] !== null).map(r => r['Days Under Care']);
    const openN = analysis.filter(r => r['Still Under Care'] === 'Yes').length;
    summary.push({
      'Measure': 'Days Under Nutrition Care', 'n (paired)': closed.length,
      'Baseline Mean': '', 'Final Mean': _r1(mean(closed)), 'Mean Change': '',
      'Notes': 'Enrolment to last recorded entry. Median ' + (median(closed) !== null ? median(closed) : 'n/a')
        + '. Excludes ' + openN + ' patient(s) still under care, whose duration is a floor rather than a result.'
        + ' Not inpatient length of stay — no admission or discharge date is recorded in this system.'
    });

    // A patient with a manufacturing job but no enrolment record has no study
    // ID. That is worth seeing — it is a data-integrity signal — but it sorts
    // to the bottom rather than heading every sheet.
    const byStudy = (a, b) => {
      const A = String(a['Study ID'] || ''), B = String(b['Study ID'] || '');
      if (!A !== !B) return A ? -1 : 1;
      return A.localeCompare(B);
    };
    enrollment.sort(byStudy);
    baseline.sort(byStudy);
    weekly.sort((a, b) => byStudy(a, b) || (a['Week'] - b['Week']));
    final.sort(byStudy);
    analysis.sort(byStudy);
    daily.sort((a, b) => byStudy(a, b) || String(a['Date']).localeCompare(String(b['Date'])));

    res.json({ enrollment, baseline, weekly, final, analysis, daily, summary, generatedAt: new Date().toISOString() });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Formula Tracking — which formula version + batch each pilot patient received.
// ── Formulation & micronutrient report ────────────────────────────────────
// The Excel export covers enrolment, baseline, weekly and outcomes, but the
// prescribed formulation and the micronutrient orders live inside
// nutrition_plans.final_plan as JSONB and were only ever rendered on one
// patient's profile page. So the question "what are we actually prescribing,
// across all patients?" could not be answered without reading the database by
// hand. This aggregates it.
//
// Reports its own denominator: a plan with no micronutrient block is counted
// as missing rather than quietly skipped, so a thin result cannot be mistaken
// for a complete one.
// Admin only, deliberately. This report names every patient in the study and
// shows what each was prescribed, so it is not scoped to one doctor's list —
// requireAdmin would have admitted DOCTOR (see the note on that function).
app.get('/api/trials/micronutrients', authenticateToken, requireAdminOnly, async (req, res) => {
  try {
    const plansRes = await pool.query(
      `SELECT DISTINCT ON (patient_id)
              patient_id, version, final_plan, engine_output, generated_at
         FROM nutrition_plans
        ORDER BY patient_id, version DESC NULLS LAST`);
    const rows = plansRes.rows;
    if (!rows.length) return res.json({ patients: 0, plansAnalysed: 0, micronutrients: [] });

    const ids = rows.map(r => r.patient_id);
    const pats = (await pool.query(
      'SELECT id, name, uhic, cancer, feeding_method FROM patients WHERE id = ANY($1)', [ids])).rows;
    const byId = {}; pats.forEach(p => { byId[p.id] = p; });
    const trials = (await pool.query(
      'SELECT patient_id, study_id FROM trial_enrollments WHERE patient_id = ANY($1)', [ids])).rows;
    const studyBy = {}; trials.forEach(t => { studyBy[t.patient_id] = t.study_id; });

    // The formulation the store actually made is on the weekly prescription,
    // not the plan — take the most recent one per patient.
    const wrx = (await pool.query(
      `SELECT DISTINCT ON (patient_id) patient_id, targets
         FROM weekly_prescriptions WHERE patient_id = ANY($1)
        ORDER BY patient_id, week_number DESC`, [ids])).rows;
    const rxBy = {}; wrx.forEach(w => { rxBy[w.patient_id] = w.targets || {}; });

    const asObj = v => {
      if (!v) return {};
      if (typeof v === 'string') { try { return JSON.parse(v); } catch(e) { return {}; } }
      return v;
    };
    // "None", "Consider if…", "-" all mean not prescribed. Counting them as
    // orders would inflate every nutrient to 100%.
    const NOT_PRESCRIBED = /^(none|nil|n\/?a|-|—|not required|consider\b)/i;
    const isOrdered = v => typeof v === 'string' && v.trim() !== '' && !NOT_PRESCRIBED.test(v.trim());

    const tally = {};                 // field -> value -> count
    const bump = (field, value) => {
      if (value === undefined || value === null || value === '') return;
      tally[field] = tally[field] || {};
      tally[field][value] = (tally[field][value] || 0) + 1;
    };
    const micro = {};                 // nutrient -> { ordered, doses:{dose:n} }
    let withMicro = 0;

    const perPatient = rows.map(r => {
      const fp = asObj(r.final_plan);
      const eo = asObj(r.engine_output);
      const plan = Object.keys(fp).length ? fp : eo;      // final overrides engine
      const p = byId[r.patient_id] || {};
      const rx = rxBy[r.patient_id] || {};

      const formulation = rx.formulation || plan.formulation
        || (plan.recipe && plan.recipe.formulation) || null;
      const proteinType = plan.proteinType || null;
      const route = plan.prescribedRoute || p.feeding_method || null;

      bump('formulation', formulation);
      bump('proteinType', proteinType);
      bump('route', route);

      const m = asObj(plan.micronutrients);
      const ordered = [];
      if (Object.keys(m).length) withMicro++;
      Object.entries(m).forEach(([nutrient, dose]) => {
        micro[nutrient] = micro[nutrient] || { ordered: 0, doses: {} };
        if (isOrdered(dose)) {
          micro[nutrient].ordered++;
          const key = String(dose).trim();
          micro[nutrient].doses[key] = (micro[nutrient].doses[key] || 0) + 1;
          ordered.push(nutrient);
        }
      });

      return {
        patientId: r.patient_id,
        studyId: studyBy[r.patient_id] || null,
        name: p.name || '—',
        uhic: p.uhic || null,
        cancer: p.cancer || null,
        planVersion: r.version,
        formulation, proteinType, route,
        kcalPerKg: plan.kcalPerKg != null ? plan.kcalPerKg : null,
        proteinPerKg: plan.proteinPerKg != null ? plan.proteinPerKg : null,
        dailyCalories: plan.dailyCalories != null ? plan.dailyCalories : null,
        dailyProtein: plan.dailyProtein != null ? plan.dailyProtein : null,
        cachexia: !!plan.cachexia,
        sarcopenia: !!plan.sarcopenia,
        micronutrientsOrdered: ordered.length,
        micronutrients: ordered
      };
    });

    const asList = field => Object.entries(tally[field] || {})
      .map(([value, n]) => ({ value, n, pct: Math.round(n / rows.length * 1000) / 10 }))
      .sort((a, b) => b.n - a.n);

    const micronutrients = Object.entries(micro)
      .map(([nutrient, d]) => ({
        nutrient,
        ordered: d.ordered,
        pct: Math.round(d.ordered / rows.length * 1000) / 10,
        doses: Object.entries(d.doses).map(([dose, n]) => ({ dose, n }))
                 .sort((a, b) => b.n - a.n)
      }))
      .sort((a, b) => b.ordered - a.ordered);

    res.json({
      generatedAt: new Date().toISOString(),
      patients: rows.length,
      plansAnalysed: rows.length,
      // Stated plainly so a partial dataset cannot read as a complete one.
      coverage: {
        plansWithMicronutrients: withMicro,
        plansMissingMicronutrients: rows.length - withMicro,
        formulationKnown: Object.values(tally.formulation || {}).reduce((a, b) => a + b, 0)
      },
      formulation: asList('formulation'),
      proteinType: asList('proteinType'),
      route: asList('route'),
      micronutrients,
      perPatient
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/trials/formula', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const jobsRes = await pool.query('SELECT patient_id, status, history, mfg_date, batch_no, created_at FROM manufacturing_jobs');
    const jobByPatient = {};
    jobsRes.rows.forEach(j => {
      const prev = jobByPatient[j.patient_id];
      if (!prev || new Date(j.created_at) > new Date(prev.created_at)) jobByPatient[j.patient_id] = j;
    });
    const ids = _scopeIds(req, Object.keys(jobByPatient));
    if (!ids.length) return res.json({ patients: [] });

    const pats = (await pool.query('SELECT id, name FROM patients WHERE id = ANY($1)', [ids])).rows;
    const nameById = {}; pats.forEach(p => { nameById[p.id] = p.name; });
    const trials = (await pool.query('SELECT patient_id, study_id FROM trial_enrollments WHERE patient_id = ANY($1)', [ids])).rows;
    const studyByPat = {}; trials.forEach(t => { studyByPat[t.patient_id] = t.study_id; });

    // Latest plan version + recipe per patient.
    const plans = (await pool.query('SELECT patient_id, version, full_data FROM nutrition_plans WHERE patient_id = ANY($1) ORDER BY version DESC NULLS LAST', [ids])).rows;
    const planByPat = {};
    plans.forEach(pl => { if (!planByPat[pl.patient_id]) planByPat[pl.patient_id] = pl; });

    const histDispatch = (job) => {
      const h = Array.isArray(job.history) ? job.history : [];
      const d = h.find(e => (e.status || '').toUpperCase() === 'DISPATCHED');
      return d ? d.at : (job.mfg_date || null);
    };

    const patients = ids.map(id => {
      const job = jobByPatient[id];
      const pl = planByPat[id];
      const fd = (pl && pl.full_data) || {};
      const fp = fd.finalPlan || fd;
      const proteinType = fp.proteinType
        || (fp.recipe && fp.recipe.protein && fp.recipe.protein.name)
        || null;
      return {
        patientId: id,
        studyId: studyByPat[id] || null,
        name: nameById[id] || '—',
        formulaVersion: pl && pl.version != null ? pl.version : null,
        proteinType,
        batchNo: job.batch_no || null,
        mfgDate: job.mfg_date || null,
        startDate: histDispatch(job)
      };
    }).sort((a, b) => String(a.studyId).localeCompare(String(b.studyId)));

    res.json({ patients });
  } catch (e) { res.status(500).json({ error: e.message }); }
});


// ── Doctor ID migration — reassign patients from old localStorage doctor ID to DB doctor ID
app.post('/api/admin/migrate-doctor-id', authenticateToken, async (req, res) => {
  if (!['ADMIN','SUPER_ADMIN'].includes(req.user && req.user.role)) return res.status(403).json({ error: 'Admin only' });
  try {
    const { oldId, newId } = req.body;
    if (!oldId || !newId) return res.status(400).json({ error: 'oldId and newId required' });
    // Update assigned_doctor_id column
    const r1 = await pool.query(
      'UPDATE patients SET assigned_doctor_id=$1 WHERE assigned_doctor_id=$2',
      [newId, oldId]
    );
    // Update inside full_data JSONB
    const r2 = await pool.query(
      `UPDATE patients SET full_data = jsonb_set(full_data, '{assignedDoctorId}', to_jsonb($1::text))
       WHERE full_data->>'assignedDoctorId' = $2`,
      [newId, oldId]
    );
    res.json({ ok: true, columnUpdated: r1.rowCount, jsonbUpdated: r2.rowCount });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// Weekly Outcomes — weekly monitoring metrics for every pilot patient.
app.get('/api/trials/outcomes', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const jobsRes = await pool.query('SELECT DISTINCT patient_id FROM manufacturing_jobs');
    const ids = _scopeIds(req, jobsRes.rows.map(r => r.patient_id).filter(Boolean));
    if (!ids.length) return res.json({ patients: [] });
    const pats = (await pool.query(
      'SELECT id, name, weight, albumin, crp, muac, hand_grip, ecog_status, full_data FROM patients WHERE id = ANY($1)', [ids]
    )).rows;
    const nameById = {};
    const baselineById = {};
    pats.forEach(p => {
      nameById[p.id] = p.name;
      const fd = p.full_data || {};
      const reducedFI = fd.reducedFoodIntake != null ? fd.reducedFoodIntake : null;
      baselineById[p.id] = {
        weight:     p.weight      != null ? p.weight      : (fd.weight     || null),
        albumin:    p.albumin     != null ? p.albumin     : (fd.albumin    || null),
        crp:        p.crp         != null ? p.crp         : (fd.crp        || null),
        muac:       p.muac        != null ? p.muac        : (fd.muac       || null),
        handGrip:   p.hand_grip   != null ? p.hand_grip   : (fd.handGrip   || null),
        bmi:        fd.bmi        != null ? fd.bmi        : null,
        ecog:       p.ecog_status != null ? p.ecog_status : (fd.ecogStatus || null),
        oralIntake: reducedFI     != null ? (100 - reducedFI) : null,
        compliance: null
      };
    });
    const trials = (await pool.query('SELECT patient_id, study_id FROM trial_enrollments WHERE patient_id = ANY($1)', [ids])).rows;
    const studyByPat = {}; trials.forEach(t => { studyByPat[t.patient_id] = t.study_id; });
    const logs = (await pool.query(
      `SELECT patient_id, recorded_at, data FROM monitoring_logs
         WHERE type='weekly' AND patient_id = ANY($1) ORDER BY recorded_at ASC`, [ids])).rows;
    const byPat = {};
    logs.forEach(l => {
      const d = l.data || {};
      (byPat[l.patient_id] = byPat[l.patient_id] || []).push({
        recordedAt: l.recorded_at,
        week: d.week != null ? d.week : null,
        weight: d.weight != null ? d.weight : null,
        bmi: d.bmi != null ? d.bmi : null,
        muac: d.muac != null ? d.muac : null,
        handGrip: d.handGrip != null ? d.handGrip : null,
        ecog: d.ecog != null ? d.ecog : null,
        albumin: d.albumin != null ? d.albumin : null,
        crp: d.crp != null ? d.crp : null,
        glucose: d.glucose != null ? d.glucose : null,
        oralIntake: d.oralIntake != null ? d.oralIntake : null,
        compliance: d.compliance != null ? d.compliance : null
      });
    });
    // Daily logs
    const dailyLogs = (await pool.query(
      `SELECT patient_id, recorded_at, data FROM monitoring_logs
         WHERE type='daily' AND patient_id = ANY($1) ORDER BY recorded_at ASC`, [ids])).rows;
    const dayByPat = {};
    dailyLogs.forEach(l => {
      const d = l.data || {};
      (dayByPat[l.patient_id] = dayByPat[l.patient_id] || []).push({
        recordedAt: l.recorded_at,
        date: d.date || null,
        oralIntake: d.oralIntake != null ? d.oralIntake : null,
        suppPrescribed: d.suppPrescribed || null,
        suppConsumed: d.suppConsumed != null ? d.suppConsumed : null,
        nausea: d.nausea || null,
        vomiting: d.vomiting || null,
        mucositis: d.mucositis || null,
        bowel: d.bowel || null,
        hydration: d.hydration || null,
        notes: d.notes || null
      });
    });

    const patients = ids.map(id => ({
      patientId: id,
      studyId: studyByPat[id] || null,
      name: nameById[id] || '—',
      baseline: baselineById[id] || null,
      weeks: byPat[id] || [],
      days: dayByPat[id] || []
    })).sort((a, b) => String(a.studyId).localeCompare(String(b.studyId)));
    res.json({ patients });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ───────────────────── Supply run-out prediction ──────────────────────────
// The adherence tracker reports gaps AFTER they happen. This predicts them:
// each dispatched product covers a fixed window, so we can tell who runs out
// in the next few days and whether anything is in the pipeline to replace it.
//
// SUPPLY_DAYS is 7 because the whole model is weekly prescriptions — one
// approved weekly Rx produces one product covering one week. If products ever
// cover a different span this is the single place to change it.
const SUPPLY_DAYS = 7;
// Warn this many days before the current product is exhausted, so the store
// has time to manufacture and dispatch the next one.
const SUPPLY_WARN_DAYS = 3;

app.get('/api/supply-status', authenticateToken, async (req, res) => {
  try {
    const role = req.user && req.user.role;
    const isAdmin = ['ADMIN', 'SUPER_ADMIN'].includes(role);
    const isStore = ['STORE', 'STORE_APPROVER'].includes(role);

    let patRes;
    if (isAdmin) {
      patRes = await pool.query('SELECT id, name, uhic, cancer, assigned_doctor_id, full_data FROM patients');
    } else if (isStore) {
      // Store users see patients whose products belong to their store.
      const u = (await pool.query('SELECT store_id FROM users WHERE id=$1', [req.user.id])).rows[0];
      const storeId = u && u.store_id;
      if (!storeId) return res.json({ patients: [], supplyDays: SUPPLY_DAYS });
      patRes = await pool.query(
        `SELECT DISTINCT p.id, p.name, p.uhic, p.cancer, p.assigned_doctor_id, p.full_data
           FROM patients p JOIN manufacturing_jobs j ON j.patient_id = p.id
          WHERE j.store_id = $1`, [storeId]);
    } else {
      patRes = await pool.query(
        `SELECT id, name, uhic, cancer, assigned_doctor_id, full_data FROM patients
          WHERE assigned_doctor_id = $1 OR full_data->>'assignedDoctorId' = $1`, [req.user.id]);
    }
    const patients = patRes.rows;
    if (!patients.length) return res.json({ patients: [], supplyDays: SUPPLY_DAYS });

    const ids = patients.map(p => p.id);
    const jobs = (await pool.query(
      `SELECT id, patient_id, status, history, batch_no, created_at
         FROM manufacturing_jobs WHERE patient_id = ANY($1)`, [ids])).rows;
    const trials = (await pool.query(
      'SELECT patient_id, withdrawn_at FROM trial_enrollments WHERE patient_id = ANY($1)', [ids])).rows;
    const withdrawnBy = {}; trials.forEach(t => { withdrawnBy[t.patient_id] = t.withdrawn_at; });

    const settings = (await pool.query('SELECT * FROM pilot_settings WHERE id=1')).rows[0]
      || { pilot_weeks: 6 };
    const weekCounts = (await pool.query(
      `SELECT patient_id, COUNT(*)::int AS n FROM monitoring_logs
        WHERE type='weekly' AND patient_id = ANY($1) GROUP BY patient_id`, [ids])).rows;
    const weeksBy = {}; weekCounts.forEach(r => { weeksBy[r.patient_id] = r.n; });

    const jobsBy = {};
    jobs.forEach(j => { (jobsBy[j.patient_id] = jobsBy[j.patient_id] || []).push(j); });

    const DAY = 86400000;
    const dispatchedAt = (j) => {
      const h = Array.isArray(j.history) ? j.history : [];
      const e = h.find(x => (x.status || '').toUpperCase() === 'DISPATCHED');
      return e ? e.at : ((j.status || '').toUpperCase() === 'DISPATCHED' ? j.created_at : null);
    };
    const weekNo = (j) => {
      const m = String(j.id).match(/_w(\d+)$/);
      return m ? parseInt(m[1], 10) : 0;
    };
    const label = (j) => weekNo(j) ? 'Week ' + weekNo(j) : 'Initial';

    const out = patients.map(p => {
      const list = (jobsBy[p.id] || []).sort((a, b) => weekNo(a) - weekNo(b));
      if (!list.length) return null;

      // Latest product that actually reached the patient.
      let lastDispatch = null, lastLabel = null;
      list.forEach(j => {
        const at = dispatchedAt(j);
        if (at && (!lastDispatch || new Date(at) > new Date(lastDispatch))) {
          lastDispatch = at; lastLabel = label(j);
        }
      });

      // Anything already moving through the store counts as cover.
      const pipeline = list.filter(j => {
        const s = (j.status || '').toUpperCase();
        return s !== 'DISPATCHED' && s !== 'DELIVERED';
      }).map(j => ({ label: label(j), status: j.status }));

      // Not a supply problem if the patient has finished or left the study.
      const finished = (weeksBy[p.id] || 0) >= (settings.pilot_weeks || 6);
      const withdrawn = !!withdrawnBy[p.id];

      let runsOutAt = null, daysLeft = null;
      if (lastDispatch) {
        const end = new Date(new Date(lastDispatch).getTime() + SUPPLY_DAYS * DAY);
        runsOutAt = end.toISOString();
        daysLeft = Math.floor((end.getTime() - Date.now()) / DAY);
      }

      let state = 'ok', reason = null;
      if (withdrawn)        { state = 'inactive'; reason = 'Withdrawn from study'; }
      else if (finished)    { state = 'inactive'; reason = 'Pilot complete'; }
      else if (!lastDispatch) {
        state = pipeline.length ? 'awaiting_first' : 'none';
        reason = pipeline.length
          ? 'First product not dispatched yet (' + pipeline[0].label + ' ' + (pipeline[0].status||'') + ')'
          : 'No product dispatched and nothing in production';
      } else if (daysLeft < 0) {
        state = pipeline.length ? 'out_pipeline' : 'out';
        reason = Math.abs(daysLeft) + ' day' + (Math.abs(daysLeft)===1?'':'s') + ' past supply end'
               + (pipeline.length ? ' — ' + pipeline[0].label + ' in production' : ' — nothing in production');
      } else if (daysLeft <= SUPPLY_WARN_DAYS && !pipeline.length) {
        state = 'running_out';
        reason = daysLeft === 0 ? 'Supply ends today — nothing in production'
               : daysLeft + ' day' + (daysLeft===1?'':'s') + ' of supply left — nothing in production';
      }

      return {
        patientId: p.id, name: p.name, uhic: p.uhic, cancer: p.cancer,
        doctorId: p.assigned_doctor_id || (p.full_data||{}).assignedDoctorId || null,
        lastProduct: lastLabel, lastDispatchAt: lastDispatch,
        runsOutAt, daysLeft, pipeline, state, reason
      };
    }).filter(Boolean);

    // Most urgent first: already out, then running out, then the rest.
    const rank = { out:0, running_out:1, out_pipeline:2, none:3, awaiting_first:4, ok:5, inactive:6 };
    out.sort((a,b) => (rank[a.state] - rank[b.state]) || ((a.daysLeft ?? 999) - (b.daysLeft ?? 999)));

    res.json({ patients: out, supplyDays: SUPPLY_DAYS, warnDays: SUPPLY_WARN_DAYS });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Impact summary: baseline vs latest across the cohort ──────────────────
// Answers the question a doctor evaluating the product actually asks: "is this
// working?" In advanced cancer the expected trajectory is continued loss, so
// stabilisation is itself a result — but this is a single-arm pilot with no
// control group, so the response deliberately ships the caveats alongside the
// numbers rather than letting the UI imply proof of causation.
app.get('/api/trials/impact', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const jobsRes = await pool.query('SELECT DISTINCT patient_id FROM manufacturing_jobs');
    const ids = _scopeIds(req, jobsRes.rows.map(r => r.patient_id).filter(Boolean));
    if (!ids.length) return res.json({ metrics: [], patients: [], n: 0 });

    const pats = (await pool.query(
      `SELECT id, name, weight, height, albumin, crp, muac, hand_grip, full_data
         FROM patients WHERE id = ANY($1)`, [ids])).rows;
    const trials = (await pool.query(
      'SELECT patient_id, study_id FROM trial_enrollments WHERE patient_id = ANY($1)', [ids])).rows;
    const studyBy = {}; trials.forEach(t => { studyBy[t.patient_id] = t.study_id; });

    const logs = (await pool.query(
      `SELECT patient_id, recorded_at, data FROM monitoring_logs
        WHERE type='weekly' AND patient_id = ANY($1) ORDER BY recorded_at ASC`, [ids])).rows;
    const weeklyBy = {};
    logs.forEach(l => { (weeklyBy[l.patient_id] = weeklyBy[l.patient_id] || []).push(l.data || {}); });

    const num = v => (v === null || v === undefined || v === '' || isNaN(parseFloat(v)))
      ? null : parseFloat(v);

    // Per-patient baseline → latest pairs. A patient only counts for a metric
    // if BOTH ends exist; otherwise the mean would be computed over a shifting
    // denominator and quietly overstate the effect.
    const rows = pats.map(p => {
      const fd = p.full_data || {};
      const weeks = weeklyBy[p.id] || [];
      const lastOf = key => {
        for (let i = weeks.length - 1; i >= 0; i--) {
          const v = num(weeks[i][key]);
          if (v !== null) return v;
        }
        return null;
      };
      const base = {
        weight:  num(p.weight)    != null ? num(p.weight)    : num(fd.weight),
        albumin: num(p.albumin)   != null ? num(p.albumin)   : num(fd.albumin),
        crp:     num(p.crp)       != null ? num(p.crp)       : num(fd.crp),
        muac:    num(p.muac)      != null ? num(p.muac)      : num(fd.muac),
        grip:    num(p.hand_grip) != null ? num(p.hand_grip) : num(fd.handGrip)
      };
      const latest = {
        weight: lastOf('weight'), albumin: lastOf('albumin'),
        crp: lastOf('crp'), muac: lastOf('muac'), grip: lastOf('handGrip')
      };
      return {
        patientId: p.id, name: p.name, studyId: studyBy[p.id] || null,
        weeks: weeks.length, base, latest
      };
    }).filter(r => r.weeks > 0);

    // "Higher is better" for weight/albumin/MUAC/grip; CRP is inverted.
    const METRICS = [
      { key:'weight',  label:'Weight',      unit:'kg',   better:'up'   },
      { key:'albumin', label:'Albumin',     unit:'g/dL', better:'up'   },
      { key:'crp',     label:'CRP',         unit:'mg/L', better:'down' },
      { key:'muac',    label:'MUAC',        unit:'cm',   better:'up'   },
      { key:'grip',    label:'Hand grip',   unit:'kg',   better:'up'   }
    ];

    const mean = a => a.length ? a.reduce((s, v) => s + v, 0) / a.length : null;
    // Sample standard deviation of the paired differences.
    const sd = a => {
      if (a.length < 2) return null;
      const m = mean(a);
      return Math.sqrt(a.reduce((s, v) => s + Math.pow(v - m, 2), 0) / (a.length - 1));
    };

    const metrics = METRICS.map(m => {
      const paired = rows
        .map(r => ({ b: r.base[m.key], l: r.latest[m.key] }))
        .filter(x => x.b !== null && x.l !== null);
      if (!paired.length) {
        return { ...m, n:0, baselineMean:null, latestMean:null, meanChange:null,
                 improved:0, stable:0, worsened:0 };
      }
      const diffs = paired.map(x => x.l - x.b);
      // "Stable" band avoids counting measurement noise as change:
      // ±2% of baseline for weight, ±10% for the lab values.
      const band = m.key === 'weight' ? 0.02 : 0.10;
      let improved = 0, stable = 0, worsened = 0;
      paired.forEach((x, i) => {
        const tol = Math.abs(x.b) * band;
        const d = diffs[i];
        if (Math.abs(d) <= tol) stable++;
        else if (m.better === 'up' ? d > 0 : d < 0) improved++;
        else worsened++;
      });
      const md = mean(diffs), s = sd(diffs);
      return {
        ...m,
        n: paired.length,
        baselineMean: +mean(paired.map(x => x.b)).toFixed(2),
        latestMean:   +mean(paired.map(x => x.l)).toFixed(2),
        meanChange:   +md.toFixed(2),
        sdChange:     s != null ? +s.toFixed(2) : null,
        // Standard error of the mean difference — lets the UI show a range
        // rather than a single figure that looks more precise than it is.
        semChange:    (s != null && paired.length > 1) ? +(s / Math.sqrt(paired.length)).toFixed(2) : null,
        improved, stable, worsened
      };
    });

    res.json({
      n: rows.length,
      metrics,
      patients: rows.map(r => ({
        studyId: r.studyId, name: r.name, weeks: r.weeks,
        weightChange:  (r.base.weight  != null && r.latest.weight  != null) ? +(r.latest.weight  - r.base.weight ).toFixed(1) : null,
        albuminChange: (r.base.albumin != null && r.latest.albumin != null) ? +(r.latest.albumin - r.base.albumin).toFixed(2) : null,
        crpChange:     (r.base.crp     != null && r.latest.crp     != null) ? +(r.latest.crp     - r.base.crp    ).toFixed(1) : null
      })),
      caveats: [
        'Single-arm pilot: there is no control group, so these changes cannot be attributed to the supplement alone.',
        'Patients also received concurrent oncological treatment, which independently affects every metric shown.',
        'Only patients with both a baseline and a follow-up value are counted for each metric; n varies by row.',
        'Albumin and CRP are acute-phase reactants and move with infection and treatment cycles, not nutrition alone.'
      ],
      generatedAt: new Date().toISOString()
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Patient Journey — assembles every key date for one patient from existing data.
// Pricing in the patient journey follows the same visibility rules as the
// rest of the app: admins see everything; the doctor sees the price sent to
// them, their share and the final MRP (never the store's price or markup);
// assistants and everyone else see no pricing at all.
function _journeyPrice(req, pr) {
  const role = req.user && req.user.role;
  if (role === 'ADMIN' || role === 'SUPER_ADMIN') return pr;
  if (role === 'DOCTOR') return { status: pr.status, basePrice: pr.basePrice, doctorShare: pr.doctorShare,
                                  finalPrice: pr.finalPrice, approvedAt: pr.approvedAt };
  return null;
}
app.get('/api/trials/:patientId/journey', authenticateToken, requireAdmin, async (req, res) => {
  const pid = req.params.patientId;
  if (req.caseload && !req.caseload.has(pid)) return res.status(404).json({ error: 'Patient not found' });
  try {
    const pat = (await pool.query('SELECT id, uhic, name, cancer, created_date, created_at FROM patients WHERE id=$1', [pid])).rows[0];
    if (!pat) return res.status(404).json({ error: 'Patient not found' });
    const trial = (await pool.query('SELECT * FROM trial_enrollments WHERE patient_id=$1', [pid])).rows[0] || null;
    const allJobs = (await pool.query(`SELECT id, status, history, mfg_date, exp_date, batch_no, created_at,
        price_status, store_price, markup_pct, base_price, doctor_amount, doctor_pct, final_price, price_note,
        store_priced_at, price_approved_at
      FROM manufacturing_jobs WHERE patient_id=$1 ORDER BY created_at ASC`, [pid])).rows;
    // History entries carry user ids — resolve them to names for display.
    const _uids = new Set();
    allJobs.forEach(j => (Array.isArray(j.history) ? j.history : []).forEach(e => { if (e && e.by) _uids.add(String(e.by)); }));
    const _uname = {};
    if (_uids.size) {
      try {
        (await pool.query('SELECT id, name FROM users WHERE id = ANY($1)', [[..._uids]])).rows
          .forEach(u => { _uname[u.id] = u.name; });
      } catch (_) {}
    }
    const _byName = by => by ? (_uname[by] || by) : null;
    // Initial product job = first non-weekly job (weekly jobs have id 'wxjob_...')
    const job = allJobs.find(j => !String(j.id).startsWith('wxjob_')) || allJobs[0] || null;
    let weeklyRx = [];
    try {
      weeklyRx = (await pool.query(
        `SELECT wp.week_number, wp.status, wp.approved_at, wp.batch_code, u.name AS approved_by_name
           FROM weekly_prescriptions wp LEFT JOIN users u ON u.id = wp.approved_by
          WHERE wp.patient_id=$1 ORDER BY wp.week_number ASC`, [pid])).rows;
    } catch(_) {}
    const planRes = await pool.query('SELECT generated_at FROM nutrition_plans WHERE patient_id=$1 ORDER BY generated_at ASC', [pid]);
    const weeklyRes = await pool.query(`SELECT recorded_at FROM monitoring_logs WHERE patient_id=$1 AND type='weekly' ORDER BY recorded_at ASC`, [pid]);
    const settings = (await pool.query('SELECT * FROM pilot_settings WHERE id=1')).rows[0] || { pilot_weeks: 6 };

    const histAt = (status) => {
      const h = job && Array.isArray(job.history) ? job.history : [];
      const e = h.find(x => (x.status || '').toUpperCase() === status);
      return e ? e.at : null;
    };
    const isDispatched = (j) => {
      if (!j) return false;
      if ((j.status || '').toUpperCase() === 'DISPATCHED') return true;
      const h = Array.isArray(j.history) ? j.history : [];
      return h.some(e => (e.status || '').toUpperCase() === 'DISPATCHED');
    };
    const weeklyDates = weeklyRes.rows.map(r => r.recorded_at);
    const baseline = pat.created_date || pat.created_at || null;
    const wk = weeklyDates.length;
    const lostThreshold = (settings.lost_threshold_days || 14) * 86400000;
    let trialStatus;
    if (trial && trial.withdrawn_at) trialStatus = 'Withdrawn';
    else if (wk >= (settings.pilot_weeks || 6)) trialStatus = 'Completed';
    else if (isDispatched(job) || wk > 0) {
      const lastAt = weeklyDates.length ? new Date(weeklyDates[weeklyDates.length - 1]).getTime() : null;
      trialStatus = (wk > 0 && lastAt && (Date.now() - lastAt) > lostThreshold) ? 'Lost to Follow-up' : 'Active';
    } else trialStatus = 'Enrolled';

    // Per-product dispatch timeline: initial job + each weekly job,
    // with approved / processing / dispatched timestamps from job history.
    const histEntry = (j, status) => {
      const h = j && Array.isArray(j.history) ? j.history : [];
      return h.find(x => (x.status || '').toUpperCase() === status) || null;
    };
    const products = allJobs.map(j => {
      const isWeekly = String(j.id).startsWith('wxjob_');
      const wkMatch  = isWeekly ? String(j.id).match(/_w(\d+)$/) : null;
      const weekNum  = wkMatch ? Number(wkMatch[1]) : null;
      const rx = isWeekly ? weeklyRx.find(r => Number(r.week_number) === weekNum) : null;
      const ap = histEntry(j, 'APPROVED'), pr = histEntry(j, 'PROCESSING'), dp = histEntry(j, 'DISPATCHED');
      return {
        type:         isWeekly ? 'weekly' : 'initial',
        week:         weekNum,
        label:        isWeekly ? ('Week ' + weekNum) : 'Initial',
        batchNo:      j.batch_no || (rx ? rx.batch_code : null),
        status:       j.status,
        approvedAt:   (ap ? ap.at : null) || (rx ? rx.approved_at : null) || j.created_at,
        approvedBy:   _byName(ap && ap.by) || (rx ? rx.approved_by_name : null) || null,
        processingAt: pr ? pr.at : null,
        processingBy: _byName(pr && pr.by),
        dispatchedAt: dp ? dp.at : null,
        dispatchedBy: _byName(dp && dp.by),
        deliveredAt:  (() => { const e = histEntry(j, 'DELIVERED'); return e ? (e.deliveredOn || e.at) : null; })(),
        deliveredBy:  (() => { const e = histEntry(j, 'DELIVERED'); return e ? _byName(e.by) : null; })(),
        price: _journeyPrice(req, {
          status:      j.price_status || null,
          storePrice:  j.store_price  != null ? Number(j.store_price)  : null,
          markupPct:   j.markup_pct   != null ? Number(j.markup_pct)   : null,
          basePrice:   j.base_price   != null ? Number(j.base_price)   : null,
          doctorShare: j.doctor_amount!= null ? Number(j.doctor_amount): null,
          finalPrice:  j.final_price  != null ? Number(j.final_price)  : null,
          note:        j.price_note || null,
          pricedAt:    j.store_priced_at || null,
          approvedAt:  j.price_approved_at || null
        }),
        mfgDate:      j.mfg_date,
        expDate:      j.exp_date
      };
    }).sort((a, b) => (a.type === 'initial' ? -1 : b.type === 'initial' ? 1 : (a.week || 0) - (b.week || 0)));

    res.json({
      patient: { id: pat.id, uhic: pat.uhic, name: pat.name, diagnosis: pat.cancer },
      studyId: trial ? trial.study_id : null,
      trialStatus,
      withdrawnAt: trial ? trial.withdrawn_at : null,
      withdrawnReason: trial ? trial.withdrawn_reason : null,
      batchNo: job ? job.batch_no : null,
      milestones: {
        enrollment:       trial ? trial.enrollment_date : baseline,
        baseline:         baseline,
        reportGenerated:  planRes.rows.length ? planRes.rows[0].generated_at : null,
        hodApproval:      histAt('APPROVED') || (job ? job.created_at : null),
        manufacturing:    job ? job.mfg_date : null,
        dispatch:         histAt('DISPATCHED'),
        supplementStart:  histAt('DISPATCHED') || (job ? job.mfg_date : null),
        finalAssessment:  weeklyDates.length >= settings.pilot_weeks ? weeklyDates[weeklyDates.length - 1] : null
      },
      weeklyReviews: weeklyDates,
      products
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Users: Get All (admin)
app.get('/api/users', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query('SELECT id, name, email, phone, role, hospital_name, store_id, created_at FROM users ORDER BY created_at DESC');
    const rows = result.rows.map(u => ({
      ...u,
      username: u.email || u.phone,
      hospitalName: u.hospital_name,
      storeId: u.store_id
    }));
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Hospitals (normalized entity) ─────────────────────────────────────────
// Find a hospital by name (case-insensitive) or create it; returns its id.
async function _resolveHospitalId(name){
  const nm = (name || '').trim();
  if (!nm) return null;
  const ex = await pool.query('SELECT id FROM hospitals WHERE LOWER(name)=LOWER($1) LIMIT 1', [nm]);
  if (ex.rows[0]) return ex.rows[0].id;
  const hid = 'hosp_' + Date.now() + '_' + Math.floor(Math.random() * 100000);
  await pool.query('INSERT INTO hospitals (id, name) VALUES ($1,$2) ON CONFLICT (name) DO NOTHING', [hid, nm]);
  const r = await pool.query('SELECT id FROM hospitals WHERE LOWER(name)=LOWER($1) LIMIT 1', [nm]);
  return r.rows[0] ? r.rows[0].id : hid;
}
app.get('/api/hospitals', authenticateToken, async (req, res) => {
  try { const r = await pool.query('SELECT id, name, city FROM hospitals ORDER BY name'); res.json(r.rows); }
  catch (e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/hospitals', authenticateToken, async (req, res) => {
  const { name, city } = req.body || {};
  if (!name || !String(name).trim()) return res.status(400).json({ error: 'name required' });
  try {
    const id = await _resolveHospitalId(name);
    if (city) await pool.query('UPDATE hospitals SET city=$1 WHERE id=$2', [city, id]);
    const r = await pool.query('SELECT id, name, city FROM hospitals WHERE id=$1', [id]);
    res.json(r.rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Users: Create (admin)
// User and store create / delete / password reset / store assignment are
// admin-only. They previously checked only that the caller was signed in, so
// any doctor, assistant or store login could create a SUPER_ADMIN account.
app.post('/api/users', authenticateToken, requireAdminOnly, async (req, res) => {
  const { id, name, email, password, role, hospital_name, store_id, phone } = req.body;
  try {
    const hash = await bcrypt.hash(password, 10);
    const hospitalId = await _resolveHospitalId(hospital_name);
    const result = await pool.query(
      'INSERT INTO users (id, name, email, password_hash, role, hospital_name, hospital_id, store_id, phone) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id, name, email, role, hospital_name, hospital_id, store_id, phone',
      [id || `user_${Date.now()}`, name, email, hash, role, hospital_name, hospitalId, store_id || null, phone || null]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Users: Delete
app.delete('/api/users/:id', authenticateToken, requireAdminOnly, async (req, res) => {
  const userId = req.params.id;
  try {
    // Patients reference a doctor via assigned_doctor_id / created_by_id (foreign keys
    // to users). Without clearing these first, Postgres blocks the delete. We null the
    // links — the PATIENTS are kept (just left unassigned) — then remove the user.
    const r = await pool.query('UPDATE patients SET assigned_doctor_id = NULL WHERE assigned_doctor_id = $1', [userId]);
    await pool.query('UPDATE patients SET created_by_id = NULL WHERE created_by_id = $1', [userId]);
    await pool.query('DELETE FROM users WHERE id = $1', [userId]);
    res.json({ success: true, patientsUnassigned: r.rowCount || 0 });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Users: Assign store
// The store a doctor is mapped to — read live from the server so approval never
// depends on a stale copy of the user list cached in the browser.
app.get('/api/users/:id/store', authenticateToken, async (req, res) => {
  try {
    const r = await pool.query('SELECT store_id FROM users WHERE id=$1', [req.params.id]);
    if (!r.rowCount) return res.status(404).json({ error: 'User not found' });
    res.json({ storeId: r.rows[0].store_id || null });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.patch('/api/users/:id/store', authenticateToken, requireAdminOnly, async (req, res) => {
  const { storeId } = req.body;
  try {
    await pool.query('UPDATE users SET store_id = $1 WHERE id = $2', [storeId || null, req.params.id]);
    res.json({ ok: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Users: Reset Password
app.put('/api/users/:id/password', authenticateToken, requireAdminOnly, async (req, res) => {
  const { password } = req.body;
  const targetId = req.params.id;
  try {
    // Safety: confirm exactly ONE user matches this id before changing anything.
    // If duplicate ids exist in the DB, a blind UPDATE would reset every matching
    // user's password at once - so we refuse and report it instead.
    const match = await pool.query('SELECT id, email FROM users WHERE id = $1', [targetId]);
    if (match.rowCount === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    if (match.rowCount > 1) {
      console.error(`[reset-password] REFUSED: id "${targetId}" matches ${match.rowCount} users (duplicate IDs). No passwords changed.`);
      return res.status(409).json({
        error: `Reset blocked: ${match.rowCount} users share this ID. Fix duplicate IDs before resetting so other users are not affected.`
      });
    }

    const hash = await bcrypt.hash(password, 10);
    const upd = await pool.query('UPDATE users SET password_hash = $1 WHERE id = $2', [hash, targetId]);
    console.log(`[reset-password] OK: reset password for id "${targetId}" (${match.rows[0].email}) by admin ${req.user && req.user.id}. Rows changed: ${upd.rowCount}`);
    res.json({ success: true });
  } catch (err) {
    console.error('[reset-password] ERROR:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// Stores: Get All
app.get('/api/stores', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM stores ORDER BY created_at DESC');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Stores: Create
app.post('/api/stores', authenticateToken, requireAdminOnly, async (req, res) => {
  const { id, name, hospital, location } = req.body;
  const fssai = req.body.fssai_number || req.body.fssai || null;
  const address = req.body.address || null;
  try {
    const hospitalId = await _resolveHospitalId(hospital);
    const result = await pool.query(
      'INSERT INTO stores (id, name, hospital, hospital_id, location, fssai_number, address) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *',
      [id || `store_${Date.now()}`, name, hospital || '', hospitalId, location || '', fssai, address]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Stores: Delete
app.delete('/api/stores/:id', authenticateToken, requireAdminOnly, async (req, res) => {
  try {
    await pool.query('DELETE FROM stores WHERE id = $1', [req.params.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create manufacturing jobs for any approved (or further) patient that lacks one.
// Derives status/store/doctor from dedicated columns, falling back to the
// full_data JSON blob and to the assigned doctor's store mapping.
async function reconcileJobs() {
  // The manufacturing_jobs table has FKs (store_id -> stores, doctor_id -> users),
  // so we resolve each candidate to ids that actually exist, then insert row by
  // row — one bad row can't abort the batch, and we report why any were skipped.
  const cand = await pool.query(`
    SELECT p.id AS patient_id,
           p.name,
           COALESCE(
             (SELECT s.id FROM stores s WHERE s.id = p.store_id),
             (SELECT s.id FROM stores s WHERE s.id = u.store_id),
             (SELECT s.id FROM stores s WHERE s.id = p.full_data->>'storeId')
           ) AS store_id,
           (SELECT us.id FROM users us WHERE us.id = COALESCE(p.assigned_doctor_id, p.full_data->>'assignedDoctorId')) AS doctor_id,
           COALESCE(p.status, p.full_data->>'status') AS status
    FROM patients p
    LEFT JOIN users u ON u.id = COALESCE(p.assigned_doctor_id, p.full_data->>'assignedDoctorId')
    WHERE COALESCE(p.status, p.full_data->>'status') IN ('APPROVED','PROCESSING','DISPATCHED','DELIVERED')
      AND NOT EXISTS (SELECT 1 FROM manufacturing_jobs mj WHERE mj.patient_id = p.id)
  `);

  let created = 0;
  const skipped = [];
  for (const r of cand.rows) {
    if (!r.store_id) {
      skipped.push({ patient: r.name || r.patient_id, reason: 'no valid store mapping (orphaned store id)' });
      continue;
    }
    try {
      const ins = await pool.query(
        `INSERT INTO manufacturing_jobs (id, patient_id, store_id, doctor_id, status, history)
         VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT (id) DO NOTHING`,
        ['job_' + r.patient_id, r.patient_id, r.store_id, r.doctor_id, r.status,
         JSON.stringify([{ status: r.status, at: new Date().toISOString() }])]
      );
      created += ins.rowCount;
    } catch (e) {
      skipped.push({ patient: r.name || r.patient_id, reason: e.message });
    }
  }
  return { created, skipped };
}

// Manufacturing Jobs: Get All
// Jobs carry the patient's withdrawal state. Closing a patient used to be
// invisible here, so the store could still manufacture and dispatch product to
// someone who had left the programme — the doctor's screen went quiet while the
// store's did not. The job is not deleted (already-dispatched product is a real
// record that must survive), it is marked, and the store refuses to advance it.
app.get('/api/manufacturing-jobs', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM manufacturing_jobs ORDER BY created_at DESC');
    const closures = await pool.query(
      `SELECT patient_id, reason, closed_at FROM patient_closures
        WHERE reopened_at IS NULL`);
    const closedBy = {};
    closures.rows.forEach(c => { closedBy[c.patient_id] = c; });

    const _isAdm = req.user && (req.user.role === 'ADMIN' || req.user.role === 'SUPER_ADMIN');
    let _defMarkup = 40;
    if (_isAdm) { try { const F = await loadFormulaConstants(pool); const m = parseFloat(F.platform_markup_pct); if (m >= 0) _defMarkup = m; } catch (e) {} }
    res.json(result.rows.map(j0 => {
      const j = jobPriceView(j0, req.user);
      if (_isAdm) j.default_markup_pct = _defMarkup;
      const c = closedBy[j.patient_id];
      if (!c) return j;
      return {
        ...j,
        patientWithdrawn: true,
        withdrawnReason: c.reason,
        withdrawnLabel: (CLOSURE_REASONS[c.reason] || {}).label || c.reason,
        withdrawnAt: c.closed_at
      };
    }));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Admin: reconcile / backfill jobs on demand + return a diagnostic snapshot.
app.post('/api/admin/reconcile-jobs', authenticateToken, async (req, res) => {
  const role = req.user && req.user.role;
  if (role !== 'ADMIN' && role !== 'SUPER_ADMIN') return res.status(403).json({ error: 'Admin only' });
  try {
    const bf = await reconcileJobs();
    const approved = await pool.query(`
      SELECT p.id, p.name,
             COALESCE(p.status, p.full_data->>'status') AS status,
             COALESCE(p.store_id, u.store_id, p.full_data->>'storeId') AS store_id,
             (SELECT 1 FROM manufacturing_jobs mj WHERE mj.patient_id = p.id LIMIT 1) AS has_job
      FROM patients p
      LEFT JOIN users u ON u.id = COALESCE(p.assigned_doctor_id, p.full_data->>'assignedDoctorId')
      WHERE COALESCE(p.status, p.full_data->>'status') IN ('APPROVED','PROCESSING','DISPATCHED','DELIVERED')
    `);
    const jobs = await pool.query('SELECT id, patient_id, store_id, status FROM manufacturing_jobs');
    const storeUsers = await pool.query("SELECT id, name, role, store_id FROM users WHERE role IN ('STORE','STORE_APPROVER','COORDINATOR','DOCTOR')");
    res.json({
      created: bf.created,
      skipped: bf.skipped,
      approvedPatients: approved.rows,
      jobs: jobs.rows,
      storeUsers: storeUsers.rows
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Manufacturing Jobs: Create
app.post('/api/manufacturing-jobs', authenticateToken, async (req, res) => {
  const j = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO manufacturing_jobs (id, patient_id, store_id, doctor_id, status, history) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *',
      [j.id, j.patientId, j.storeId, j.doctorId, j.status || 'APPROVED', JSON.stringify(j.history || [])]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Allowed job status transitions, keyed by current status.
// Value maps target status -> role required to perform it.
const JOB_TRANSITIONS = {
  APPROVED:           { PENDING_PROCESSING: 'STORE' },
  PROCESSING:         { PENDING_DISPATCH:   'STORE' },
  PENDING_PROCESSING: { PROCESSING: 'STORE_APPROVER', APPROVED:   'STORE_APPROVER' },
  PENDING_DISPATCH:   { DISPATCHED: 'STORE_APPROVER', PROCESSING: 'STORE_APPROVER' },
  // Delivery is recorded by the store itself (manager or approver); the
  // coordinator can still record it too.
  DISPATCHED:         { DELIVERED:  ['STORE', 'STORE_APPROVER', 'COORDINATOR'] }
};

// Manufacturing Jobs: Update Status
app.put('/api/manufacturing-jobs/:id', authenticateToken, async (req, res) => {
  let { status, history } = req.body;
  const delivery = req.body.delivery || null;   // { date, receivedBy, note } when marking DELIVERED
  try {
    const role = req.user && req.user.role;
    const isAdmin = role === 'ADMIN' || role === 'SUPER_ADMIN';
    const target = (status || '').toUpperCase();

    // Load the current job to validate the transition and ownership.
    const cur = await pool.query('SELECT status, store_id, patient_id, price_status, history FROM manufacturing_jobs WHERE id=$1', [req.params.id]);
    if (!cur.rows.length) return res.status(404).json({ error: 'Job not found' });
    const currentStatus = (cur.rows[0].status || '').toUpperCase();
    const jobStore = cur.rows[0].store_id;

    // Production cannot start until the doctor has approved the product price.
    if (currentStatus === 'APPROVED' && target === 'PENDING_PROCESSING'
        && cur.rows[0].price_status !== 'APPROVED') {
      return res.status(409).json({
        error: 'The price for this product has not been approved by the doctor yet. '
             + 'Enter the store price and wait for the doctor\'s approval before requesting processing.',
        reason: 'PRICE_NOT_APPROVED'
      });
    }

    // A withdrawn patient's job must not move FORWARD toward dispatch. The store
    // UI already hides the buttons, but a stale tab still holds them, and the
    // cost of getting this wrong is product physically sent to someone who left
    // the programme.
    //
    // Two things stay allowed on purpose. Rejections (rolling a job back) are
    // de-escalation and are exactly what an approver should be able to do when
    // they learn the patient has withdrawn. And DISPATCHED → DELIVERED records
    // something that already physically happened — refusing it would leave the
    // record permanently wrong about where the product went.
    const ADVANCES = {
      APPROVED:           'PENDING_PROCESSING',
      PENDING_PROCESSING: 'PROCESSING',
      PROCESSING:         'PENDING_DISPATCH',
      PENDING_DISPATCH:   'DISPATCHED'
    };
    if (ADVANCES[currentStatus] === target) {
      const wd = await pool.query(
        `SELECT reason FROM patient_closures
          WHERE patient_id=$1 AND reopened_at IS NULL`, [cur.rows[0].patient_id]);
      if (wd.rowCount) {
        const lbl = (CLOSURE_REASONS[wd.rows[0].reason] || {}).label || wd.rows[0].reason;
        return res.status(409).json({
          error: `This patient has been withdrawn (${lbl}). No further product may be prepared or dispatched. `
               + `Ask the doctor to reopen the patient if this is wrong.`,
          reason: 'PATIENT_WITHDRAWN'
        });
      }
    }

    if (!isAdmin) {
      // Store-scope: a manager/approver may only touch their own store's jobs.
      if (role === 'STORE' || role === 'STORE_APPROVER') {
        const ur = await pool.query('SELECT store_id FROM users WHERE id=$1', [req.user.id]);
        const userStore = ur.rows[0] && ur.rows[0].store_id;
        if (userStore && jobStore && userStore !== jobStore) {
          return res.status(403).json({ error: 'This job belongs to another store.' });
        }
      }
      // Transition legality + role requirement.
      const allowed = JOB_TRANSITIONS[currentStatus] || {};
      if (!(target in allowed)) {
        return res.status(409).json({ error: `Illegal status change: ${currentStatus} → ${target || '(empty)'}.` });
      }
      const requiredRole = allowed[target];
      const okRoles = Array.isArray(requiredRole) ? requiredRole : (requiredRole ? [requiredRole] : []);
      if (okRoles.length && !okRoles.includes(role)) {
        const who = okRoles.map(r => r.replace('_', ' ').toLowerCase()).join(' or ');
        return res.status(403).json({ error: `Only a ${who} may perform this action.` });
      }
    }

    // A caller that sends no history (e.g. the coordinator page) used to wipe
    // the job's whole history. Keep the stored history and append this step.
    if (!Array.isArray(history)) {
      const prev = Array.isArray(cur.rows[0].history) ? cur.rows[0].history : [];
      history = prev.concat([{ status: target, at: new Date().toISOString(), by: req.user.id, role }]);
    }
    if (target === 'DELIVERED' && history.length) {
      const d = delivery || {};
      const last = history[history.length - 1] || {};
      const dd = /^\d{4}-\d{2}-\d{2}$/.test(String(d.date || '')) ? d.date : new Date().toISOString().slice(0, 10);
      last.deliveredOn = dd;
      if (d.receivedBy) last.receivedBy = String(d.receivedBy).slice(0, 120);
      if (d.note) last.deliveryNote = String(d.note).slice(0, 500);
      last.by = last.by || req.user.id;
      history[history.length - 1] = last;
    }

    const result = await pool.query(
      'UPDATE manufacturing_jobs SET status=$1, history=$2, updated_at=NOW() WHERE id=$3 RETURNING *',
      [status, JSON.stringify(history || []), req.params.id]
    );
    const job = result.rows[0];
    res.json(jobPriceView(job, req.user));
    if (currentStatus !== target) {
      const _last = Array.isArray(history) && history.length ? history[history.length - 1] : null;
      const _act = _last && _last.action;
      const _t = { PENDING_PROCESSING: '🟠 Processing requested', PROCESSING: '🏭 Processing started',
                   PENDING_DISPATCH: '🟠 Dispatch requested', DISPATCHED: '🚚 Dispatched', DELIVERED: '📦 Delivered' }[target]
              || (_act === 'reject' ? '🔴 Request rejected' : 'Production status changed');
      recordEvent({ type: 'job_status', title: _act === 'reject' ? '🔴 Request rejected' : _t,
        body: `{patient} — ${_jobProductLabel(req.params.id)}: ${_stageLabel(currentStatus)} → ${_stageLabel(target)} (by {actor})`
            + (target === 'DELIVERED' && _last
                ? ` — delivered on ${_last.deliveredOn}${_last.receivedBy ? ', received by ' + _last.receivedBy : ''}${_last.deliveryNote ? ' · ' + _last.deliveryNote : ''}.`
                : '.'),
        patientId: job.patient_id, jobId: req.params.id, user: req.user });

      // Tell the patient's doctor when their product actually moves stage.
      const _docMsg = { PROCESSING: ['🏭 Production started', 'is being prepared by the store'],
                        DISPATCHED: ['🚚 Product dispatched', 'has been dispatched'],
                        DELIVERED:  ['📦 Product delivered', 'has been delivered'] }[target];
      if (_docMsg && _act !== 'reject') {
        (async () => {
          try {
            const pr = await pool.query('SELECT name, assigned_doctor_id FROM patients WHERE id=$1', [job.patient_id]);
            const pat = pr.rows[0] || {};
            const docs = [...new Set([job.doctor_id, pat.assigned_doctor_id].filter(Boolean))];
            if (docs.length) await notifyUsers(docs, _docMsg[0],
              `${pat.name || 'Your patient'} — ${_jobProductLabel(req.params.id)} ${_docMsg[1]}.`, '/dashboard');
          } catch (e) { console.warn('doctor job notify:', e.message); }
        })();
      }
    }

    // ── Approval-workflow notifications (sent after responding) ──────────────
    // The last history entry carries the action: request | approve | reject.
    try {
      const storeId = job && (job.store_id || job.storeId);
      const last = Array.isArray(history) && history.length ? history[history.length - 1] : null;
      const action = last && last.action;
      if (storeId && action) {
        let pName = 'A patient';
        try {
          const pr = await pool.query('SELECT name FROM patients WHERE id=$1', [job.patient_id]);
          if (pr.rows[0] && pr.rows[0].name) pName = pr.rows[0].name;
        } catch(e) { /* ignore */ }
        const s = (status || '').toUpperCase();
        const nice = s === 'PROCESSING' ? 'Processing'
                   : s === 'DISPATCHED' ? 'Dispatched'
                   : s.charAt(0) + s.slice(1).toLowerCase();
        if (action === 'request') {
          // Manager submitted a request → alert the store's approver(s).
          notifyStore(storeId,
            '🟠 Approval Needed',
            `${pName} is awaiting your sign-off (${s === 'PENDING_DISPATCH' ? 'Dispatch' : 'Processing'}).`,
            '/store', ['STORE_APPROVER']).catch(() => {});
        } else if (action === 'approve') {
          // Approver approved → tell the store's manager(s).
          notifyStore(storeId,
            '✅ Request Approved',
            `${pName} moved to ${nice}.`,
            '/store', ['STORE']).catch(() => {});
        } else if (action === 'reject') {
          // Approver rejected → tell the store's manager(s).
          notifyStore(storeId,
            '🔴 Request Rejected',
            `${pName} was reverted to ${nice}.`,
            '/store', ['STORE']).catch(() => {});
        }
      }
    } catch(e) { console.warn('job notify:', e.message); }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Product pricing ─────────────────────────────────────────────────────────
// Flow per job (initial plan and every weekly batch):
//   store enters its price → the ADMIN sets the markup % (default
//   engine_formulas.platform_markup_pct = 40, any value allowed) → the doctor
//   enters the FINAL price (≥ the marked-up price) → store, printed as the MRP.
//   Production is blocked until then.
//   Example: store 1000 → admin 45 % = 1450 → doctor enters 1900 → final 1900.
//   doctor_amount (1900 − 1400 = 500) and doctor_pct are derived and stored for reporting.
// price_status: NULL/'AWAITING_STORE' → 'AWAITING_ADMIN' (admin sets markup %) → 'AWAITING_DOCTOR' → 'APPROVED'
//               ('QUERIED' = doctor sent it back to the store with a note).
// Visibility: the store never sees the markup or the doctor's share; the doctor
// never sees the store's own price or the markup rate; admins see everything.
const PRICE_FIELDS = ['price_status','store_price','markup_pct','base_price','doctor_pct','doctor_amount',
  'final_price','price_note','store_priced_by','store_priced_at','price_approved_by','price_approved_at'];
const PRICE_RESET_SQL = PRICE_FIELDS.map(f => f + '=NULL').join(', ');
const _money = v => Math.round(Number(v) * 100) / 100;

function jobPriceView(job, user) {
  if (!job) return job;
  const role = user && user.role;
  if (role === 'ADMIN' || role === 'SUPER_ADMIN') return job;
  const keep = {
    STORE:          ['price_status','store_price','final_price','price_note','store_priced_at','price_approved_at'],
    STORE_APPROVER: ['price_status','store_price','final_price','price_note','store_priced_at','price_approved_at'],
    DOCTOR:         ['price_status','base_price','doctor_pct','doctor_amount','final_price','price_note','store_priced_at','price_approved_at'],
    ASSISTANT:      ['price_status']      // assistants see no amounts at all
  }[role] || ['price_status','final_price'];
  const out = Object.assign({}, job);
  PRICE_FIELDS.forEach(f => { if (!keep.includes(f)) delete out[f]; });
  return out;
}

async function _loadJobForPricing(id) {
  const r = await pool.query(
    `SELECT j.*, p.name AS patient_name, p.assigned_doctor_id
       FROM manufacturing_jobs j LEFT JOIN patients p ON p.id = j.patient_id
      WHERE j.id=$1`, [id]);
  return r.rows[0] || null;
}
function _jobProductLabel(id) { const m = String(id).match(/_w(\d+)$/); return m ? 'Week ' + m[1] : 'Initial'; }
function _appendHistory(job, entry) {
  const h = Array.isArray(job.history) ? job.history.slice() : [];
  h.push(Object.assign({ at: new Date().toISOString(), status: job.status }, entry));
  return JSON.stringify(h);
}

// Store enters (or re-enters) its price.
app.post('/api/manufacturing-jobs/:id/store-price', authenticateToken, async (req, res) => {
  const role = req.user && req.user.role;
  const isAdmin = role === 'ADMIN' || role === 'SUPER_ADMIN';
  if (!['STORE', 'STORE_APPROVER'].includes(role) && !isAdmin) return res.status(403).json({ error: 'Only the store can enter the store price.' });
  const price = parseFloat(req.body && req.body.price);
  if (!(price > 0) || price > 10000000) return res.status(400).json({ error: 'Enter a valid store price.' });
  try {
    const job = await _loadJobForPricing(req.params.id);
    if (!job) return res.status(404).json({ error: 'Job not found' });
    if (!isAdmin) {
      const ur = await pool.query('SELECT store_id FROM users WHERE id=$1', [req.user.id]);
      const us = ur.rows[0] && ur.rows[0].store_id;
      if (us && job.store_id && us !== job.store_id) return res.status(403).json({ error: 'This job belongs to another store.' });
    }
    if ((job.status || '').toUpperCase() !== 'APPROVED') return res.status(409).json({ error: 'Price can only be set before production starts.' });
    if (job.price_status === 'APPROVED') return res.status(409).json({ error: 'The doctor has already approved the price for this product.' });

    // The store's price goes to the admin first; the admin sets the markup %
    // (default platform_markup_pct, 40) and only then does it reach the doctor.
    const upd = await pool.query(
      `UPDATE manufacturing_jobs
          SET price_status='AWAITING_ADMIN', store_price=$1, markup_pct=NULL, base_price=NULL,
              doctor_pct=NULL, doctor_amount=NULL, final_price=NULL, price_note=NULL,
              store_priced_by=$2, store_priced_at=NOW(), price_approved_by=NULL, price_approved_at=NULL,
              history=$3, updated_at=NOW()
        WHERE id=$4 RETURNING *`,
      [_money(price), req.user.id,
       _appendHistory(job, { action: 'price_set', by: req.user.id, role }), job.id]);
    res.json(jobPriceView(upd.rows[0], req.user));
    recordEvent({ type: 'price_set', title: '💰 Store price — set your markup',
      body: `{patient} — ${_jobProductLabel(job.id)}: store price ₹${_money(price)}. Set the markup % and send it to the doctor.`,
      patientId: job.patient_id, patientName: job.patient_name, jobId: job.id, user: req.user });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Admin sets the markup % on the store price (any value ≥ 0, e.g. 40, 45, 105)
// and sends the resulting price to the doctor.
app.post('/api/manufacturing-jobs/:id/admin-markup', authenticateToken, async (req, res) => {
  const role = req.user && req.user.role;
  if (role !== 'ADMIN' && role !== 'SUPER_ADMIN') return res.status(403).json({ error: 'Only an admin can set the markup.' });
  const pct = parseFloat(req.body && req.body.markupPct);
  if (!(pct >= 0) || pct > 10000) return res.status(400).json({ error: 'Enter a markup percentage (0 or more).' });
  try {
    const job = await _loadJobForPricing(req.params.id);
    if (!job) return res.status(404).json({ error: 'Job not found' });
    if ((job.status || '').toUpperCase() !== 'APPROVED') return res.status(409).json({ error: 'Price can only be changed before production starts.' });
    if (!['AWAITING_ADMIN', 'AWAITING_DOCTOR'].includes(job.price_status) || job.store_price == null) {
      return res.status(409).json({ error: 'There is no store price waiting for your markup on this product.' });
    }
    const store = Number(job.store_price);
    const base = _money(store * (1 + pct / 100));
    const upd = await pool.query(
      `UPDATE manufacturing_jobs
          SET price_status='AWAITING_DOCTOR', markup_pct=$1, base_price=$2, price_note=NULL,
              history=$3, updated_at=NOW()
        WHERE id=$4 RETURNING *`,
      [_money(pct), base, _appendHistory(job, { action: 'markup_set', by: req.user.id, role, markupPct: pct }), job.id]);
    res.json(jobPriceView(upd.rows[0], req.user));
    recordEvent({ type: 'price_markup', title: '📈 Markup set — sent to doctor',
      body: `{actor} set ${_money(pct)}% on {patient} — ${_jobProductLabel(job.id)}: store ₹${store} → ₹${base}. Waiting for the doctor.`,
      patientId: job.patient_id, patientName: job.patient_name, jobId: job.id, user: req.user });
    const doc = job.doctor_id || job.assigned_doctor_id;
    if (doc) notifyUsers([doc], '💰 Price approval needed',
      `${job.patient_name || 'A patient'} — ${_jobProductLabel(job.id)}: price ₹${base} is waiting for your approval.`, '/dashboard').catch(() => {});
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Doctor enters the final price (MRP) directly and approves. It may not be
// below the marked-up price. Older clients may still send doctorAmount or
// doctorPct; those are converted.
app.post('/api/manufacturing-jobs/:id/doctor-price', authenticateToken, async (req, res) => {
  const role = req.user && req.user.role;
  const isAdmin = role === 'ADMIN' || role === 'SUPER_ADMIN';
  if (role !== 'DOCTOR' && !isAdmin) return res.status(403).json({ error: 'Only the doctor can approve the price.' });
  const body = req.body || {};
  const has = v => v != null && v !== '';
  const rawFinal = has(body.finalPrice) ? parseFloat(body.finalPrice) : null;
  const rawAmt = rawFinal == null && has(body.doctorAmount) ? parseFloat(body.doctorAmount) : null;
  const rawPct = rawFinal == null && rawAmt == null && has(body.doctorPct) ? parseFloat(body.doctorPct) : null;
  if (rawFinal == null && rawAmt == null && rawPct == null) return res.status(400).json({ error: 'Enter the final price (₹).' });
  if (rawFinal != null && !(rawFinal > 0 && rawFinal <= 10000000)) return res.status(400).json({ error: 'Enter a valid final price (₹).' });
  if (rawAmt != null && !(rawAmt >= 0 && rawAmt <= 10000000)) return res.status(400).json({ error: 'Enter a valid amount (₹0 or more).' });
  if (rawPct != null && !(rawPct >= 0 && rawPct <= 500)) return res.status(400).json({ error: 'Enter a valid percentage (0–500).' });
  try {
    const job = await _loadJobForPricing(req.params.id);
    if (!job) return res.status(404).json({ error: 'Job not found' });
    if (!isAdmin && req.user.id !== job.doctor_id && req.user.id !== job.assigned_doctor_id) {
      return res.status(403).json({ error: 'This product belongs to another doctor\'s patient.' });
    }
    if (job.price_status !== 'AWAITING_DOCTOR' || job.base_price == null) {
      return res.status(409).json({ error: 'There is no store price waiting for approval on this product.' });
    }
    const base = Number(job.base_price);
    const final = Math.round(rawFinal != null ? rawFinal
                : base + (rawAmt != null ? rawAmt : base * rawPct / 100));   // MRP in whole rupees
    if (final < Math.ceil(base)) {
      return res.status(400).json({ error: `The final price cannot be below ₹${Math.ceil(base)} (the price sent by the store).` });
    }
    const amount = _money(final - base);
    const pct = base > 0 ? _money(amount / base * 100) : 0;
    const upd = await pool.query(
      `UPDATE manufacturing_jobs
          SET price_status='APPROVED', doctor_pct=$1, doctor_amount=$2, final_price=$3, price_note=NULL,
              price_approved_by=$4, price_approved_at=NOW(), history=$5, updated_at=NOW()
        WHERE id=$6 RETURNING *`,
      [pct, amount, final, req.user.id,
       _appendHistory(job, { action: 'price_approved', by: req.user.id, role }), job.id]);
    res.json(jobPriceView(upd.rows[0], req.user));
    recordEvent({ type: 'price_approved', title: '✅ Price approved',
      body: `{actor} approved {patient} — ${_jobProductLabel(job.id)}: final price ₹${final} (price ₹${base}, protocol supervision fee ₹${amount}).`,
      patientId: job.patient_id, patientName: job.patient_name, jobId: job.id, user: req.user });
    notifyStore(job.store_id, '✅ Price approved',
      `${job.patient_name || 'A patient'} — ${_jobProductLabel(job.id)}: final price ₹${final}. You can start production.`,
      '/store', ['STORE', 'STORE_APPROVER']).catch(() => {});
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Doctor sends the price back to the store with a note.
app.post('/api/manufacturing-jobs/:id/price-query', authenticateToken, async (req, res) => {
  const role = req.user && req.user.role;
  const isAdmin = role === 'ADMIN' || role === 'SUPER_ADMIN';
  if (role !== 'DOCTOR' && !isAdmin) return res.status(403).json({ error: 'Only the doctor or an admin can send a price back.' });
  const note = String((req.body && req.body.note) || '').trim().slice(0, 500);
  if (!note) return res.status(400).json({ error: 'Add a note so the store knows what to change.' });
  try {
    const job = await _loadJobForPricing(req.params.id);
    if (!job) return res.status(404).json({ error: 'Job not found' });
    if (!isAdmin && req.user.id !== job.doctor_id && req.user.id !== job.assigned_doctor_id) {
      return res.status(403).json({ error: 'This product belongs to another doctor\'s patient.' });
    }
    const okStates = isAdmin ? ['AWAITING_ADMIN', 'AWAITING_DOCTOR'] : ['AWAITING_DOCTOR'];
    if (!okStates.includes(job.price_status)) return res.status(409).json({ error: 'This price is not waiting for your approval.' });
    const upd = await pool.query(
      `UPDATE manufacturing_jobs SET price_status='QUERIED', price_note=$1, history=$2, updated_at=NOW()
        WHERE id=$3 RETURNING *`,
      [note, _appendHistory(job, { action: 'price_queried', by: req.user.id, role, note }), job.id]);
    res.json(jobPriceView(upd.rows[0], req.user));
    recordEvent({ type: 'price_queried', title: '🔁 Price sent back',
      body: `{actor} sent back the price for {patient} — ${_jobProductLabel(job.id)}: "${note}"`,
      patientId: job.patient_id, patientName: job.patient_name, jobId: job.id, user: req.user });
    notifyStore(job.store_id, '🔁 Price sent back',
      `${job.patient_name || 'A patient'} — ${_jobProductLabel(job.id)}: ${note}`, '/store', ['STORE', 'STORE_APPROVER']).catch(() => {});
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Manufacturing Jobs: Assign batch number + manufacturing/expiry dates (for labels).
// Batch no is a per-store running sequence, assigned once and reused on reprints.
// Exp date = mfg date + 18 months.
app.post('/api/manufacturing-jobs/:id/batch', authenticateToken, async (req, res) => {
  const role = req.user && req.user.role;
  if (!['STORE', 'STORE_APPROVER', 'ADMIN', 'SUPER_ADMIN'].includes(role)) {
    return res.status(403).json({ error: 'Not permitted' });
  }
  const { mfgDate } = req.body;
  if (!mfgDate || !/^\d{4}-\d{2}-\d{2}$/.test(mfgDate)) {
    return res.status(400).json({ error: 'A valid manufacturing date (YYYY-MM-DD) is required.' });
  }
  try {
    const cur = await pool.query('SELECT store_id, batch_no FROM manufacturing_jobs WHERE id=$1', [req.params.id]);
    if (!cur.rows.length) return res.status(404).json({ error: 'Job not found' });
    const storeId = cur.rows[0].store_id;
    let batchNo = cur.rows[0].batch_no;

    // Assign a per-store sequential batch number on first print.
    if (!batchNo) {
      const cnt = await pool.query(
        'SELECT COUNT(*)::int AS n FROM manufacturing_jobs WHERE store_id=$1 AND batch_no IS NOT NULL',
        [storeId]
      );
      const seq = (cnt.rows[0].n || 0) + 1;
      batchNo = 'B' + String(seq).padStart(5, '0');
    }

    // Exp date = mfg + 18 months
    const d = new Date(mfgDate + 'T00:00:00Z');
    const exp = new Date(d);
    exp.setUTCMonth(exp.getUTCMonth() + 18);
    const expDate = exp.toISOString().slice(0, 10);

    const upd = await pool.query(
      'UPDATE manufacturing_jobs SET batch_no=$1, mfg_date=$2, exp_date=$3, updated_at=NOW() WHERE id=$4 RETURNING *',
      [batchNo, mfgDate, expDate, req.params.id]
    );
    res.json(jobPriceView(upd.rows[0], req.user));
    if (!cur.rows[0].batch_no) {
      recordEvent({ type: 'batch', title: '🏷️ Batch generated',
        body: `{patient} — ${_jobProductLabel(req.params.id)}: batch ${batchNo}, mfg ${mfgDate}, exp ${expDate} (by {actor}).`,
        patientId: upd.rows[0].patient_id, jobId: req.params.id, user: req.user });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Assistant → Doctor mapping ─────────────────────────────────────────────
// Stored on the server (it used to live only in the admin's browser, so an
// assistant's own browser never knew their doctor and every patient they
// created was assigned to nobody — or to the assistant — and never reached
// the doctor's dashboard).
async function _saveAssistantMapping(assistantId, doctorId) {
  if (doctorId) {
    // Delete-then-insert rather than ON CONFLICT: an older copy of this table
    // may exist without a unique key on assistant_id (and even with duplicates).
    await pool.query('DELETE FROM doctor_assistant_map WHERE assistant_id=$1', [assistantId]);
    await pool.query('INSERT INTO doctor_assistant_map (assistant_id, doctor_id) VALUES ($1,$2)', [assistantId, doctorId]);
    _asstMap[assistantId] = doctorId;
    return _reassignAssistantPatients(assistantId, doctorId);
  }
  await pool.query('DELETE FROM doctor_assistant_map WHERE assistant_id=$1', [assistantId]);
  delete _asstMap[assistantId];
  return 0;
}

// Mappings: Get doctor-assistant map
app.get('/api/mappings', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query('SELECT assistant_id, doctor_id FROM doctor_assistant_map');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Mappings: set / clear one assistant's doctor (admin only)
app.put('/api/mappings/:assistantId', authenticateToken, async (req, res) => {
  const role = req.user && req.user.role;
  if (role !== 'ADMIN' && role !== 'SUPER_ADMIN') return res.status(403).json({ error: 'Admin only' });
  const doctorId = (req.body && req.body.doctorId) || null;
  try {
    if (doctorId) {
      const d = await pool.query("SELECT role FROM users WHERE id=$1", [doctorId]);
      if (!d.rowCount || d.rows[0].role !== 'DOCTOR') return res.status(400).json({ error: 'That user is not a doctor.' });
    }
    const moved = await _saveAssistantMapping(req.params.assistantId, doctorId);
    res.json({ ok: true, assistantId: req.params.assistantId, doctorId, patientsReassigned: moved });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Mappings: Create (kept for older clients — behaves as an upsert)
app.post('/api/mappings', authenticateToken, async (req, res) => {
  const role = req.user && req.user.role;
  if (role !== 'ADMIN' && role !== 'SUPER_ADMIN') return res.status(403).json({ error: 'Admin only' });
  const { assistantId, doctorId } = req.body || {};
  if (!assistantId) return res.status(400).json({ error: 'assistantId required' });
  try {
    const moved = await _saveAssistantMapping(assistantId, doctorId || null);
    res.status(201).json({ assistant_id: assistantId, doctor_id: doctorId || null, patientsReassigned: moved });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// AI configuration is handled by Anthropic SDK below

// --- ANTHROPIC (CLAUDE) INTEGRATION ---
const Anthropic = require('@anthropic-ai/sdk');
const rawKey = process.env.ANTHROPIC_API_KEY || '';
const anthropic = new Anthropic({ apiKey: rawKey });

// Prompt for mapping Clinical Data
const extractionSystemPrompt = `You are a clinical data extraction tool. You transcribe what a document says; you do not diagnose, estimate or complete.
Extract clinical parameters from the provided text/PDF and return a precise JSON object.
Return ONLY valid JSON. START with '{' and END with '}'. NO preamble, NO markdown code blocks, NO headers.

THE ONE RULE THAT OVERRIDES EVERYTHING ELSE:
Return a value ONLY if the document explicitly states it. Never infer, estimate, or supply a typical value. If the document does not state it, return null for that key.
These values are attached to a real patient and drive a real nutrition prescription that is manufactured and dispensed — an invented weight produces a wrong dose. A null is safe; a plausible guess is not.
Do NOT choose a cancer subtype, stage, tumour burden or regimen that the document does not name. Do NOT pattern-complete laboratory values from the diagnosis.
Schema: {
  "name": "String", "age": "Number", "sex": "Male/Female", "weight": "Number (kg)", "height": "Number (cm)", 
  "usualWeight": "Number (kg)", "uhic": "String", "cancer": "String", "regimen": "String", "feedingMethod": "String",
  "tumorBurden": "String", "sarcopeniaStatus": "String", "cancerStage": "String", "ecogStatus": "Number", "activityLevel": "String",
  "reducedFoodIntake": "Number (%)", "albumin": "Number", "crp": "Number", "muac": "Number", "creatinine": "Number",
  "alt": "Number", "ast": "Number", "bilirubin": "Number", "bloodSugar": "Number", "sodium": "Number", "potassium": "Number",
  "urea": "Number", "tsh": "Number", "prealbumin": "Number", "hemoglobin": "Number", "vitD": "Number", "vitB12": "Number", 
  "folate": "Number", "zinc": "Number", "magnesium": "Number", "hba1c": "Number", "giIssues": "Boolean",
  "allergies": [], "existingSupplements": [], "comorbidities": [], "sideEffects": [], "genomicMarkers": [], "treatmentTypes": []
}`;

app.post('/api/extract', async (req, res) => {
  const { pdfText } = req.body;
  if (!pdfText) return res.status(400).json({ error: 'No text provided.' });

  try {
    const msg = await anthropic.messages.create({
      model: "claude-haiku-4-5-20251001",
      max_tokens: 1600,
      system: extractionSystemPrompt,
      messages: [{ role: "user", content: `Extract from:\n\n${pdfText}` }],
    });

    const rawText = msg.content[0].text;
    let extracted;
    try {
      const jsonStr = rawText.match(/{[\s\S]*}/)?.[0] || rawText;
      extracted = JSON.parse(jsonStr);
    } catch (parseError) {
      console.error("JSON Parse Error in Extraction:", rawText);
      return res.status(422).json({ error: 'AI returned malformed data. Please try again.' });
    }
    res.json({ success: true, data: extracted });
  } catch (error) {
    if (error.status === 429) {
      return res.status(429).json({ error: 'AI Rate Limit exceeded. Please wait a moment.' });
    }
    console.error("Claude Extraction Error:", error);
    res.status(500).json({ error: 'Internal AI failure.' });
  }
});

app.post('/api/chat', async (req, res) => {
  const { message, contextObj } = req.body;
  if (!message) return res.status(400).json({ error: 'No message provided.' });

  // ── Mode is chosen by the CLIENT, never by the model ────────────────────
  // Previously one prompt held both an EXTRACT and a GENERATE mode and the
  // model decided which it was in from the phrasing of the message. "name
  // subramani age 56 lung cancer" reads just as much like a request for a
  // sample case as like a clinical note, and in generate mode the prompt
  // instructed it to fill EVERY schema field. A doctor who supplied three
  // facts about a real patient could receive sixty invented ones — including
  // weight, albumin and creatinine, which the nutrition engine then turns
  // into a real prescription. Extraction is now the default and generating a
  // synthetic case requires the caller to ask for it explicitly.
  const mode = (req.body.mode === 'generate') ? 'generate' : 'extract';

  try {
    const SCHEMA = `{ "name":str, "age":num, "sex":"Male"/"Female", "weight":num, "height":num, "usualWeight":num, "reducedFoodIntake":num, "albumin":num, "crp":num, "cancer":str, "cancerStage":"Stage I"/"Stage II"/"Stage III"/"Stage IV"/"Recurrent", "tumorBurden":"Low"/"Moderate"/"High (Bulky)", "regimen":str, "creatinine":num, "alt":num, "ast":num, "bilirubin":num, "bloodSugar":num, "sodium":num, "potassium":num, "urea":num, "muac":num, "prealbumin":num, "vitD":num, "vitB12":num, "folate":num, "zinc":num, "magnesium":num, "tsh":num, "hba1c":num, "hemoglobin":num, "wbc":num, "anc":num, "platelet":num, "sarcopeniaStatus":str, "activityLevel":str, "ecogStatus":num, "leanBodyMass":num, "smi":num, "handGrip":num, "fatPercent":num, "feedingMethod":str, "giIssues":bool, "comorbidities":[], "sideEffects":[], "existingSupplements":[], "allergies":[], "metastasisSites":[], "genomicMarkers":[], "notes":str }`;

    // Formatting rules only. Nothing here may require a field to be present —
    // "always include this" is what turned an extraction into an invention.
    const FORMAT_RULES = `FORMAT RULES (these describe the SHAPE of a value, and never require one to exist):
RULE: Use ONLY the keys in the schema. NO emojis in keys. NO custom keys like "RED_FLAGS".
RULE: Map any "Red Flags" or "Additional Clinical Data" to the "notes" key.
RULE: "cancer", when stated, uses the format "Cancer Type - Subtype", e.g. "Lung Cancer - NSCLC Adenocarcinoma", "Breast Cancer - Triple Negative", "Lymphoma - DLBCL". If the source names only the type and not the subtype, return just the type — do NOT choose a subtype.
RULE: "feedingMethod" must be EXACTLY one of: "Oral Feeding (Normal Diet)" | "Enteral Feeding – Nasogastric Tube (NG)" | "Enteral Feeding – PEG Tube" | "Enteral Feeding – Jejunostomy (J-Tube)" | "Parenteral Nutrition (TPN)" | "Combination Feeding (Oral + Enteral)" | "Combination Feeding (Enteral + Parenteral)".
RULE: "regimen", when stated, uses clinical protocol notation, e.g. "FOLFOX", "R-CHOP", "Carboplatin + Paclitaxel ± Pembrolizumab".
RULE: "sex" must be "Male" or "Female" (not M/F).
RULE: "reducedFoodIntake" is a percentage (0-100) of normal intake the patient is currently eating.
RULE: "ecogStatus" must be 0, 1, 2, 3, or 4.
RULE: "cancerStage" must be EXACTLY one of: "Stage I" | "Stage II" | "Stage III" | "Stage IV" | "Recurrent".
RULE: "tumorBurden" must be EXACTLY one of: "Low" | "Moderate" | "High (Bulky)".
RULE: "activityLevel" must be one of: "Sedentary" | "Lightly Active" | "Moderately Active" | "Highly Active".
RULE: "sarcopeniaStatus" must be one of: "No" | "Yes" | "Unknown".
RULE: "comorbidities", "sideEffects", "existingSupplements", "allergies", "metastasisSites", "genomicMarkers" must be arrays of strings.`;

    const EXTRACT_PROMPT = `You are a clinical data extraction tool for an oncology nutrition platform. You transcribe; you do not diagnose, estimate or complete.

THE ONE RULE THAT OVERRIDES EVERYTHING ELSE:
Return a value ONLY if it is explicitly stated in the user's text. Never infer, estimate, derive, assume a typical value, or fill a field because it is usually present. If the text does not state it, OMIT THE KEY ENTIRELY.

These outputs are attached to a real patient and drive a real nutrition prescription that is manufactured and dispensed. An invented weight produces a wrong dose. A missing field is safe; a plausible guess is not.

Specifically:
- Do NOT choose a cancer subtype, stage, tumour burden or chemotherapy regimen that was not stated. Omit them.
- Do NOT supply a weight, height, or any laboratory value that was not stated.
- Do NOT convert an absent value into 0, "Unknown", or a normal-range figure.
- Do NOT pattern-complete from the diagnosis. Two patients with the same cancer have different bodies.
- If the text says a value is unavailable, pending or not done, list that field name in "notAvailable" rather than in "extractedData".

${FORMAT_RULES}

Schema (all keys OPTIONAL — include only what the text states): ${SCHEMA}

"reply": one or two plain sentences naming what you found and, if anything essential is absent, what is still needed. Never claim to have filled something you omitted.

Format: { "reply": str, "extractedData": { ...only stated values... }, "notAvailable": [ ...field names the text marks as unavailable... ] }`;

    const GENERATE_PROMPT = `You are generating a SYNTHETIC DEMONSTRATION patient for an oncology nutrition platform. This case is fictional and is labelled as such in the product; it is never a real person.

Generate a complete, clinically realistic synthetic patient. Use Indian epidemiological context by default unless another region is specified: typical Indian names, Asian BMI thresholds (overweight ≥23, obese ≥27.5), realistic Indian lab normals, common Indian comorbidities (Type 2 Diabetes, hypertension), and appropriate body weight and height for Indian adults. Populate ALL schema fields with realistic values.

${FORMAT_RULES}
RULE: include "cancerStage", "tumorBurden" and "regimen" — this is a generated case, so every field is expected.

Schema: ${SCHEMA}

"reply": a 3-4 sentence clinical summary of the generated case, explaining the key nutritional risk factors and why these values were chosen. Begin the reply with "Synthetic demonstration case — not a real patient."

Format: { "reply": str, "extractedData": { ...all values... } }`;

    const systemPrompt = (mode === 'generate') ? GENERATE_PROMPT : EXTRACT_PROMPT;

    const msg = await anthropic.messages.create({
      model: "claude-haiku-4-5-20251001",
      max_tokens: 2000,
      system: systemPrompt,
      messages: [{ role: "user", content: message }],
    });

    const rawText = msg.content[0].text;
    let data;
    try {
      // Robust Parser V5.1: Find the OUTERMOST curly braces
      let start = rawText.indexOf('{');
      let end = rawText.lastIndexOf('}');
      
      if (start !== -1) {
          let jsonCandidate = (end !== -1 && end > start) ? 
                              rawText.substring(start, end + 1) : 
                              rawText.substring(start);
          
          // Truncation Recovery: If JSON is cut off, try to close it
          let openBraces = (jsonCandidate.match(/\{/g) || []).length;
          let closeBraces = (jsonCandidate.match(/\}/g) || []).length;
          while (closeBraces < openBraces) {
              jsonCandidate += "}";
              closeBraces++;
          }

          try {
              data = JSON.parse(jsonCandidate);
          } catch (e) {
              // Last ditch: try to fix common truncation at end of string
              const fixed = jsonCandidate.replace(/,\s*$/, "").replace(/\"$/, "").trim();
              data = JSON.parse(fixed + "}".repeat(openBraces - (fixed.match(/\}/g) || []).length));
          }
      } else {
          throw new Error("No JSON braces found");
      }
      
      // Structural Normalization: Ensure { reply, extractedData } exists
      const commonKeys = ['name', 'age', 'weight', 'height', 'cancer', 'regimen', 'albumin', 'crp', 'notes'];
      
      if (data.extractedData && typeof data.extractedData === 'object') {
          // Already have extractedData, but make sure it's not JUST a reply
          data.reply = data.reply || data.extractedData.reply || "Clinical extraction complete.";
      } else {
          // Flattened response or mixed response
          const reply = data.reply || "Clinical extraction complete.";
          const extracted = { ...data };
          delete extracted.reply;
          
          // Check if it actually contains ANY data keys beyond the reply
          const hasKeys = Object.keys(extracted).length > 0;
          
          data = {
              reply: reply,
              extractedData: hasKeys ? extracted : null
          };
      }
    } catch (e) {
      console.warn("AI Parser Error:", e.message);
      // Fallback: Greedy match outermost braces
      try {
          const match = rawText.match(/\{[\s\S]*\}/)?.[0];
          if (match) {
              const parsed = JSON.parse(match);
              const { reply, ...rest } = (parsed.extractedData || parsed);
              data = { 
                  reply: parsed.reply || reply || "Extraction fallback successful.", 
                  extractedData: Object.keys(rest).length > 0 ? rest : null
              };
          } else {
              throw new Error("No braces in fallback");
          }
      } catch (e2) {
          data = { reply: rawText, extractedData: null };
      }
    }
    
    // Final check for empty objects
    if (data.extractedData && Object.keys(data.extractedData).length === 0) {
        data.extractedData = null;
    }

    // Tell the client which mode produced this, so it can style the fields
    // honestly: values the doctor stated look different from values a demo
    // case invented, and a demo case can be blocked from becoming a patient.
    data.mode = mode;
    data.provenance = (mode === 'generate') ? 'generated' : 'stated';
    if (mode === 'generate') data.synthetic = true;
    if (!Array.isArray(data.notAvailable)) data.notAvailable = [];

    // Belt and braces: in extract mode, drop anything the model returned that
    // is not actually a value — a null, an empty string, or the strings some
    // models emit instead of omitting a key. The prompt forbids these; this
    // makes it impossible for one to reach the form.
    if (mode === 'extract' && data.extractedData) {
      const PLACEHOLDER = /^(unknown|not (available|stated|provided|specified|reported|documented|mentioned)|n\/?a|none|null|nil|tbd|pending|—|-)$/i;
      Object.keys(data.extractedData).forEach(k => {
        const v = data.extractedData[k];
        if (v === null || v === undefined || v === '' ||
            (typeof v === 'string' && PLACEHOLDER.test(v.trim())) ||
            (Array.isArray(v) && v.length === 0)) {
          delete data.extractedData[k];
          if (!data.notAvailable.includes(k)) data.notAvailable.push(k);
        }
      });
      if (!Object.keys(data.extractedData).length) data.extractedData = null;
    }

    res.json(data);
  } catch (error) {
    console.error("Claude Chat Error:", error);
    if (error.status === 429) {
      return res.status(429).json({ error: 'AI rate limit reached. Please wait a moment and try again.' });
    }
    const msg = error.message || 'AI extraction failed';
    res.status(500).json({ error: msg });
  }
});

app.get('/api/list-models', async (req, res) => {
  try {
    const models = await anthropic.models.list();
    res.json({ models: models.data.map(m => m.id) });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Weekly entry dictation ───────────────────────────────────────────────────
// Speech gives us a raw transcript; this turns it into weekly monitoring fields.
// The client NEVER writes these straight into the form — a mis-heard "fifteen"
// for "fifty" would otherwise become a manufactured prescription. The response
// is a proposal the doctor confirms field by field.
const weeklyDictationPrompt = `You transcribe spoken clinical notes into weekly monitoring fields. You transcribe; you do not diagnose, estimate or complete.
Return ONLY valid JSON. START with '{' and END with '}'. NO preamble, NO markdown, NO code fences.

THE ONE RULE THAT OVERRIDES EVERYTHING ELSE:
Return a value ONLY if the speaker actually said it. Never infer, estimate, carry over, or supply a typical value. If it was not said, return null.
These values drive a nutrition prescription that is manufactured and dispensed. A null is safe; a plausible guess is not.

SPOKEN NUMBER HANDLING:
- Words become digits: "three point five" -> 3.5, "fifty five point seven" -> 55.7, "one twenty" -> 120.
- Strip spoken units: "fifty five point seven kilos" -> 55.7, "albumin three point two grams per decilitre" -> 3.2.
- "percent" is a unit, not part of the number: "intake sixty percent" -> 60.
- If a number is genuinely ambiguous between two readings, return null rather than choosing.

FIELD NOTES:
- week: the week number of the assessment ("week four" -> 4).
- weight: body weight in kg.
- muac: mid-upper arm circumference in cm.
- handGrip: hand grip / dynamometer strength in kg.
- ecog: ECOG performance status, integer 0 to 4 only.
- albumin g/dL, crp mg/L, glucose mg/dL, creatinine mg/dL, urea mg/dL.
- oralIntake: oral intake as a PERCENTAGE OF REQUIREMENT. "eating about half" -> 50. If the speaker describes a deficit ("intake down forty percent"), convert to the remaining intake -> 60.
- compliance: supplement adherence percentage.
- interruptions: one of exactly "None", "Dose Delay", "Dose Reduction", "RT Interruption", "Treatment Held", "Hospitalisation", else null.
- notes: any remaining clinical remark, verbatim, as a short string. Null if none.

Schema, all keys always present:
{"week":null,"weight":null,"muac":null,"handGrip":null,"ecog":null,"albumin":null,"crp":null,"glucose":null,"creatinine":null,"urea":null,"oralIntake":null,"compliance":null,"interruptions":null,"notes":null}`;

// ── Speech-to-Text ───────────────────────────────────────────────────────────
// Two providers, chosen at boot. Google is preferred when configured.
//
// GOOGLE, VIA WORKLOAD IDENTITY FEDERATION — worth understanding, because it is
// how cloud-to-cloud auth should work and it needs no secret at all:
//   1. This server runs on an EC2 instance that carries an AWS IAM role.
//   2. google-auth-library reads temporary AWS credentials from the instance
//      metadata service (169.254.169.254) — the same ones the AWS SDK uses.
//   3. It signs an AWS GetCallerIdentity request with them and posts that to
//      Google's STS, which verifies with AWS "is this really your role?".
//   4. Google returns a federated token, which is exchanged for a short-lived
//      access token impersonating a GCP service account.
// Nothing downloadable exists. GCP_WIF_CONFIG holds no key — only the names of
// the pool, provider and service account — so it is not a secret, and the
// organisation's ban on service-account keys is satisfied rather than bypassed.
const GCP_WIF_CONFIG = process.env.GCP_WIF_CONFIG || '';
const OPENAI_KEY     = process.env.OPENAI_API_KEY || '';
const STT_MODEL      = process.env.OPENAI_STT_MODEL || 'gpt-transcribe';

let _gspeech = null, _sttProvider = null, _sttWhy = '';
(function initSpeech() {
  if (GCP_WIF_CONFIG) {
    try {
      const speech = require('@google-cloud/speech');
      const { GoogleAuth } = require('google-auth-library');
      const cfg = JSON.parse(GCP_WIF_CONFIG);
      if (cfg.type !== 'external_account') {
        throw new Error('GCP_WIF_CONFIG is not an external_account config (type=' + cfg.type + ')');
      }
      const auth = new GoogleAuth({
        credentials: cfg,
        scopes: ['https://www.googleapis.com/auth/cloud-platform']
      });
      _gspeech = new speech.SpeechClient({ auth });
      _sttProvider = 'google';
      console.log('Speech-to-Text ready (Google, workload identity federation)');
      return;
    } catch (e) {
      _sttWhy = 'Google WIF failed: ' + e.message;
      console.warn('Speech-to-Text:', _sttWhy);
    }
  }
  if (OPENAI_KEY) {
    _sttProvider = 'openai';
    console.log('Speech-to-Text ready (OpenAI, ' + STT_MODEL + ')');
    return;
  }
  _sttWhy = _sttWhy || 'neither GCP_WIF_CONFIG nor OPENAI_API_KEY is set';
  console.log('Speech-to-Text: ' + _sttWhy + ' — browser speech will be used');
})();

// Primes the recogniser's vocabulary. Without it "albumin" comes back as
// "albumen" and "ECOG" as "eco". Google takes a phrase list with a boost;
// OpenAI takes a sentence of context. Same job, different shape.
const SPEECH_PHRASES = [
  'albumin', 'prealbumin', 'creatinine', 'urea', 'CRP', 'C reactive protein',
  'MUAC', 'mid upper arm circumference', 'hand grip', 'dynamometer',
  'ECOG', 'ECOG zero', 'ECOG one', 'ECOG two', 'ECOG three', 'ECOG four',
  'oral intake', 'supplement compliance', 'adherence', 'sarcopenia', 'cachexia',
  'enteral', 'parenteral', 'nasogastric', 'kilocalories per kilogram',
  'grams per kilogram', 'grams per decilitre', 'milligrams per decilitre',
  'FOLFOX', 'FOLFIRINOX', 'oxaliplatin', 'cisplatin', 'carboplatin',
  'doxorubicin', 'cyclophosphamide', 'paclitaxel', 'docetaxel', 'pemetrexed',
  'pembrolizumab', 'nivolumab', 'atezolizumab', 'durvalumab', 'bortezomib',
  'capecitabine', 'gemcitabine', 'trastuzumab', 'anthracycline', 'taxane',
  'alpha lipoic acid', 'week one', 'week two', 'week three', 'week four',
  'week five', 'week six', 'week seven', 'week eight'
];
const STT_VOCAB_PROMPT =
  'Clinical dictation for an oncology nutrition weekly assessment. Expect: ' +
  SPEECH_PHRASES.join(', ') + '. Numbers are spoken plainly, for example ' +
  '"weight fifty five point seven", "albumin three point five", "week four", ' +
  '"oral intake sixty percent".';

async function _transcribeGoogle(buf, type) {
  const enc = type.indexOf('ogg') >= 0 ? 'OGG_OPUS' : 'WEBM_OPUS';
  const [result] = await _gspeech.recognize({
    config: {
      encoding: enc,
      sampleRateHertz: 48000,
      languageCode: 'en-IN',
      alternativeLanguageCodes: ['en-GB', 'en-US'],
      model: 'latest_long',
      useEnhanced: true,
      enableAutomaticPunctuation: true,
      speechContexts: [{ phrases: SPEECH_PHRASES, boost: 18 }]
    },
    audio: { content: buf.toString('base64') }
  });
  const transcript = (result.results || [])
    .map(r => (r.alternatives && r.alternatives[0] && r.alternatives[0].transcript) || '')
    .join(' ').trim();
  const confidence = (result.results || []).reduce((m, r) => {
    const c = r.alternatives && r.alternatives[0] && r.alternatives[0].confidence;
    return (c != null && (m === null || c < m)) ? c : m;
  }, null);
  return { transcript, confidence };
}

async function _transcribeOpenAI(buf, type) {
  const ext = type.indexOf('ogg') >= 0 ? 'ogg' : type.indexOf('mp4') >= 0 ? 'mp4' : 'webm';
  const form = new FormData();
  form.append('file', new Blob([buf], { type }), 'dictation.' + ext);
  form.append('model', STT_MODEL);
  form.append('language', 'en');
  form.append('prompt', STT_VOCAB_PROMPT);
  form.append('response_format', 'json');
  const r = await fetch('https://api.openai.com/v1/audio/transcriptions', {
    method: 'POST', headers: { Authorization: 'Bearer ' + OPENAI_KEY }, body: form
  });
  const body = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error((body && body.error && body.error.message) || ('HTTP ' + r.status));
  // This API returns no confidence, so report none rather than invent one.
  return { transcript: (body.text || '').trim(), confidence: null };
}

app.post('/api/transcribe', authenticateToken, async (req, res) => {
  if (!_sttProvider) {
    // 503 rather than 500: the client reads this as "fall back to the browser
    // engine", not "something is broken".
    return res.status(503).json({ error: 'STT_UNAVAILABLE', detail: _sttWhy });
  }
  const { audio, mimeType } = req.body || {};
  if (!audio) return res.status(400).json({ error: 'No audio supplied.' });
  try {
    const buf = Buffer.from(audio, 'base64');
    if (!buf.length) return res.status(400).json({ error: 'Empty audio.' });
    if (buf.length > 24 * 1024 * 1024) {
      return res.status(413).json({ error: 'Recording too long. Please dictate in shorter bursts.' });
    }
    const type = (mimeType && String(mimeType).split(';')[0]) || 'audio/webm';
    const out = _sttProvider === 'google'
      ? await _transcribeGoogle(buf, type)
      : await _transcribeOpenAI(buf, type);
    if (!out.transcript) return res.json({ transcript: '', confidence: null, empty: true });
    res.json(out);
  } catch (e) {
    console.error('[transcribe]', e.message);
    res.status(502).json({ error: 'Transcription failed', detail: e.message });
  }
});

// Lets the client pick an engine before recording a single byte.
app.get('/api/speech-status', authenticateToken, (req, res) => {
  res.json({
    available: !!_sttProvider,
    provider: _sttProvider,
    model: _sttProvider === 'openai' ? STT_MODEL : (_sttProvider === 'google' ? 'latest_long' : null),
    reason: _sttProvider ? null : _sttWhy
  });
});

// Free-form dictation from the assistant. One utterance may declare an intent
// ("I want to fill the weekly report"), carry values, or both. This works out
// which and pulls out whatever was actually said.
const dictateRouterPrompt = `You route and transcribe spoken clinical input for an oncology nutrition platform. You transcribe; you never diagnose, estimate or complete.
Return ONLY valid JSON. START with '{' and END with '}'. NO preamble, NO markdown, NO code fences.

THE ONE RULE THAT OVERRIDES EVERYTHING ELSE:
Return a value ONLY if the speaker actually said it. Never infer, estimate, carry over or supply a typical value. If it was not said, return null.
These values drive a nutrition prescription that is manufactured and dispensed. A null is safe; a plausible guess is not.

STEP 1 — INTENT. The first question is always RECORD or RETRIEVE. Recording puts new
values into the chart; retrieving reads back what is already there. "Fill the weekly
report" and "show me the weekly report" differ only in that verb, and confusing them is
the single most likely mistake here. When the verb is show / read / tell / what / which /
when / how much / is she / did she, it is RETRIEVE, no matter which form is named.

Set "intent" to exactly one of:
- "weekly"  : they want to RECORD, or are reciting, a WEEKLY monitoring assessment (week number, weight, MUAC, grip, ECOG, labs, intake, adherence).
- "profile" : they want to RECORD, or are reciting, the patient's CLINICAL PROFILE / intake details (diagnosis, regimen, stage, height, baseline labs).
- "ask"     : they want to RETRIEVE or be told something about THIS patient — "show me the latest weekly report", "what was her weight last week", "when was she last monitored", "is she overdue", "how is her albumin trending".
- "chat"    : anything else — an open clinical question, a request, small talk, or unclear.
If they only announce an intention to RECORD ("I want to fill the weekly report") with no values yet, still set intent to "weekly" and leave every field null.

For intent "ask", also fill "query": {"topic":..., "field":..., "week":...}
- topic: "latest_weekly" | "value" | "trend" | "monitoring_status" | "prescription" | "other"
- field: the field they named, one of week, weight, muac, handGrip, ecog, albumin, crp, glucose, creatinine, urea, oralIntake, compliance — else null
- week: an explicit week number if they named one, else null
"show me the latest weekly report" -> {"topic":"latest_weekly","field":null,"week":null}
"what was her albumin last week"   -> {"topic":"value","field":"albumin","week":null}
"how is her weight trending"       -> {"topic":"trend","field":"weight","week":null}
"when was she last monitored"      -> {"topic":"monitoring_status","field":null,"week":null}

STEP 2 — EXTRACT whatever values were spoken, into the matching object.

SPOKEN NUMBER HANDLING:
- Words become digits: "three point five" -> 3.5, "fifty five point seven" -> 55.7, "one twenty" -> 120.
- Strip spoken units: "fifty five point seven kilos" -> 55.7.
- "percent" is a unit, not part of the number: "intake sixty percent" -> 60.
- If a number is genuinely ambiguous between two readings, return null rather than choosing.
- oralIntake is a PERCENTAGE OF REQUIREMENT. "eating about half" -> 50. A stated deficit ("intake down forty percent") converts to the remainder -> 60.
- ecog is an integer 0 to 4 only.
- interruptions must be exactly one of "None","Dose Delay","Dose Reduction","RT Interruption","Treatment Held","Hospitalisation", else null.
- sex must be exactly "Male" or "Female", else null.
- uhic is a hospital record number, dictated digit by digit with spoken separators: "ten four two six slash twenty six" is "10426/26". Return it as a plain string, digits and separators only. If no record number was spoken, null.
- feedingMethod must be EXACTLY one of "Oral Feeding (Normal Diet)","Enteral Feeding - Nasogastric Tube (NG)","Enteral Feeding - PEG Tube","Enteral Feeding - Jejunostomy (J-Tube)","Parenteral Nutrition (TPN)","Combination Feeding (Oral + Enteral)","Combination Feeding (Enteral + Parenteral)", else null. "eating normally" or "taking orally" is the first one.
- usualWeight is the patient's weight BEFORE illness, only if stated separately from the current weight.

STEP 3 — "reply": one short sentence to show the clinician, in plain British English. If intent is "weekly" or "profile" and no values were spoken, invite them to dictate the values. If values were spoken, say what you captured in general terms. If intent is "chat", answer or acknowledge briefly. Never invent clinical advice here.
If intent is "ask", "reply" must NOT contain any clinical number. The application reads
the real values out of the patient's record and answers from those; anything you state
here would be a guess competing with the record. Acknowledge only — "Fetching her latest
weekly now." 

Schema, all keys always present:
{"intent":"weekly|profile|ask|chat",
 "reply":"string",
 "query":{"topic":null,"field":null,"week":null},
 "weekly":{"week":null,"weight":null,"muac":null,"handGrip":null,"ecog":null,"albumin":null,"crp":null,"glucose":null,"creatinine":null,"urea":null,"oralIntake":null,"compliance":null,"interruptions":null,"notes":null},
 "profile":{"name":null,"uhic":null,"age":null,"sex":null,"weight":null,"usualWeight":null,"height":null,"muac":null,"cancer":null,"regimen":null,"cancerStage":null,"feedingMethod":null,"ecogStatus":null,"albumin":null,"crp":null,"creatinine":null,"urea":null,"bloodSugar":null,"hemoglobin":null,"reducedFoodIntake":null}}`;

const DICTATE_RANGE = {
  week: [1, 60], weight: [20, 250], muac: [10, 60], handGrip: [1, 90],
  ecog: [0, 4], albumin: [1, 6], crp: [0, 400], glucose: [30, 600],
  creatinine: [0.1, 15], urea: [2, 300], oralIntake: [0, 100], compliance: [0, 100],
  age: [0, 120], height: [50, 250], usualWeight: [20, 250], ecogStatus: [0, 4], bloodSugar: [30, 600],
  hemoglobin: [2, 25], reducedFoodIntake: [0, 100]
};

// Implausible values are flagged for the clinician, never silently dropped —
// discarding a real reading is as bad as accepting a mis-heard one.
function _sanitiseDictated(obj) {
  const suspect = [];
  if (!obj || typeof obj !== 'object') return { fields: {}, suspect };
  Object.keys(obj).forEach(k => {
    const v = obj[k];
    if (v === null || v === undefined || v === '') return;
    if (!DICTATE_RANGE[k]) return;              // free-text field, leave as-is
    const n = parseFloat(v);
    if (isNaN(n)) { obj[k] = null; return; }
    if (n < DICTATE_RANGE[k][0] || n > DICTATE_RANGE[k][1]) suspect.push(k);
    obj[k] = n;
  });
  return { fields: obj, suspect };
}

app.post('/api/dictate', authenticateToken, async (req, res) => {
  const { transcript } = req.body || {};
  if (!transcript || !String(transcript).trim()) {
    return res.status(400).json({ error: 'No transcript supplied.' });
  }
  try {
    const msg = await anthropic.messages.create({
      model: "claude-haiku-4-5-20251001",
      max_tokens: 900,
      system: [{ type: "text", text: dictateRouterPrompt, cache_control: { type: "ephemeral" } }],
      messages: [{ role: "user", content: String(transcript).slice(0, 4000) }]
    });
    let raw = (msg.content[0] && msg.content[0].text) || '';
    raw = raw.replace(/^```(?:json)?\s*/m, '').replace(/```\s*$/m, '').trim();
    const start = raw.indexOf('{');
    if (start < 0) throw new Error('No JSON in model response');
    const out = JSON.parse(raw.slice(start));

    const intent = ['weekly', 'profile', 'ask', 'chat'].includes(out.intent) ? out.intent : 'chat';
    const picked = intent === 'weekly' ? out.weekly : intent === 'profile' ? out.profile : null;
    const { fields, suspect } = _sanitiseDictated(picked || {});
    const filled = Object.keys(fields).filter(k =>
      fields[k] !== null && fields[k] !== undefined && fields[k] !== '');

    res.json({
      intent,
      reply: out.reply || '',
      query: (intent === 'ask' && out.query && typeof out.query === 'object') ? out.query : null,
      fields,
      suspect,
      filledCount: filled.length,
      heard: String(transcript).trim()
    });
  } catch (e) {
    console.error('[dictate]', e.message);
    res.status(500).json({ error: 'Could not read that back. Please try again or type it in.' });
  }
});

app.post('/api/dictate-weekly', authenticateToken, async (req, res) => {
  const { transcript } = req.body || {};
  if (!transcript || !String(transcript).trim()) {
    return res.status(400).json({ error: 'No transcript supplied.' });
  }
  try {
    const msg = await anthropic.messages.create({
      model: "claude-haiku-4-5-20251001",
      max_tokens: 700,
      system: [{ type: "text", text: weeklyDictationPrompt, cache_control: { type: "ephemeral" } }],
      messages: [{ role: "user", content: String(transcript).slice(0, 4000) }]
    });
    let raw = (msg.content[0] && msg.content[0].text) || '';
    raw = raw.replace(/^```(?:json)?\s*/m, '').replace(/```\s*$/m, '').trim();
    const start = raw.indexOf('{');
    if (start < 0) throw new Error('No JSON in model response');
    const fields = JSON.parse(raw.slice(start));

    // Anything outside physiological range is returned flagged, not dropped —
    // the doctor sees it and decides. Silently discarding a real reading is as
    // bad as accepting a mis-heard one.
    const RANGE = {
      week: [1, 60], weight: [20, 250], muac: [10, 60], handGrip: [1, 90],
      ecog: [0, 4], albumin: [1, 6], crp: [0, 400], glucose: [30, 600],
      creatinine: [0.1, 15], urea: [2, 300], oralIntake: [0, 100], compliance: [0, 100]
    };
    const suspect = [];
    Object.keys(RANGE).forEach(k => {
      const v = fields[k];
      if (v === null || v === undefined || v === '') return;
      const n = parseFloat(v);
      if (isNaN(n)) { fields[k] = null; return; }
      if (n < RANGE[k][0] || n > RANGE[k][1]) suspect.push(k);
      fields[k] = n;
    });
    res.json({ fields, suspect, heard: String(transcript).trim() });
  } catch (e) {
    console.error('[dictate-weekly]', e.message);
    res.status(500).json({ error: 'Could not read that back. Please try again or type it in.' });
  }
});

// In-memory job store for async AI report generation
const __aiJobs = {};

app.get('/api/claude-report/status/:jobId', (req, res) => {
  const job = __aiJobs[req.params.jobId];
  if (!job) return res.status(404).json({ error: 'Job not found' });
  res.json(job);
});

app.post('/api/claude-report', async (req, res) => {
  const { patient, plan } = req.body;
  if (!patient || !plan) return res.status(400).json({ error: 'Context required.' });

  // Return a jobId immediately so Cloudflare doesn't timeout
  const jobId = 'job_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
  __aiJobs[jobId] = { status: 'pending' };
  res.json({ jobId });

  // Run Claude in background (no await — response already sent)
  (async () => {

  try {
    const system = `You are an Oncology Clinical Nutrition AI Auditor (PhD/RD level). You receive a patient profile and a rules-engine-generated nutrition plan. Your job is to:
1. Validate every clinical parameter against the rules below
2. Correct the prescription if it is clinically wrong
3. Produce a complete drug-nutrient interaction table for every drug in the regimen
4. Produce a complete micronutrient orders table for every relevant nutrient
5. Score the plan honestly

CLINICAL VALIDATION RULES — apply every rule to every patient:

ENTERAL ESCALATION:
- If reducedFoodIntake >= 50 (meaning actual oral intake < 50% of requirements), generate a HIGH clinicalAlert with type "EN_ESCALATION_MANDATORY".
- State that nasogastric or nasoduodenal tube feeding must be initiated immediately.

PROTEIN SAFETY:
- The renal protein cap of 0.8 g/kg applies when creatinine > 1.3 mg/dL OR urea ≥ 50 mmol/L (KDIGO guideline + renal function indicator). If the engine has already applied this cap, DO NOT override it — respect it as a non-negotiable safety ceiling.
- If creatinine ≤ 1.3 AND urea < 50: no renal cap. For cachexia OR sarcopenia patients in this case: minimum protein is 1.6 g/kg.
- For patients with BOTH (cachexia OR sarcopenia) AND (immunotherapy checkpoint inhibitor — pembrolizumab, nivolumab, atezolizumab, durvalumab — OR platinum agents) AND creatinine ≤ 1.3 AND urea < 50: minimum protein is 1.6 g/kg due to combined immunometabolic and anti-catabolic demand.
- If totalDailyProtein is below plan.calcWeight × 1.4 g/kg AND creatinine ≤ 1.3 AND urea < 50 AND cachexia or sarcopenia present: generate HIGH alert "PROTEIN_CRITICAL_UNDERDOSE", set isOverpowered:true, correctedPrescription.dailyProtein = plan.calcWeight × 1.6.
- If totalDailyProtein is below plan.calcWeight × 1.5 g/kg AND patient has BOTH (cachexia or sarcopenia) AND (immunotherapy or platinum) AND creatinine ≤ 1.3 AND urea < 50: generate HIGH alert "PROTEIN_UNDERDOSE_IMMUNOTHERAPY", set isOverpowered:true, correctedPrescription.dailyProtein = plan.calcWeight × 1.6. State that 1.6 g/kg is the minimum for this immunometabolic profile and that underdosing accelerates muscle catabolism, worsens sarcopenia, and increases chemotherapy toxicity risk.
- CRITICAL: Never raise protein above 0.8 g/kg when creatinine > 1.3 OR urea ≥ 50 — doing so risks accelerating renal failure in an oncology patient.

ANTIFOLATE TOXICITY:
- If the regimen contains Pemetrexed, Methotrexate, or FOLFIRINOX AND patient folate < 5 ng/mL: generate HIGH alert type "FOLATE_DEFICIENCY_ANTIFOLATE".
- State that folate deficiency on antifolate therapy significantly increases risk of severe mucositis, myelosuppression, and treatment-limiting neutropenia.
- Folate repletion must be initiated before the next chemotherapy cycle. Specify the repletion dose (5 mg/day folic acid), the timing of the follow-up serum folate test (Day 7 after commencing supplementation), and the cycle-day checkpoint (serum folate must be confirmed ≥ 5 ng/mL before Cycle N+1 Day 1).
- Include folate supplementation in micronutrientOrders with status DEFICIENT and dose "5 mg/day folic acid — recheck serum folate Day 7; confirm ≥5 ng/mL before next cycle."

MICRONUTRIENT RDA VALIDATION — CRITICAL RULE:
All micronutrient doses displayed in the plan are based exclusively on FSSAI/ICMR-NIN 2020 RDA values. You must NOT prescribe clinical correction doses (e.g. 4000 IU VitD, 2000 IU VitD, 500 mg VitC) in micronutrientOrders — these are not permitted for product approval.
The FSSAI/ICMR-NIN 2020 RDA values are (gender-specific where applicable — use the patient's gender):
  VitD: 600 IU/day | VitC: Male 80 mg / Female 65 mg | Zinc: Male 12 mg / Female 10 mg | Magnesium: Male 340 mg / Female 310 mg | Calcium: 600 mg | Folate maintenance: 400 mcg | VitB12 maintenance: 500 mcg | VitE: Male 15 mg / Female 12 mg | Thiamine: Male 1.4 mg / Female 1.1 mg | Riboflavin: Male 1.9 mg / Female 1.5 mg | Niacin: Male 16 mg NE / Female 12 mg NE | VitB6: 1.6 mg | Iodine: 150 mcg | VitK: 55 mcg | Sodium: 2000 mg | Potassium: 3500 mg | Fiber: Male 30 g / Female 25 g | Iron: Male 17 mg / Female 21 mg
If the engine's output for any nutrient does NOT match the correct RDA above (i.e. the engine has a bug), set status "RDA_CORRECTION" in micronutrientOrders with dose set to the exact RDA value from the table above, and rationale explaining the correction.
If the engine's output already matches the RDA, do NOT include that nutrient in micronutrientOrders with RDA_CORRECTION — leave it unchanged.
VITAMIN D: Only flag RDA_CORRECTION if the engine shows a value other than 600 IU/day. Do not prescribe clinical correction doses under any circumstances.

ANAEMIA & IRON:
- Hemoglobin < 12 g/dL: generate MODERATE alert for anaemia.
- If iron studies (ferritin, serum iron, TIBC) are absent from the lab panel: generate HIGH alert type "IRON_PANEL_MANDATORY" and flag iron panel as a mandatory investigation.
- If oral intake < 60%: recommend IV iron over oral supplementation due to impaired GI absorption.
- In micronutrientOrders, set iron status to "HOLD" and dose to "ON CLINICAL HOLD — Pending iron panel (ferritin, serum iron, TIBC, transferrin saturation) before empirical dosing."

LIVER FUNCTION:
- ALT > 40 U/L or AST > 40 U/L: generate MODERATE alert requiring fortnightly LFT monitoring.
- If patient has liver metastases or is on a hepatotoxic regimen (platinum agents, taxanes, anthracyclines): add hepatology escalation threshold of 3× ULN.

GLUTAMINE CAUTION:
- If glutamine is prescribed AND tumor burden is High or Bulky: add a LOW informational note in micronutrientOrders with status "MONITOR" noting that glutamine use in high-burden settings should be reviewed at the next oncology MDT.
- Do NOT generate a blocking alert or set HOLD status for glutamine.

STEROID-INDUCED HYPERGLYCAEMIA & MACRO REDISTRIBUTION:
- If HbA1c is 5.7–6.4% OR fasting blood sugar is 100–125 mg/dL (pre-diabetic range) AND the regimen includes dexamethasone or steroid-containing chemotherapy: generate MODERATE alert.
- Recommend blood glucose monitoring before and 2 hours after each dexamethasone dose.
- If HbA1c ≥ 6.5% (diabetic range) OR blood sugar > 140 mg/dL OR patient comorbidities include Fatty Liver Disease (NAFLD/MAFLD/NASH/steatohepatitis): the macro distribution MUST be corrected. Set isOverpowered: true. Fat must not exceed 30% of totalDailyCalories: set dailyFat = totalDailyCalories × 0.30 / 9, then set dailyCarbs = (totalDailyCalories − dailyProtein×4 − dailyFat×9) / 4. Distribute carbs across 5–6 small meals for glycaemic control. Provide the corrected gram values for dailyCarbs and dailyFat in correctedPrescription.

IMMUNOTHERAPY MONITORING:
- If regimen includes Pembrolizumab, Nivolumab, Atezolizumab, or Durvalumab: TSH monitoring every treatment cycle is MANDATORY.
- If TSH is absent from the lab panel: generate HIGH alert type "IMMUNOTHERAPY_TSH_MISSING" — this is a patient safety requirement.
- If TSH is absent AND patient sideEffects include fatigue, tiredness, or weakness: add an additional note in the alert that current fatigue symptoms must be assessed as a possible immune-related adverse event (irAE — immune thyroiditis) while TSH is pending. Do not attribute fatigue solely to chemotherapy until thyroid function is confirmed.

ANTIOXIDANT SAFETY:
- If regimen includes Bortezomib, AC (Doxorubicin + Cyclophosphamide), Oxaliplatin, or Cisplatin: Vitamin C > 500 mg/day and Alpha-Lipoic Acid are CONTRAINDICATED during those specific cycles as they may reduce chemotherapy efficacy via ROS-dependent cytotoxic mechanisms.
- If any such supplement is present in the plan without phase-specific suspension guidance: generate HIGH clinicalAlert.
- Mark these as EXCLUDED in micronutrientOrders.
- PHASE-SPECIFIC ALA RULE (sequential regimens): If the regimen is AC → Taxane (or any anthracycline-first sequential protocol), ALA may be prescribed therapeutically during the Taxane phase for peripheral neuropathy prevention, BUT must be explicitly SUSPENDED during all AC/anthracycline cycles. If the plan prescribes ALA without this phase-specific suspension instruction documented, generate a MODERATE alert type "ALA_PHASE_SUSPENSION_MISSING" stating: "ALA must be held during AC cycles and resumed only at Taxane phase commencement. Continuous ALA administration through AC cycles risks attenuating doxorubicin cytotoxicity."

BCAA & LEUCINE OVERLAP:
- If BCAA ≥ 15g/day AND Leucine is also prescribed separately: flag MODERATE alert for potential leucine excess (>13–15g/day total may exceed anabolic threshold and cause metabolic stress).

ALA EXCLUSION ON CISPLATIN:
- ALA is contraindicated during Cisplatin cycles (same rationale as oxaliplatin — platinum cytotoxicity relies on oxidative stress; ALA antioxidant activity may attenuate efficacy).
- If ALA is prescribed AND the regimen includes Cisplatin: generate HIGH alert type "ALA_CISPLATIN_CONTRAINDICATION" and set status EXCLUDED in micronutrientOrders for ALA.
- For peripheral neuropathy management on Cisplatin in a diabetic patient: recommend High-potency B-Complex only. Do NOT recommend ALA as a substitute during active Cisplatin cycles.

CISPLATIN RENAL BORDERLINE:
- If creatinine is between 1.2–1.3 mg/dL AND regimen includes Cisplatin: generate MODERATE alert type "RENAL_BORDERLINE_CISPLATIN" noting creatinine is at the nephrotoxicity threshold, weekly monitoring is mandatory, and the escalation trigger is >1.5 mg/dL (hold Cisplatin, escalate to nephrology). Do NOT classify this as "Normal."

RADIATION ENTERITIS FORMULA ADAPTATION:
- If treatmentTypes includes any form of radiation (pelvic, abdominal, EBRT, brachytherapy) OR comorbidities/sideEffects include radiation enteritis: the formula protein source MUST be peptide-based or hydrolysed whey. Flag in micronutrientOrders and rationale that intact disaccharides (e.g. Palatinose) are contraindicated — low-residue carbohydrate only. If brachytherapy is planned, note elemental formula may be required peri-procedure. Generate MODERATE alert type "RADIATION_ENTERITIS_FORMULA" if the prescribed formula uses non-adapted protein or high-residue carbohydrates.

DRUG INTERACTIONS:
- For EVERY drug or drug class named in the regimen, you MUST generate a drugInteractions entry.
- Never return an empty drugInteractions array for a patient on active chemotherapy.
- Include: Cisplatin (renal Mg wasting + nephrotoxicity threshold monitoring), Carboplatin (myelosuppression + nutrition timing), Paclitaxel/Docetaxel (peripheral neuropathy — B12/B6 relevance), Doxorubicin (cardiotoxicity — antioxidant caution), Cyclophosphamide (nausea/hydration), Pembrolizumab/nivolumab (immune enterocolitis, TSH), Pemetrexed (folate protocol), 5-FU/Capecitabine (mucositis, folate timing), Bevacizumab (wound healing, protein adequacy), Bortezomib (neuropathy, antioxidant exclusion).

ARITHMETIC VERIFICATION:
- Verify: onsCalories ÷ servingsPerDay ≈ perServingCalories (±5 kcal tolerance). Flag discrepancy in logicRefinements.
- Verify: (totalDailyProtein × 4) + (dailyCarbs × 4) + (dailyFat × 9) ≤ totalDailyCalories × 1.05. Flag if macros significantly exceed total calories.
- Verify: prescribedProtein ÷ weight = proteinPerKg matches stated proteinPerKg (±0.1 tolerance).

SCORING (max 9.8):
- Start at 9.8. This ceiling represents a clinically complete, arithmetically correct plan with all mandatory labs present and no safety violations.
- Deduct 1.5 for each HIGH/unresolved CRITICAL alert.
- Deduct 0.5 for each MODERATE gap.
- Deduct 0.3 for each missing mandatory investigation.
- Deduct 0.5 for each arithmetic error.
- Do NOT round up to 10.0. A plan with 3+ HIGH issues should score ≤ 5.3.

OVERPOWER CORRECTION:
- The plan object contains plan.calcWeight (the weight the engine used — IBW or actual) and plan.kcalPerKg. ALWAYS use plan.calcWeight for all calorie validation, NOT the raw patient weight.
- Set isOverpowered: true and provide correctedPrescription values if:
  (a) protein is underdosed per PROTEIN SAFETY rules above, OR
  (b) plan.kcalPerKg is clinically incorrect for this patient's condition — e.g. engine used 28 kcal/kg but stable non-cachexia maintenance should be 25 kcal/kg, or cachexia patient got 25 when they need 30–35. Correct correctedPrescription.dailyCalories = plan.calcWeight × correct kcal/kg. Deviation threshold: any kcal/kg value outside the clinically appropriate range for this patient. OR
  (c) NAFLD / NASH / non-alcoholic fatty liver disease is in comorbidities AND (dailyFat × 9) > (totalDailyCalories × 0.30) — fat ceiling 30% is a hard clinical protocol for hepatic steatosis.
- For case (b): state the correct kcal/kg value, why it was chosen (cachexia, maintenance, refeeding risk), and compute correctedPrescription.dailyCalories = plan.calcWeight × correct kcal/kg.
- For case (c): correctedPrescription.dailyCalories = input totalDailyCalories (unchanged), correctedPrescription.dailyProtein = input totalDailyProtein (unchanged). Compute correctedPrescription.dailyFat = floor(totalDailyCalories × 0.30 / 9) and correctedPrescription.dailyCarbs = floor((totalDailyCalories - (dailyProtein × 4) - (correctedDailyFat × 9)) / 4). Reasoning must state: "NAFLD fat ceiling 30% violated — fat [X]g ([X]%) corrected to [Y]g (30%); excess redistributed to carbohydrates [Z]g."
- Always provide a clinical reasoning string explaining the correction.

BRAND NAMES — STRICT RULE:
NEVER mention any commercial product name, brand name, or trade name (e.g. Prosure, Ensure, Fresubin, Peptamen, Nepro, Glucerna, Abbott, Nestle, Fresenius, Danone, or any other manufacturer brand). Use only generic clinical/nutrient descriptions (e.g. "high-protein ONS formula", "omega-3 enriched enteral supplement", "immunonutrition formula with EPA/DHA"). This rule applies to every field in the output including rationale, micronutrientOrders, and drugInteractions.

NUMERICAL CONSISTENCY — CRITICAL RULE — APPLIES TO ALL FIELDS (rationale, drugInteractions, everything):
The plan object contains the authoritative calculated values. You MUST use these exact numbers everywhere. NEVER recalculate protein, calories, or any macro independently.
- plan.totalDailyProtein = the total protein target (diet + formula). Use this number when telling the patient their daily protein goal. NEVER apply g/kg × patient weight yourself.
- plan.dailyProtein = the formula/supplement protein only (what the prescription provides).
- plan.estimatedDietaryProtein = protein estimated from oral diet.
- plan.totalDailyCalories = total daily calorie requirement.
- plan.dailyCalories = formula calorie contribution only.
- plan.calcWeight = the weight used for calculation (IBW or actual). NEVER use patient.weight for any calculation.
- plan.kcalPerKg and plan.proteinPerKg = the rates the engine applied.
If you disagree with a value (e.g. protein seems low for sarcopenia), set isOverpowered:true and provide correctedPrescription — do NOT silently use a different number in rationale while leaving the plan unchanged. Every number in rationale must match either plan values or correctedPrescription values.

OUTPUT FORMAT — return ONLY valid JSON, no markdown, no text outside the JSON object. CRITICAL: never embed literal newline or tab characters inside JSON string values — use \\n and \\t escape sequences if line breaks are needed in text, or omit them entirely. All string values must be valid single-line JSON strings.
{
  "validationScore": number,
  "rationale": ["string 1", "string 2", "string 3", "string 4", "string 5"],
  "correctedPrescription": {"isOverpowered": false, "dailyCalories": number, "dailyProtein": number, "dailyCarbs": number, "dailyFat": number, "reasoning": "string"},
  "logicRefinements": ["string 1", "string 2"],
  "drugInteractions": [{"drug": "string", "interaction": "string", "advice": "string", "risk": "HIGH|MODERATE|LOW"}],
  "micronutrientOrders": [{"nutrient": "string", "labValue": "string", "dose": "string", "rationale": "string", "status": "RDA_CORRECTION|EXCLUDED|HOLD|MONITOR|STANDARD"}]
}`;

    const msg = await anthropic.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 4000,
      // Prompt caching: system prompt is identical for every patient — cache reads cost 10% vs 100%
      system: [{ type: "text", text: system, cache_control: { type: "ephemeral" } }],
      messages: [{
        role: "user",
        content: `AUDIT: Patient: ${JSON.stringify(patient)} Plan: ${JSON.stringify(plan)}`
      }]
    });

    const rawText = msg.content[0].text;
    let data;

    // Escape literal control characters that appear inside JSON string values.
    // Claude occasionally writes real newlines/tabs within long string values which
    // produces "Expected ',' or ']'" errors even when the rest of the JSON is valid.
    function escapeControlsInStrings(s) {
      let out = '', inStr = false;
      for (let i = 0; i < s.length; i++) {
        const ch = s[i];
        if (!inStr) {
          out += ch;
          if (ch === '"') inStr = true;
        } else {
          if (ch === '\\') { out += ch + (s[++i] || ''); } // skip already-escaped pair
          else if (ch === '"') { out += ch; inStr = false; }
          else if (ch === '\n') out += '\\n';
          else if (ch === '\r') out += '\\r';
          else if (ch === '\t') out += '\\t';
          else if (ch.charCodeAt(0) < 32) out += ' ';
          else out += ch;
        }
      }
      return out;
    }

    try {
      // Strip markdown code fences if Claude wrapped the output
      let jsonStr = rawText.replace(/^```(?:json)?\s*/m, '').replace(/```\s*$/m, '').trim();
      const jsonStart = jsonStr.indexOf('{');
      if (jsonStart < 0) throw new Error("No JSON");
      jsonStr = jsonStr.slice(jsonStart);

      // Pass 0: sanitize literal control chars inside string values
      jsonStr = escapeControlsInStrings(jsonStr);

      // Pass 1: balance unclosed braces AND brackets
      const openB = (jsonStr.match(/{/g) || []).length;
      const closeB = (jsonStr.match(/}/g) || []).length;
      const openArr = (jsonStr.match(/\[/g) || []).length;
      const closeArr = (jsonStr.match(/\]/g) || []).length;
      if (openArr > closeArr) jsonStr += ']'.repeat(openArr - closeArr);
      if (openB > closeB) jsonStr += '}'.repeat(openB - closeB);

      // Pass 2: direct parse
      try {
        data = JSON.parse(jsonStr);
      } catch {
        // Pass 3: truncate at last cleanly-closed boundary
        const lastClean = Math.max(jsonStr.lastIndexOf('],'), jsonStr.lastIndexOf('},'));
        if (lastClean > 10) {
          let trimmed = jsonStr.substring(0, lastClean + 1);
          const o2 = (trimmed.match(/{/g) || []).length;
          const c2 = (trimmed.match(/}/g) || []).length;
          const oa2 = (trimmed.match(/\[/g) || []).length;
          const ca2 = (trimmed.match(/\]/g) || []).length;
          if (oa2 > ca2) trimmed += ']'.repeat(oa2 - ca2);
          trimmed += '}'.repeat(Math.max(0, o2 - c2));
          data = JSON.parse(trimmed);
        } else {
          throw new Error('Unrecoverable parse failure');
        }
      }
    } catch (e) {
      console.error("Claude report parse failed, raw length:", rawText?.length, e.message);
      // Salvage whatever fields are present via regex rather than returning nothing
      const grabArr = (key) => { try { const m = rawText.match(new RegExp(`"${key}"\\s*:\\s*(\\[[\\s\\S]*?\\])`)); return m ? JSON.parse(m[1]) : []; } catch { return []; } };
      const grabNum = (key) => { const m = rawText.match(new RegExp(`"${key}"\\s*:\\s*([\\d.]+)`)); return m ? parseFloat(m[1]) : null; };
      data = {
        validationScore: grabNum('validationScore'),
        rationale: grabArr('rationale'),
        correctedPrescription: { isOverpowered: false, dailyCalories: null, dailyProtein: null, reasoning: 'Response truncated — re-run audit.' },
        logicRefinements: grabArr('logicRefinements'),
        drugInteractions: grabArr('drugInteractions'),
        micronutrientOrders: grabArr('micronutrientOrders')
      };
    }
    __aiJobs[jobId] = { status: 'done', data };
    // Clean up job after 10 minutes
    setTimeout(() => { delete __aiJobs[jobId]; }, 10 * 60 * 1000);
  } catch (error) {
    console.error("Claude Report Error:", error);
    __aiJobs[jobId] = { status: 'error', error: error.message };
  }
  })();
});

// ── RULE ENGINE MANAGER ──────────────────────────────────────────────────────

// Push subscription table + load existing subs into memory
(async () => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS push_subscriptions (
        user_id TEXT PRIMARY KEY,
        subscription JSONB NOT NULL,
        updated_at TIMESTAMP DEFAULT NOW()
      )
    `);
    const rows = await pool.query('SELECT user_id, subscription FROM push_subscriptions');
    rows.rows.forEach(r => { _pushSubs[r.user_id] = r.subscription; });
    console.log(`Push: loaded ${rows.rows.length} subscription(s)`);
  } catch(e) { console.warn('push_subscriptions init:', e.message); }
})();

// Create tables on startup if they don't exist
(async () => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS monitoring_logs (
        id SERIAL PRIMARY KEY,
        patient_id TEXT NOT NULL,
        type VARCHAR(10) NOT NULL,
        recorded_at TIMESTAMP DEFAULT NOW(),
        recorded_by TEXT,
        data JSONB NOT NULL
      )
    `);
    // Patient ids are strings (e.g. 'pat_…'); coerce any legacy INTEGER columns from
    // an earlier migration to TEXT so monitoring saves don't fail on string ids.
    await pool.query(`ALTER TABLE monitoring_logs ALTER COLUMN patient_id TYPE TEXT USING patient_id::text`).catch(() => {});
    await pool.query(`ALTER TABLE monitoring_logs ALTER COLUMN recorded_by TYPE TEXT USING recorded_by::text`).catch(() => {});
  } catch(e) { console.error('monitoring_logs migration:', e.message); }
})();

// Migration: add FSSAI licence number + address to stores
(async () => {
  try {
    await pool.query('ALTER TABLE stores ADD COLUMN IF NOT EXISTS fssai_number VARCHAR(20)');
    await pool.query('ALTER TABLE stores ADD COLUMN IF NOT EXISTS address TEXT');
  } catch(e) { console.error('stores fssai_number/address migration:', e.message); }
})();

// Migration: ensure manufacturing_jobs table exists (production queue / approvals)
(async () => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS manufacturing_jobs (
        id TEXT PRIMARY KEY,
        patient_id TEXT,
        store_id TEXT,
        doctor_id TEXT,
        status TEXT DEFAULT 'APPROVED',
        history JSONB DEFAULT '[]'::jsonb,
        created_at TIMESTAMPTZ DEFAULT NOW(),
        updated_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);
    // Label fields
    await pool.query('ALTER TABLE manufacturing_jobs ADD COLUMN IF NOT EXISTS batch_no TEXT');
    await pool.query('ALTER TABLE manufacturing_jobs ADD COLUMN IF NOT EXISTS mfg_date DATE');
    await pool.query('ALTER TABLE manufacturing_jobs ADD COLUMN IF NOT EXISTS exp_date DATE');
    // Product pricing: store price → platform markup → doctor share → final MRP.
    await pool.query(`ALTER TABLE manufacturing_jobs
      ADD COLUMN IF NOT EXISTS price_status      TEXT,
      ADD COLUMN IF NOT EXISTS store_price       NUMERIC(12,2),
      ADD COLUMN IF NOT EXISTS markup_pct        NUMERIC(6,2),
      ADD COLUMN IF NOT EXISTS base_price        NUMERIC(12,2),
      ADD COLUMN IF NOT EXISTS doctor_pct        NUMERIC(10,2),
      ADD COLUMN IF NOT EXISTS doctor_amount     NUMERIC(12,2),
      ADD COLUMN IF NOT EXISTS final_price       NUMERIC(12,2),
      ADD COLUMN IF NOT EXISTS price_note        TEXT,
      ADD COLUMN IF NOT EXISTS store_priced_by   TEXT,
      ADD COLUMN IF NOT EXISTS store_priced_at   TIMESTAMPTZ,
      ADD COLUMN IF NOT EXISTS price_approved_by TEXT,
      ADD COLUMN IF NOT EXISTS price_approved_at TIMESTAMPTZ`);
    // doctor_pct is now derived from a free rupee amount, so it can exceed 9999 %.
    await pool.query('ALTER TABLE manufacturing_jobs ALTER COLUMN doctor_pct TYPE NUMERIC(10,2)');
    const bf = await reconcileJobs();
    if (bf.created) console.log('manufacturing_jobs backfill: created ' + bf.created + ' job(s) for approved patients.');
  } catch(e) { console.error('manufacturing_jobs migration:', e.message); }
})();

// Weekly prescriptions table
(async () => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS weekly_prescriptions (
        id                  SERIAL PRIMARY KEY,
        patient_id          TEXT NOT NULL,
        week_number         INT  NOT NULL,
        monitoring_log_id   INT,
        batch_code          TEXT UNIQUE,
        clinical_params     JSONB,
        targets             JSONB,
        baseline_snapshot   JSONB,
        notes               TEXT,
        status              TEXT NOT NULL DEFAULT 'PENDING_REVIEW',
        created_by          TEXT,
        approved_by         TEXT,
        approved_at         TIMESTAMPTZ,
        created_at          TIMESTAMPTZ DEFAULT NOW(),
        updated_at          TIMESTAMPTZ DEFAULT NOW(),
        UNIQUE(patient_id, week_number)
      )
    `);
    await pool.query('CREATE INDEX IF NOT EXISTS idx_weekly_rx_patient ON weekly_prescriptions(patient_id)');
    // Editing a weekly log after the doctor approved it has to send the row back
    // for approval — the numbers changed. But it must not look like a brand-new
    // pending item, or the doctor cannot tell "never reviewed" from "reviewed,
    // then the data moved under me". A separate status value would break the
    // several places that test for APPROVED / PENDING_REVIEW, so the fact is
    // carried alongside the status instead.
    await pool.query(`ALTER TABLE weekly_prescriptions
                        ADD COLUMN IF NOT EXISTS reopened_at TIMESTAMPTZ`);
    await pool.query(`ALTER TABLE weekly_prescriptions
                        ADD COLUMN IF NOT EXISTS previously_approved_at TIMESTAMPTZ`);
    console.log('weekly_prescriptions table ready');
  } catch(e) { console.error('weekly_prescriptions migration:', e.message); }
})();

// ── Patient drafts ────────────────────────────────────────────────────────
// Deliberately NOT a row in `patients` with status='DRAFT'. Two reasons:
//
//  1. patients.name is NOT NULL and patients.uhic is UNIQUE NOT NULL — which
//     is exactly the state a draft is allowed to be in. An unnamed draft
//     cannot be inserted at all, and two drafts without a UHIC collide.
//  2. Nineteen queries read FROM patients and none filter on status. A draft
//     row would surface in the risk panel, the weekly queue, trial exports
//     and the dashboard list, and every one of those would need patching.
//
// Keeping drafts in their own table makes the "no plan is ever generated for
// a draft" guarantee structural rather than a filter someone has to remember:
// nothing that reads `patients` can see them, so the engine is never invoked,
// no nutrition_plans row appears, and no store ever receives a job.
(async () => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS patient_drafts (
        id             TEXT PRIMARY KEY,
        doctor_id      TEXT NOT NULL,
        created_by_id  TEXT,
        patient_name   TEXT,
        data           JSONB NOT NULL DEFAULT '{}'::jsonb,
        sources        JSONB NOT NULL DEFAULT '{}'::jsonb,
        next_question  INT DEFAULT 0,
        created_at     TIMESTAMPTZ DEFAULT NOW(),
        updated_at     TIMESTAMPTZ DEFAULT NOW()
      )
    `);
    await pool.query('CREATE INDEX IF NOT EXISTS idx_patient_drafts_doctor ON patient_drafts(doctor_id)');
    console.log('patient_drafts table ready');
  } catch(e) { console.error('patient_drafts migration:', e.message); }
})();

// ── Patient closures ──────────────────────────────────────────────────────
// Until now a patient who stopped simply went quiet. trial_enrollments could
// record a withdrawal, but only for pilot patients, only by an admin, and the
// reason was free text — so "discharged", "Discharged" and "pt went home" were
// three different values and none of them could be counted.
//
// The consequence is that every patient who stops looks identical. A pilot
// reading "46 enrolled, 6 completed" implies 40 failures, when most of those
// are discharges, clinician decisions or deaths — outcomes, not dropouts. Only
// "lost to contact" is a genuine loss to follow-up.
//
// Closing a patient properly is therefore not bookkeeping; it is what makes
// the retention number mean anything.
(async () => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS activity_events (
        id SERIAL PRIMARY KEY,
        at TIMESTAMPTZ DEFAULT NOW(),
        type TEXT NOT NULL,
        title TEXT,
        body TEXT,
        patient_id TEXT,
        job_id TEXT,
        actor_id TEXT,
        actor_role TEXT
      );
      CREATE TABLE IF NOT EXISTS patient_closures (
        patient_id     TEXT PRIMARY KEY,
        reason         TEXT NOT NULL,
        note           TEXT,
        closed_by      TEXT NOT NULL,
        closed_by_role TEXT,
        closed_at      TIMESTAMPTZ DEFAULT NOW(),
        -- what the patient looked like at the moment they stopped, so a closed
        -- record still carries its outcome without re-deriving it later
        last_week      INT,
        last_weight    DOUBLE PRECISION,
        -- an assistant may record the administrative reasons; the doctor is
        -- asked to confirm, and owns the clinical ones outright
        confirmed_by   TEXT,
        confirmed_at   TIMESTAMPTZ,
        reopened_at    TIMESTAMPTZ,
        reopened_by    TEXT
      )
    `);
    await pool.query('CREATE INDEX IF NOT EXISTS idx_patient_closures_reason ON patient_closures(reason)');
    console.log('patient_closures table ready');
  } catch(e) { console.error('patient_closures migration:', e.message); }
})();

// The fixed reason list. Grouped so the retention story reads correctly, and
// so the funnel can separate an outcome from an actual loss.
const CLOSURE_REASONS = {
  // Clinical decisions — the doctor owns these outright.
  COMPLETED:        { label:'Completed the programme',        group:'planned',    clinical:true },
  GOAL_MET:         { label:'Stopped — nutritional goal met', group:'planned',    clinical:true },
  ROUTE_CHANGED:    { label:'Switched to NG tube / TPN',      group:'planned',    clinical:true },
  PALLIATIVE:       { label:'Moved to palliative care',       group:'transition', clinical:true },
  // Administrative facts — whoever chases follow-up learns these first.
  DISCHARGED:       { label:'Discharged home',                group:'transition', clinical:false },
  TRANSFERRED:      { label:'Transferred to another centre',  group:'transition', clinical:false },
  DECLINED:         { label:'Patient declined to continue',   group:'patient',    clinical:false },
  COST:             { label:'Could not afford it',            group:'patient',    clinical:false },
  INTOLERANT:       { label:'Could not tolerate the product', group:'patient',    clinical:false },
  DIED:             { label:'Died',                           group:'patient',    clinical:false },
  // The only reason that is genuinely a loss to follow-up.
  LOST:             { label:'No contact after repeated attempts', group:'lost',   clinical:false }
};

app.get('/api/closure-reasons', authenticateToken, (req, res) => {
  const role = (req.user && req.user.role) || '';
  const canClinical = ['DOCTOR','ADMIN','SUPER_ADMIN'].includes(role);
  res.json({
    reasons: Object.entries(CLOSURE_REASONS).map(([k, v]) => ({
      key: k, label: v.label, group: v.group, clinical: v.clinical,
      allowed: v.clinical ? canClinical : true
    })),
    canCloseClinical: canClinical
  });
});

// Close a patient. Works for ANY patient, not only trial-enrolled ones.
app.post('/api/patients/:id/close', authenticateToken, async (req, res) => {
  const { reason, note } = req.body || {};
  const spec = CLOSURE_REASONS[reason];
  if (!spec) return res.status(400).json({ error: 'Unknown closure reason' });

  const role = (req.user && req.user.role) || '';
  const isDoctor = ['DOCTOR','ADMIN','SUPER_ADMIN'].includes(role);
  // A clinical ending is a clinical decision. An assistant may record that a
  // patient was discharged; they may not record that treatment was stopped
  // because the nutritional goal was met.
  if (spec.clinical && !isDoctor) {
    return res.status(403).json({ error: 'Only the doctor can record a clinical closure' });
  }

  try {
    // Snapshot where the patient had reached, so the closed record still says
    // something even after the monitoring rows age.
    const last = await pool.query(
      `SELECT data FROM monitoring_logs
        WHERE patient_id=$1 AND type='weekly'
        ORDER BY recorded_at DESC, id DESC LIMIT 1`, [req.params.id]);
    let lastWeek = null, lastWeight = null;
    if (last.rowCount){
      let d = last.rows[0].data;
      if (typeof d === 'string') { try { d = JSON.parse(d); } catch(e) { d = {}; } }
      lastWeek   = d && d.week   != null ? parseInt(d.week)      : null;
      lastWeight = d && d.weight != null ? parseFloat(d.weight)  : null;
      if (isNaN(lastWeek))   lastWeek = null;
      if (isNaN(lastWeight)) lastWeight = null;
    }

    await pool.query(
      `INSERT INTO patient_closures
         (patient_id, reason, note, closed_by, closed_by_role, last_week, last_weight, confirmed_by, confirmed_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       ON CONFLICT (patient_id) DO UPDATE SET
         reason=EXCLUDED.reason, note=EXCLUDED.note, closed_by=EXCLUDED.closed_by,
         closed_by_role=EXCLUDED.closed_by_role, closed_at=NOW(),
         last_week=EXCLUDED.last_week, last_weight=EXCLUDED.last_weight,
         confirmed_by=EXCLUDED.confirmed_by, confirmed_at=EXCLUDED.confirmed_at,
         reopened_at=NULL, reopened_by=NULL`,
      [req.params.id, reason, note || null, req.user.id, role, lastWeek, lastWeight,
       // A doctor closing it is its own confirmation.
       isDoctor ? req.user.id : null, isDoctor ? new Date() : null]
    );

    // Keep the pilot record in step, so trial reporting and closures agree.
    await pool.query(
      `UPDATE trial_enrollments SET withdrawn_at=NOW(), withdrawn_reason=$2 WHERE patient_id=$1`,
      [req.params.id, reason]
    ).catch(() => {});

    res.json({ ok:true, reason, label: spec.label, needsConfirmation: !isDoctor });
    recordEvent({ type: 'patient_closed', title: '⛔ Patient closed',
      body: `{actor} closed {patient}: ${spec.label}${note ? ' — ' + String(note).slice(0, 200) : ''}.`,
      patientId: req.params.id, user: req.user });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// The doctor confirming a closure an assistant recorded.
app.post('/api/patients/:id/close/confirm', authenticateToken, async (req, res) => {
  const role = (req.user && req.user.role) || '';
  if (!['DOCTOR','ADMIN','SUPER_ADMIN'].includes(role)) {
    return res.status(403).json({ error: 'Only the doctor can confirm a closure' });
  }
  try {
    const r = await pool.query(
      `UPDATE patient_closures SET confirmed_by=$2, confirmed_at=NOW()
        WHERE patient_id=$1 AND reopened_at IS NULL
        RETURNING patient_id`, [req.params.id, req.user.id]);
    if (!r.rowCount) return res.status(404).json({ error: 'No closure to confirm' });
    res.json({ ok:true });
    recordEvent({ type: 'patient_closure_confirmed', title: 'Closure confirmed',
      body: `{actor} confirmed the closure of {patient}.`, patientId: req.params.id, user: req.user });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Patients come back. Closure must never be a one-way door.
//
// This stamps the closure as reopened rather than deleting it. Deleting erased
// the fact that the patient had ever stopped, so someone who withdrew in week 3
// and returned in week 6 counted as a continuous six-week patient and the gap
// vanished from the retention funnel — the exact dishonesty structured closures
// exist to prevent. Every read of this table is scoped to reopened_at IS NULL,
// so the patient behaves as fully active again; only the history survives.
app.post('/api/patients/:id/reopen', authenticateToken, async (req, res) => {
  try {
    const r = await pool.query(
      `UPDATE patient_closures SET reopened_at=NOW(), reopened_by=$2
        WHERE patient_id=$1 AND reopened_at IS NULL
        RETURNING reason`, [req.params.id, req.user.id]);
    if (!r.rowCount) return res.status(404).json({ error: 'Patient is not closed' });
    await pool.query(
      `UPDATE trial_enrollments SET withdrawn_at=NULL, withdrawn_reason=NULL WHERE patient_id=$1`,
      [req.params.id]).catch(() => {});
    res.json({ ok:true, was: r.rows[0].reason });
    recordEvent({ type: 'patient_reopened', title: '↩️ Patient reopened',
      body: `{actor} reopened {patient}.`, patientId: req.params.id, user: req.user });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Retention funnel ──────────────────────────────────────────────────────
// The chart that makes a pilot legible: how far each patient got, and for the
// ones who stopped, why. Separates outcomes from genuine loss to follow-up,
// which is the difference between "40 dropped out" and "2 were lost".
app.get('/api/retention-funnel', authenticateToken, async (req, res) => {
  try {
    const role = (req.user && req.user.role) || '';
    const isAdmin = ['ADMIN','SUPER_ADMIN'].includes(role);
    const docId = req.query.doctorId || req.user.id;

    const pats = isAdmin && !req.query.doctorId
      ? await pool.query('SELECT id, name FROM patients')
      : await pool.query(
          `SELECT id, name FROM patients
            WHERE assigned_doctor_id=$1 OR full_data->>'assignedDoctorId'=$1`, [docId]);
    const ids = pats.rows.map(p => p.id);
    if (!ids.length) return res.json({ enrolled:0, stages:[], closures:[], lostToFollowUp:0 });

    const weeks = await pool.query(
      `SELECT patient_id, COUNT(*)::int AS n FROM monitoring_logs
        WHERE patient_id = ANY($1) AND type='weekly' GROUP BY patient_id`, [ids]);
    const byPatient = {};
    weeks.rows.forEach(r => { byPatient[r.patient_id] = r.n; });

    const reached = k => ids.filter(id => (byPatient[id] || 0) >= k).length;
    const stages = [
      { stage:'Enrolled', n: ids.length },
      { stage:'Week 1',   n: reached(1) },
      { stage:'Week 2',   n: reached(2) },
      { stage:'Week 4',   n: reached(4) },
      { stage:'Week 6',   n: reached(6) }
    ];

    const cl = await pool.query(
      `SELECT reason, COUNT(*)::int AS n FROM patient_closures
        WHERE patient_id = ANY($1) AND reopened_at IS NULL
        GROUP BY reason ORDER BY n DESC`, [ids]);
    const closures = cl.rows.map(r => ({
      reason: r.reason,
      label: (CLOSURE_REASONS[r.reason] || {}).label || r.reason,
      group: (CLOSURE_REASONS[r.reason] || {}).group || 'other',
      n: r.n
    }));
    const closedTotal = closures.reduce((a, c) => a + c.n, 0);
    const lost = closures.filter(c => c.group === 'lost').reduce((a, c) => a + c.n, 0);

    // Patients who stopped and came back. Worth stating plainly: they are
    // counted as active above (correctly), but a funnel that silently absorbs
    // them reads as though nobody ever interrupted treatment.
    const ret = await pool.query(
      `SELECT reason, COUNT(*)::int AS n FROM patient_closures
        WHERE patient_id = ANY($1) AND reopened_at IS NOT NULL
        GROUP BY reason ORDER BY n DESC`, [ids]);
    const returnedBreakdown = ret.rows.map(r => ({
      reason: r.reason,
      label: (CLOSURE_REASONS[r.reason] || {}).label || r.reason,
      n: r.n
    }));
    const returnedTotal = returnedBreakdown.reduce((a, c) => a + c.n, 0);

    res.json({
      enrolled: ids.length,
      stages,
      closures,
      closedTotal,
      // The honest headline: everything else was an outcome, not a dropout.
      lostToFollowUp: lost,
      stillOpen: ids.length - closedTotal,
      // Interrupted treatment and resumed — active now, but not continuous.
      returnedTotal,
      returnedBreakdown
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Assistants act for their doctor; everyone else owns their own drafts.
// A draft holds unverified, partly-entered clinical values, so it is visible
// only to the doctor it belongs to — not to the whole clinic.
function _draftOwner(req) {
  // An assistant's drafts belong to their mapped doctor, whatever the browser sent.
  if (req.user && req.user.role === 'ASSISTANT' && _mappedDoctor(req.user.id)) return _mappedDoctor(req.user.id);
  const asked = req.query.doctorId || (req.body && req.body.doctorId) || req.user.id;
  return _mappedDoctor(asked) || asked;
}

// List this doctor's drafts. Returns a summary per draft — enough for the
// dashboard card (name, progress, what is still missing) without shipping
// every field of every draft.
app.get('/api/drafts', authenticateToken, async (req, res) => {
  try {
    const r = await pool.query(
      `SELECT id, patient_name, data, sources, next_question, created_at, updated_at
         FROM patient_drafts WHERE doctor_id = $1 ORDER BY updated_at DESC`,
      [_draftOwner(req)]
    );
    // Mirrors the client's tiers — keep the two lists in step if either changes.
    const BLOCKING  = ['patientName','age','sex','cancerInput','weight','height'];
    const ESSENTIAL = BLOCKING.concat(['usualWeight','albumin','crp','ecogStatus',
                                       'reducedFoodIntake','feedingMethod','creatinine']);
    const out = r.rows.map(d => {
      const data = d.data || {}, src = d.sources || {};
      const has = k => src[k] === 'doctor' || src[k] === 'na';
      return {
        id: d.id,
        patientName: d.patient_name || null,
        answered: ESSENTIAL.filter(has).length,
        essentialTotal: ESSENTIAL.length,
        missingBlocking: BLOCKING.filter(k => src[k] !== 'doctor'),
        fieldsFilled: Object.keys(src).filter(k => src[k] === 'doctor').length,
        nextQuestion: d.next_question,
        createdAt: d.created_at,
        updatedAt: d.updated_at
      };
    });
    res.json({ drafts: out });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Create or update. Called by the Save button AND by autosave, so it must be
// cheap and idempotent — the client owns the id and upserts against it.
app.post('/api/drafts', authenticateToken, async (req, res) => {
  const { id, patientName, data, sources, nextQuestion } = req.body || {};
  if (!id) return res.status(400).json({ error: 'id required' });
  try {
    const r = await pool.query(
      `INSERT INTO patient_drafts (id, doctor_id, created_by_id, patient_name, data, sources, next_question)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       ON CONFLICT (id) DO UPDATE SET
         patient_name = EXCLUDED.patient_name,
         data         = EXCLUDED.data,
         sources      = EXCLUDED.sources,
         next_question= EXCLUDED.next_question,
         updated_at   = NOW()
       WHERE patient_drafts.doctor_id = EXCLUDED.doctor_id
       RETURNING id, updated_at`,
      [id, _draftOwner(req), req.user.id, patientName || null,
       JSON.stringify(data || {}), JSON.stringify(sources || {}), nextQuestion || 0]
    );
    if (!r.rowCount) return res.status(403).json({ error: 'Not your draft' });
    res.json({ id: r.rows[0].id, updatedAt: r.rows[0].updated_at, saved: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Load one draft to resume it.
app.get('/api/drafts/:id', authenticateToken, async (req, res) => {
  try {
    const r = await pool.query(
      `SELECT * FROM patient_drafts WHERE id = $1 AND doctor_id = $2`,
      [req.params.id, _draftOwner(req)]
    );
    if (!r.rowCount) return res.status(404).json({ error: 'Draft not found' });
    const d = r.rows[0];
    res.json({ id: d.id, patientName: d.patient_name, data: d.data || {},
               sources: d.sources || {}, nextQuestion: d.next_question,
               createdAt: d.created_at, updatedAt: d.updated_at });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/drafts/:id', authenticateToken, async (req, res) => {
  try {
    const r = await pool.query(
      `DELETE FROM patient_drafts WHERE id = $1 AND doctor_id = $2 RETURNING id`,
      [req.params.id, _draftOwner(req)]
    );
    if (!r.rowCount) return res.status(404).json({ error: 'Draft not found' });
    res.json({ deleted: r.rows[0].id });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── The one gate ──────────────────────────────────────────────────────────
// The ONLY route from draft to patient. Everything downstream — the nutrition
// engine, the store queue, the weekly prescriptions — begins on the far side
// of this call, so the completeness check lives here and nowhere else.
app.post('/api/drafts/:id/activate', authenticateToken, async (req, res) => {
  const BLOCKING = { patientName:'Patient Name', age:'Age', sex:'Sex',
                     cancerInput:'Cancer Type', weight:'Current Weight', height:'Height' };
  try {
    const dr = await pool.query(
      `SELECT * FROM patient_drafts WHERE id = $1 AND doctor_id = $2`,
      [req.params.id, _draftOwner(req)]
    );
    if (!dr.rowCount) return res.status(404).json({ error: 'Draft not found' });
    const draft = dr.rows[0];
    const data  = draft.data || {};
    const src   = draft.sources || {};

    // A field marked "not available" does not satisfy a blocking requirement.
    const missing = Object.keys(BLOCKING).filter(k => src[k] !== 'doctor');
    if (missing.length) {
      return res.status(422).json({
        error: 'Draft is incomplete',
        missing,
        missingLabels: missing.map(k => BLOCKING[k])
      });
    }

    // UHIC is UNIQUE NOT NULL. If the doctor never entered one, mint a stable
    // fallback rather than failing the insert or writing an empty string that
    // would collide with the next patient in the same position.
    const patientId = req.body.patientId || ('pat_' + Date.now() + '_' + Math.floor(Math.random() * 1e6));
    const uhic = (data.uhic && String(data.uhic).trim())
      || ('UH-' + patientId.replace(/[^a-zA-Z0-9]/g, '').slice(-8).toUpperCase());

    const payload = Object.assign({}, data, {
      id: patientId,
      uhic,
      name: data.patientName,
      cancer: data.cancerInput,
      regimen: data.regimenInput,
      status: 'CREATED',
      assignedDoctorId: _mappedDoctor(draft.doctor_id) || draft.doctor_id,
      createdDate: new Date().toISOString().slice(0, 10),
      // Which values the doctor actually stated, and which were recorded as
      // unavailable. Carried onto the patient so the plan can flag that it was
      // built on incomplete data instead of silently treating gaps as zeroes.
      fieldSources: src,
      unavailableFields: Object.keys(src).filter(k => src[k] === 'na'),
      createdFromDraft: draft.id
    });

    res.json({ ok: true, patient: payload, draftId: draft.id });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Called once the client has successfully written the patient, so a failed
// save never destroys the draft it came from.
app.post('/api/drafts/:id/complete', authenticateToken, async (req, res) => {
  try {
    await pool.query(`DELETE FROM patient_drafts WHERE id = $1 AND doctor_id = $2`,
      [req.params.id, _draftOwner(req)]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Clinical Trials module — enrollment records + pilot settings
(async () => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS trial_enrollments (
        patient_id       TEXT PRIMARY KEY,
        study_id         TEXT UNIQUE NOT NULL,
        enrollment_date  DATE NOT NULL,
        cohort           TEXT DEFAULT 'PILOT-1',
        withdrawn_at     TIMESTAMPTZ,
        withdrawn_reason TEXT,
        created_at       TIMESTAMPTZ DEFAULT NOW()
      )
    `);
    await pool.query('CREATE INDEX IF NOT EXISTS idx_trial_enrollments_study ON trial_enrollments(study_id)');
    await pool.query(`
      CREATE TABLE IF NOT EXISTS pilot_settings (
        id                  INT PRIMARY KEY DEFAULT 1,
        target_patients     INT DEFAULT 30,
        pilot_weeks         INT DEFAULT 6,
        lost_threshold_days INT DEFAULT 14,
        CHECK (id = 1)
      )
    `);
    await pool.query(`INSERT INTO pilot_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING`);
  } catch(e) { console.error('clinical trials migration:', e.message); }
})();

// Hospitals as a real entity — normalizes the free-text hospital names on users/stores.
(async () => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS hospitals (
        id         TEXT PRIMARY KEY,
        name       TEXT UNIQUE NOT NULL,
        city       TEXT,
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);
    await pool.query('ALTER TABLE users  ADD COLUMN IF NOT EXISTS hospital_id TEXT');
    await pool.query('ALTER TABLE stores ADD COLUMN IF NOT EXISTS hospital_id TEXT');

    // One-time backfill: create a hospital per distinct typed name and link users/stores.
    const names = await pool.query(`
      SELECT DISTINCT TRIM(hospital_name) AS nm FROM users  WHERE hospital_name IS NOT NULL AND TRIM(hospital_name) <> ''
      UNION
      SELECT DISTINCT TRIM(hospital)      AS nm FROM stores WHERE hospital      IS NOT NULL AND TRIM(hospital)      <> ''
    `);
    for (const row of names.rows) {
      const nm = row.nm;
      let hid;
      const ex = await pool.query('SELECT id FROM hospitals WHERE LOWER(name)=LOWER($1) LIMIT 1', [nm]);
      if (ex.rows[0]) hid = ex.rows[0].id;
      else {
        hid = 'hosp_' + Date.now() + '_' + Math.floor(Math.random() * 100000);
        await pool.query('INSERT INTO hospitals (id, name) VALUES ($1,$2) ON CONFLICT (name) DO NOTHING', [hid, nm]);
        const r2 = await pool.query('SELECT id FROM hospitals WHERE LOWER(name)=LOWER($1) LIMIT 1', [nm]);
        hid = r2.rows[0] ? r2.rows[0].id : hid;
      }
      await pool.query('UPDATE users  SET hospital_id=$1 WHERE hospital_id IS NULL AND LOWER(TRIM(hospital_name))=LOWER($2)', [hid, nm]);
      await pool.query('UPDATE stores SET hospital_id=$1 WHERE hospital_id IS NULL AND LOWER(TRIM(hospital))=LOWER($2)', [hid, nm]);
    }
  } catch(e) { console.error('hospitals migration:', e.message); }
})();

(async () => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS ai_corrections (
        id TEXT PRIMARY KEY,
        patient_id TEXT,
        plan_id TEXT,
        patient_name TEXT,
        cancer TEXT,
        regimen TEXT,
        changes JSONB,
        reason TEXT,
        patient_context JSONB,
        status TEXT DEFAULT 'pending',
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);
    await pool.query(`
      CREATE TABLE IF NOT EXISTS engine_rules (
        id TEXT PRIMARY KEY,
        rule_name TEXT NOT NULL,
        condition_description TEXT,
        target_field TEXT NOT NULL,
        operator TEXT NOT NULL,
        value TEXT NOT NULL,
        reason TEXT,
        source_correction_id TEXT,
        confirmed_by TEXT,
        status TEXT DEFAULT 'pending',
        created_at TIMESTAMPTZ DEFAULT NOW(),
        confirmed_at TIMESTAMPTZ
      )
    `);
    await pool.query(`
      CREATE TABLE IF NOT EXISTS engine_formulas (
        id TEXT PRIMARY KEY,
        category TEXT NOT NULL,
        name TEXT NOT NULL,
        description TEXT,
        value TEXT NOT NULL,
        unit TEXT,
        source TEXT,
        editable BOOLEAN DEFAULT true,
        updated_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // Seed engine_formulas — always runs, ON CONFLICT (id) DO NOTHING skips existing rows
    {
      const formulas = [
        // ── Calorie Targets ───────────────────────────────────────────────────
        { id:'kcal_stable',               category:'calories',     name:'kcal_stable',               description:'Calorie target — Stable, no cachexia or significant risk',                                     value:'25',   unit:'kcal/kg',      source:'ESPEN Oncology 2021' },
        { id:'kcal_moderate_risk',        category:'calories',     name:'kcal_moderate_risk',        description:'Calorie target — Moderate risk (WL ≥5%, ECOG ≥2, Age ≥70)',                                   value:'30',   unit:'kcal/kg',      source:'ESPEN Oncology 2021' },
        { id:'kcal_cachexia',             category:'calories',     name:'kcal_cachexia',             description:'Calorie target — Cachexia/Severe (albumin <3.5, WL ≥10%, BMI <18.5, CRP >10, sarcopenia)',    value:'35',   unit:'kcal/kg',      source:'ESPEN Oncology 2021' },
        { id:'kcal_active_chemo_min',     category:'calories',     name:'kcal_active_chemo_min',     description:'Minimum calorie floor for any active chemotherapy regimen (stable patients)',                   value:'28',   unit:'kcal/kg',      source:'ESPEN Oncology 2021' },
        { id:'kcal_appetite_loss_floor',  category:'calories',     name:'kcal_appetite_loss_floor',  description:'Calorie floor when appetite loss side effect is present',                                       value:'32',   unit:'kcal/kg',      source:'Clinical' },
        // ── Protein Targets ───────────────────────────────────────────────────
        { id:'protein_baseline',          category:'protein',      name:'protein_baseline',          description:'Protein target — Baseline stable (no cachexia/moderate risk)',                                  value:'1.4',  unit:'g/kg',         source:'ESPEN Oncology 2021' },
        { id:'protein_cachexia',          category:'protein',      name:'protein_cachexia',          description:'Protein target — Cachexia or moderate risk',                                                   value:'1.8',  unit:'g/kg',         source:'ESPEN Oncology 2021' },
        { id:'protein_renal',             category:'protein',      name:'protein_renal',             description:'Protein cap — Renal disease/impairment (KDIGO strict limit, highest priority)',                 value:'0.8',  unit:'g/kg',         source:'KDIGO 2012' },
        { id:'protein_elderly_min',       category:'protein',      name:'protein_elderly_min',       description:'Protein floor — Elderly patients (Age ≥70)',                                                   value:'1.5',  unit:'g/kg',         source:'ESPEN Geriatric 2018' },
        { id:'protein_high_catabolism',   category:'protein',      name:'protein_high_catabolism',   description:'Protein target — High catabolism (Platinum/FOLFIRINOX/immunotherapy + cachexia or sarcopenia)', value:'2.0',  unit:'g/kg',         source:'ESPEN Oncology 2021' },
        // ── Ideal Body Weight (Devine Formula) ───────────────────────────────
        { id:'ibw_base_male',             category:'weight',       name:'ibw_base_male',             description:'IBW base weight for males at exactly 5 ft (Devine Formula)',                                    value:'50',   unit:'kg',           source:'Devine 1974' },
        { id:'ibw_base_female',           category:'weight',       name:'ibw_base_female',           description:'IBW base weight for females at exactly 5 ft (Devine Formula)',                                  value:'45.5', unit:'kg',           source:'Devine 1974' },
        { id:'ibw_per_inch',              category:'weight',       name:'ibw_per_inch',              description:'IBW increment per inch of height above 5 ft (Devine Formula)',                                  value:'2.3',  unit:'kg/inch',      source:'Devine 1974' },
        { id:'adjbw_factor',              category:'weight',       name:'adjbw_factor',              description:'Adjusted Body Weight factor (fraction of excess weight added to IBW when BMI ≥30)',             value:'0.25', unit:'fraction',     source:'ASPEN' },
        { id:'bmi_obesity_threshold',     category:'weight',       name:'bmi_obesity_threshold',     description:'BMI threshold above which AdjBW replaces Actual Body Weight for calorie calculation',           value:'30',   unit:'kg/m²',        source:'ESPEN/ASPEN' },
        // ── Risk Scoring ──────────────────────────────────────────────────────
        { id:'albumin_low_threshold',     category:'risk_scoring', name:'albumin_low_threshold',     description:'Albumin below this value adds +2 to nutrition risk score',                                      value:'3.5',  unit:'g/dL',         source:'GLIM Criteria 2019' },
        { id:'albumin_critical_threshold',category:'risk_scoring', name:'albumin_critical_threshold',description:'Albumin below this value used as a compound malnutrition factor',                               value:'3.0',  unit:'g/dL',         source:'Clinical' },
        { id:'weight_loss_high',          category:'risk_scoring', name:'weight_loss_high',          description:'Weight loss at or above this value adds +2 to risk score (cachexia trigger)',                   value:'10',   unit:'%',            source:'GLIM/MUST' },
        { id:'weight_loss_moderate',      category:'risk_scoring', name:'weight_loss_moderate',      description:'Weight loss at or above this value adds +1 to risk score (moderate risk trigger)',              value:'5',    unit:'%',            source:'GLIM/MUST' },
        { id:'bmi_low_threshold',         category:'risk_scoring', name:'bmi_low_threshold',         description:'BMI below this value adds +2 to risk score (cachexia trigger)',                                 value:'18.5', unit:'kg/m²',        source:'MUST Score' },
        { id:'bmi_must_moderate',         category:'risk_scoring', name:'bmi_must_moderate',         description:'BMI at or below this value adds +1 to MUST score',                                             value:'20',   unit:'kg/m²',        source:'MUST Score' },
        { id:'ecog_moderate_threshold',   category:'risk_scoring', name:'ecog_moderate_threshold',   description:'ECOG at or above this value triggers moderate risk classification and +1 risk score',           value:'2',    unit:'ECOG',         source:'ESPEN' },
        { id:'age_elderly_threshold',     category:'risk_scoring', name:'age_elderly_threshold',     description:'Age at or above this value triggers moderate risk classification',                               value:'70',   unit:'years',        source:'ESPEN Geriatric 2018' },
        { id:'risk_score_moderate',       category:'risk_scoring', name:'risk_score_moderate',       description:'Risk score threshold for Moderate nutrition risk classification',                                 value:'2',    unit:'score',        source:'Clinical' },
        { id:'risk_score_high',           category:'risk_scoring', name:'risk_score_high',           description:'Risk score threshold for High nutrition risk classification',                                    value:'4',    unit:'score',        source:'Clinical' },
        // ── Sarcopenia Thresholds ─────────────────────────────────────────────
        { id:'smi_l3_male',               category:'sarcopenia',   name:'smi_l3_male',               description:'L3-SMI sarcopenia threshold for males (Janssen/Martin CT method)',                              value:'55',   unit:'cm²/m²',       source:'Janssen 2004 / Martin 2013' },
        { id:'smi_l3_female',             category:'sarcopenia',   name:'smi_l3_female',             description:'L3-SMI sarcopenia threshold for females (Janssen/Martin CT method)',                            value:'38.5', unit:'cm²/m²',       source:'Janssen 2004 / Martin 2013' },
        { id:'asmi_male',                 category:'sarcopenia',   name:'asmi_male',                 description:'Appendicular SMI sarcopenia threshold for males (EWGSOP2 DXA/BIA method)',                      value:'7.0',  unit:'kg/m²',        source:'EWGSOP2 2019' },
        { id:'asmi_female',               category:'sarcopenia',   name:'asmi_female',               description:'Appendicular SMI sarcopenia threshold for females (EWGSOP2 DXA/BIA method)',                    value:'5.7',  unit:'kg/m²',        source:'EWGSOP2 2019' },
        { id:'grip_male',                 category:'sarcopenia',   name:'grip_male',                 description:'Hand grip strength sarcopenia threshold for males',                                              value:'26',   unit:'kg',           source:'EWGSOP2 2019' },
        { id:'grip_female',               category:'sarcopenia',   name:'grip_female',               description:'Hand grip strength sarcopenia threshold for females',                                            value:'18',   unit:'kg',           source:'EWGSOP2 2019' },
        // ── Safety Lab Thresholds ─────────────────────────────────────────────
        { id:'creatinine_renal_danger',   category:'safety_labs',  name:'creatinine_renal_danger',   description:'Creatinine above this value triggers KDIGO renal protocol (protein cap to 0.8g/kg)',            value:'1.3',  unit:'mg/dL',        source:'KDIGO 2012' },
        { id:'creatinine_cisplatin_warn', category:'safety_labs',  name:'creatinine_cisplatin_warn', description:'Creatinine at this level on cisplatin triggers nephrotoxicity warning',                         value:'1.2',  unit:'mg/dL',        source:'Clinical' },
        { id:'creatinine_low',            category:'safety_labs',  name:'creatinine_low',            description:'Creatinine below this value flags possible muscle wasting',                                      value:'0.6',  unit:'mg/dL',        source:'Clinical' },
        { id:'blood_sugar_danger',        category:'safety_labs',  name:'blood_sugar_danger',        description:'Blood glucose above this value triggers diabetic danger protocol',                                value:'180',  unit:'mg/dL',        source:'ADA' },
        { id:'blood_sugar_diabetic',      category:'safety_labs',  name:'blood_sugar_diabetic',      description:'Blood glucose above this value in a known diabetic triggers metabolic alert',                    value:'140',  unit:'mg/dL',        source:'ADA' },
        { id:'sodium_danger',             category:'safety_labs',  name:'sodium_danger',             description:'Sodium below this value triggers HIGH hyponatremia alert',                                       value:'130',  unit:'mmol/L',       source:'Clinical' },
        { id:'sodium_warning',            category:'safety_labs',  name:'sodium_warning',            description:'Sodium below this value triggers mild hyponatremia warning',                                     value:'135',  unit:'mmol/L',       source:'Clinical' },
        { id:'potassium_high',            category:'safety_labs',  name:'potassium_high',            description:'Potassium above this value triggers hyperkalemia protocol',                                      value:'5.0',  unit:'mmol/L',       source:'Clinical' },
        { id:'potassium_danger',          category:'safety_labs',  name:'potassium_danger',          description:'Potassium above this value is a danger-level hyperkalemia',                                      value:'5.5',  unit:'mmol/L',       source:'Clinical' },
        { id:'hemoglobin_anemia',         category:'safety_labs',  name:'hemoglobin_anemia',         description:'Hemoglobin below this value triggers anemia protocol (iron + B12)',                              value:'10',   unit:'g/dL',         source:'WHO' },
        { id:'hemoglobin_low',            category:'safety_labs',  name:'hemoglobin_low',            description:'Hemoglobin below this value adds +1 to nutrition risk score',                                   value:'12',   unit:'g/dL',         source:'WHO' },
        { id:'vitd_deficiency',           category:'safety_labs',  name:'vitd_deficiency',           description:'Vitamin D below this value triggers deficiency correction (4000 IU/day)',                        value:'20',   unit:'ng/mL',        source:'Endocrine Society' },
        { id:'vitd_insufficient',         category:'safety_labs',  name:'vitd_insufficient',         description:'Vitamin D below this value is classified as insufficient',                                       value:'30',   unit:'ng/mL',        source:'Endocrine Society' },
        { id:'magnesium_low',             category:'safety_labs',  name:'magnesium_low',             description:'Magnesium below this value triggers correction protocol (200–400mg Mg)',                         value:'1.7',  unit:'mg/dL',        source:'Clinical' },
        { id:'tsh_high',                  category:'safety_labs',  name:'tsh_high',                  description:'TSH above this value triggers metabolic rate flag',                                              value:'5.0',  unit:'mU/L',         source:'Clinical' },
        { id:'prealbumin_low',            category:'safety_labs',  name:'prealbumin_low',            description:'Prealbumin below this value used as a compound malnutrition factor',                             value:'18',   unit:'mg/dL',        source:'Clinical' },
        { id:'urea_high',                 category:'safety_labs',  name:'urea_high',                 description:'Urea at or above this value contributes to renal issue flag (alongside creatinine)',             value:'45',   unit:'mg/dL',        source:'Clinical' },
        { id:'wbc_neutropenia',           category:'safety_labs',  name:'wbc_neutropenia',           description:'WBC below this value triggers neutropenia food safety protocol (no live cultures)',              value:'3500', unit:'/µL',          source:'ESMO' },
        { id:'wbc_severe_neutropenia',    category:'safety_labs',  name:'wbc_severe_neutropenia',    description:'WBC below this value triggers severe neutropenia danger protocol (G-CSF assessment)',            value:'2000', unit:'/µL',          source:'ESMO' },
        { id:'alt_liver_threshold',       category:'safety_labs',  name:'alt_liver_threshold',       description:'ALT above this value signals liver compromise (+2 risk score)',                                  value:'50',   unit:'IU/L',         source:'Clinical' },
        { id:'ast_liver_threshold',       category:'safety_labs',  name:'ast_liver_threshold',       description:'AST above this value signals liver compromise (+2 risk score)',                                  value:'50',   unit:'IU/L',         source:'Clinical' },
        { id:'bilirubin_liver_threshold', category:'safety_labs',  name:'bilirubin_liver_threshold', description:'Bilirubin above this value signals liver compromise (+2 risk score)',                            value:'1.2',  unit:'mg/dL',        source:'Clinical' },
        // ── Macro Distribution ────────────────────────────────────────────────
        { id:'carb_ratio_standard',       category:'macros',       name:'carb_ratio_standard',       description:'Carbohydrate share of non-protein calories — standard patients',                                 value:'0.45', unit:'fraction',     source:'Clinical' },
        { id:'carb_ratio_diabetic',       category:'macros',       name:'carb_ratio_diabetic',       description:'Carbohydrate share of non-protein calories — diabetic or inflamed (CRP >5)',                    value:'0.35', unit:'fraction',     source:'Clinical' },
        // ── Intake / Escalation ───────────────────────────────────────────────
        { id:'intake_mandatory_en',       category:'escalation',   name:'intake_mandatory_en',       description:'Oral intake below this value triggers enteral tube escalation and full calorie/protein replacement prescription',  value:'50',   unit:'% oral intake', source:'ESPEN' },
        // ── Fluid Targets ─────────────────────────────────────────────────────
        { id:'fluid_min_per_kg',          category:'fluid',        name:'fluid_min_per_kg',          description:'Minimum daily fluid target',                                                                     value:'30',   unit:'ml/kg',        source:'ESPEN' },
        { id:'fluid_max_per_kg',          category:'fluid',        name:'fluid_max_per_kg',          description:'Maximum daily fluid target',                                                                     value:'35',   unit:'ml/kg',        source:'ESPEN' },

        // ── FSSAI/ICMR-NIN 2020 RDA — Gender pairs (same value for both) ───────
        { id:'micro_folate_maintenance_male',   category:'micronutrients', name:'micro_folate_maintenance_male',   description:'Folate maintenance — FSSAI/ICMR-NIN 2020 RDA for male',   value:'400', unit:'mcg/day', source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_folate_maintenance_female', category:'micronutrients', name:'micro_folate_maintenance_female', description:'Folate maintenance — FSSAI/ICMR-NIN 2020 RDA for female', value:'400', unit:'mcg/day', source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_vite_dose_male',            category:'micronutrients', name:'micro_vite_dose_male',            description:'Vitamin E maintenance — FSSAI/ICMR-NIN 2020 RDA for male',   value:'15',  unit:'mg/day',  source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_vite_dose_female',          category:'micronutrients', name:'micro_vite_dose_female',          description:'Vitamin E maintenance — FSSAI/ICMR-NIN 2020 RDA for female', value:'12',  unit:'mg/day',  source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_vitb12_maintenance_male',   category:'micronutrients', name:'micro_vitb12_maintenance_male',   description:'Vitamin B12 maintenance — FSSAI/ICMR-NIN 2020 RDA for male',   value:'500', unit:'mcg/day', source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_vitb12_maintenance_female', category:'micronutrients', name:'micro_vitb12_maintenance_female', description:'Vitamin B12 maintenance — FSSAI/ICMR-NIN 2020 RDA for female', value:'500', unit:'mcg/day', source:'FSSAI/ICMR-NIN 2020' },

        // ── FSSAI/ICMR-NIN 2020 RDA — Gender-specific pairs ──────────────────
        { id:'micro_zinc_maintenance_male',   category:'micronutrients', name:'micro_zinc_maintenance_male',   description:'Zinc maintenance — FSSAI/ICMR-NIN 2020 RDA for male',                                        value:'12',   unit:'mg/day',        source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_zinc_maintenance_female', category:'micronutrients', name:'micro_zinc_maintenance_female', description:'Zinc maintenance — FSSAI/ICMR-NIN 2020 RDA for female',                                      value:'10',   unit:'mg/day',        source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_magnesium_maintenance_male',  category:'micronutrients', name:'micro_magnesium_maintenance_male',  description:'Magnesium maintenance — FSSAI/ICMR-NIN 2020 RDA for male',                           value:'340',  unit:'mg/day',        source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_magnesium_maintenance_female',category:'micronutrients', name:'micro_magnesium_maintenance_female',description:'Magnesium maintenance — FSSAI/ICMR-NIN 2020 RDA for female',                         value:'310',  unit:'mg/day',        source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_iron_rda_male',           category:'micronutrients', name:'micro_iron_rda_male',           description:'Iron RDA for male — FSSAI/ICMR-NIN 2020',                                                    value:'17',   unit:'mg/day',        source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_iron_rda_female',         category:'micronutrients', name:'micro_iron_rda_female',         description:'Iron RDA for female — FSSAI/ICMR-NIN 2020',                                                  value:'21',   unit:'mg/day',        source:'FSSAI/ICMR-NIN 2020' },

        // ── Clinical Protocols — Folate ───────────────────────────────────────
        { id:'micro_folate_protocol',         category:'clinical_protocols', name:'micro_folate_protocol',         description:'Folate mandatory dose for antifolate regimens (Pemetrexed/Methotrexate)',                  value:'5',    unit:'mg/day',        source:'ESPEN / NCCN' },
        { id:'micro_folate_correction',       category:'clinical_protocols', name:'micro_folate_correction',       description:'Folate correction dose for lab-confirmed deficiency or anaemia',                          value:'5',    unit:'mg/day',        source:'Clinical' },
        { id:'micro_folate_lab_threshold',    category:'clinical_protocols', name:'micro_folate_lab_threshold',    description:'Serum folate below this value triggers deficiency correction',                            value:'3',    unit:'ng/mL',         source:'Clinical' },

        // ── Clinical Protocols — Omega-3 / EPA ───────────────────────────────
        { id:'micro_omega3_standard',         category:'clinical_protocols', name:'micro_omega3_standard',         description:'Omega-3 standard oncology dose (no high-risk indication)',                                value:'2',    unit:'g/day',         source:'ESPEN Oncology 2021' },
        { id:'micro_omega3_high',             category:'clinical_protocols', name:'micro_omega3_high',             description:'Omega-3 high dose (cachexia, CRP >5, pancreatic/biliary cancer)',                        value:'3',    unit:'g/day',         source:'ESPEN Oncology 2021' },
        { id:'micro_epa_low',                 category:'clinical_protocols', name:'micro_epa_low',                 description:'EPA dose for cachexia / tumor burden (moderate indication)',                              value:'2.2',  unit:'g EPA/day',     source:'ESPEN Oncology 2021' },
        { id:'micro_epa_high',                category:'clinical_protocols', name:'micro_epa_high',                description:'EPA dose for advanced metastatic / pancreatic / biliary cancer',                         value:'3.0',  unit:'g EPA/day',     source:'ESPEN Oncology 2021' },

        // ── Clinical Protocols — Leucine / Glutamine / BCAA ──────────────────
        { id:'micro_leucine_standard',        category:'clinical_protocols', name:'micro_leucine_standard',        description:'Leucine standard dose for muscle protein synthesis support',                              value:'3',    unit:'g/day',         source:'ESPEN / Leucine review' },
        { id:'micro_leucine_high',            category:'clinical_protocols', name:'micro_leucine_high',            description:'Leucine high dose — sarcopenia, high tumor burden, or ECOG ≥ 2',                        value:'5',    unit:'g/day',         source:'ESPEN / Leucine review' },
        { id:'micro_glutamine_daily',         category:'clinical_protocols', name:'micro_glutamine_daily',         description:'Glutamine total daily dose — mucosal protection',                                        value:'16',   unit:'g/day',         source:'ESPEN Oncology 2021' },
        { id:'micro_bcaa_hepatic',            category:'clinical_protocols', name:'micro_bcaa_hepatic',            description:'BCAA dose for hepatic protection (elevated ALT/AST/bilirubin)',                          value:'20',   unit:'g/day',         source:'ESPEN Liver 2019' },
        { id:'micro_bcaa_sarcopenia',         category:'clinical_protocols', name:'micro_bcaa_sarcopenia',         description:'BCAA dose for sarcopenia muscle preservation',                                           value:'10',   unit:'g/day',         source:'ESPEN Oncology 2021' },

        // ── Clinical Protocols — Iron ─────────────────────────────────────────
        { id:'micro_iron_correction',         category:'clinical_protocols', name:'micro_iron_correction',         description:'Elemental iron correction dose for anaemia (Hb < threshold)',                             value:'100',  unit:'mg/day',        source:'WHO / Clinical' },

        // ── Clinical Protocols — Selenium ─────────────────────────────────────
        { id:'micro_selenium_rda_male',       category:'micronutrients',     name:'micro_selenium_rda_male',       description:'Selenium RDA for male — ICMR-NIN 2020',                                                       value:'40',   unit:'mcg/day',       source:'ICMR-NIN 2020' },
        { id:'micro_selenium_rda_female',     category:'micronutrients',     name:'micro_selenium_rda_female',     description:'Selenium RDA for female — ICMR-NIN 2020',                                                     value:'40',   unit:'mcg/day',       source:'ICMR-NIN 2020' },
        { id:'micro_selenium_pharma_max',     category:'clinical_protocols', name:'micro_selenium_pharma_max',     description:'Selenium maximum pharmacological dose (requires oncologist approval)',                     value:'200',  unit:'mcg/day',       source:'Clinical' },

        // ── Clinical Protocols — Chromium / ALA ──────────────────────────────
        { id:'micro_chromium_rda_male',       category:'micronutrients',     name:'micro_chromium_rda_male',       description:'Chromium RDA for male — ICMR-NIN 2020',                                               value:'33',   unit:'mcg/day',       source:'ICMR-NIN 2020' },
        { id:'micro_chromium_rda_female',     category:'micronutrients',     name:'micro_chromium_rda_female',     description:'Chromium RDA for female — ICMR-NIN 2020',                                             value:'25',   unit:'mcg/day',       source:'ICMR-NIN 2020' },
        { id:'micro_ala_low',                 category:'clinical_protocols', name:'micro_ala_low',                 description:'Alpha-lipoic acid dose for peripheral neuropathy (taxane protocol)',                     value:'300',  unit:'mg/day',        source:'Clinical' },
        { id:'micro_ala_high',                category:'clinical_protocols', name:'micro_ala_high',                description:'Alpha-lipoic acid dose for diabetic glycaemic neuropathy support',                       value:'600',  unit:'mg/day',        source:'Clinical' },

        // ── Clinical Protocols — Vitamin B12 ─────────────────────────────────
        { id:'micro_vitb12_protocol',         category:'clinical_protocols', name:'micro_vitb12_protocol',         description:'Vitamin B12 mandatory dose for Pemetrexed/antifolate protocol',                          value:'1000', unit:'mcg/day',       source:'ESPEN / NCCN' },
        { id:'micro_vitb12_deficiency',       category:'clinical_protocols', name:'micro_vitb12_deficiency',       description:'Vitamin B12 correction dose for confirmed deficiency (serum B12 < 200 pg/mL)',           value:'1000', unit:'mcg/day',       source:'Clinical' },
        { id:'micro_vitb12_insufficiency',    category:'clinical_protocols', name:'micro_vitb12_insufficiency',    description:'Vitamin B12 correction dose for insufficiency (serum B12 200–400 pg/mL)',                value:'500',  unit:'mcg/day',       source:'Clinical' },
        { id:'micro_vitb12_deficiency_threshold',  category:'clinical_protocols', name:'micro_vitb12_deficiency_threshold',  description:'Serum B12 below this value = deficiency',                                    value:'200',  unit:'pg/mL',         source:'Clinical' },
        { id:'micro_vitb12_insufficiency_threshold',category:'clinical_protocols',name:'micro_vitb12_insufficiency_threshold',description:'Serum B12 below this value = insufficiency',                                value:'400',  unit:'pg/mL',         source:'Clinical' },

        // ── FSSAI/ICMR-NIN 2020 RDA Reference — Vitamin D ────────────────────
        { id:'micro_vita_rda_male',               category:'micronutrients', name:'micro_vita_rda_male',               description:'Vitamin A RDA for male — ICMR-NIN 2020',                                                                     value:'900',  unit:'mcg RAE/day', source:'ICMR-NIN 2020' },
        { id:'micro_vita_rda_female',             category:'micronutrients', name:'micro_vita_rda_female',             description:'Vitamin A RDA for female — ICMR-NIN 2020',                                                                   value:'700',  unit:'mcg RAE/day', source:'ICMR-NIN 2020' },
        { id:'micro_vitd_rda_male',               category:'micronutrients', name:'micro_vitd_rda_male',               description:'Vitamin D RDA for male — FSSAI/ICMR-NIN 2020',                                                               value:'600',  unit:'IU/day',   source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_vitd_rda_female',             category:'micronutrients', name:'micro_vitd_rda_female',             description:'Vitamin D RDA for female — FSSAI/ICMR-NIN 2020',                                                             value:'600',  unit:'IU/day',   source:'FSSAI/ICMR-NIN 2020' },

        // ── FSSAI/ICMR-NIN 2020 RDA Reference — Vitamin C ────────────────────
        { id:'micro_vitc_rda_male',   category:'micronutrients', name:'micro_vitc_rda_male',   description:'Vitamin C RDA for male — ICMR-NIN',   value:'80', unit:'mg/day', source:'ICMR-NIN' },
        { id:'micro_vitc_rda_female', category:'micronutrients', name:'micro_vitc_rda_female', description:'Vitamin C RDA for female — ICMR-NIN', value:'65', unit:'mg/day', source:'ICMR-NIN' },

        // ── FSSAI/ICMR-NIN 2020 RDA Reference — Calcium ─────────────────────
        { id:'micro_calcium_rda_male',            category:'micronutrients', name:'micro_calcium_rda_male',            description:'Calcium RDA for male — FSSAI/ICMR-NIN 2020',                                                                 value:'600',  unit:'mg/day',   source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_calcium_rda_female',          category:'micronutrients', name:'micro_calcium_rda_female',          description:'Calcium RDA for female — FSSAI/ICMR-NIN 2020',                                                               value:'600',  unit:'mg/day',   source:'FSSAI/ICMR-NIN 2020' },

        // ── FSSAI/ICMR-NIN 2020 RDA Reference — Thiamine (B1) ───────────────
        { id:'micro_thiamine_rda_male',           category:'micronutrients', name:'micro_thiamine_rda_male',           description:'Thiamine (B1) RDA for male — FSSAI/ICMR-NIN 2020',                                                           value:'1.4',  unit:'mg/day',   source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_thiamine_rda_female',         category:'micronutrients', name:'micro_thiamine_rda_female',         description:'Thiamine (B1) RDA for female — FSSAI/ICMR-NIN 2020',                                                         value:'1.1',  unit:'mg/day',   source:'FSSAI/ICMR-NIN 2020' },

        // ── FSSAI/ICMR-NIN 2020 RDA Reference — Riboflavin (B2) ─────────────
        { id:'micro_riboflavin_rda_male',         category:'micronutrients', name:'micro_riboflavin_rda_male',         description:'Riboflavin (B2) RDA for male — FSSAI/ICMR-NIN 2020',                                                         value:'1.9',  unit:'mg/day',   source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_riboflavin_rda_female',       category:'micronutrients', name:'micro_riboflavin_rda_female',       description:'Riboflavin (B2) RDA for female — FSSAI/ICMR-NIN 2020',                                                       value:'1.5',  unit:'mg/day',   source:'FSSAI/ICMR-NIN 2020' },

        // ── FSSAI/ICMR-NIN 2020 RDA Reference — Niacin (B3) ─────────────────
        { id:'micro_niacin_rda_male',             category:'micronutrients', name:'micro_niacin_rda_male',             description:'Niacin (B3) RDA for male — FSSAI/ICMR-NIN 2020',                                                             value:'16',   unit:'mg NE/day',source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_niacin_rda_female',           category:'micronutrients', name:'micro_niacin_rda_female',           description:'Niacin (B3) RDA for female — FSSAI/ICMR-NIN 2020',                                                           value:'12',   unit:'mg NE/day',source:'FSSAI/ICMR-NIN 2020' },

        // ── FSSAI/ICMR-NIN 2020 RDA Reference — Vitamin B6 ──────────────────
        { id:'micro_vitb6_rda_male',              category:'micronutrients', name:'micro_vitb6_rda_male',              description:'Vitamin B6 RDA for male — FSSAI/ICMR-NIN 2020',                                                              value:'1.6',  unit:'mg/day',   source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_vitb6_rda_female',            category:'micronutrients', name:'micro_vitb6_rda_female',            description:'Vitamin B6 RDA for female — FSSAI/ICMR-NIN 2020',                                                            value:'1.6',  unit:'mg/day',   source:'FSSAI/ICMR-NIN 2020' },

        // ── FSSAI/ICMR-NIN 2020 RDA Reference — Iodine ──────────────────────
        { id:'micro_iodine_rda_male',             category:'micronutrients', name:'micro_iodine_rda_male',             description:'Iodine RDA for male — FSSAI/ICMR-NIN 2020',                                                                  value:'150',  unit:'mcg/day',  source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_iodine_rda_female',           category:'micronutrients', name:'micro_iodine_rda_female',           description:'Iodine RDA for female — FSSAI/ICMR-NIN 2020',                                                                value:'150',  unit:'mcg/day',  source:'FSSAI/ICMR-NIN 2020' },

        // ── FSSAI/ICMR-NIN 2020 RDA Reference — Dietary Fiber ───────────────
        { id:'micro_fiber_rda_male',              category:'micronutrients', name:'micro_fiber_rda_male',              description:'Dietary fiber adequate intake for male — FSSAI/ICMR-NIN 2020',                                               value:'30',   unit:'g/day',    source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_fiber_rda_female',            category:'micronutrients', name:'micro_fiber_rda_female',            description:'Dietary fiber adequate intake for female — FSSAI/ICMR-NIN 2020',                                             value:'25',   unit:'g/day',    source:'FSSAI/ICMR-NIN 2020' },

        // ── FSSAI/ICMR-NIN 2020 RDA Reference — Vitamin K ───────────────────
        { id:'micro_vitk_rda_male',               category:'micronutrients', name:'micro_vitk_rda_male',               description:'Vitamin K RDA for male — FSSAI/ICMR-NIN 2020',                                                               value:'55',   unit:'mcg/day',  source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_vitk_rda_female',             category:'micronutrients', name:'micro_vitk_rda_female',             description:'Vitamin K RDA for female — FSSAI/ICMR-NIN 2020',                                                             value:'55',   unit:'mcg/day',  source:'FSSAI/ICMR-NIN 2020' },

        // ── FSSAI/ICMR-NIN 2020 AI Reference — Sodium ───────────────────────
        { id:'micro_sodium_ai_male',              category:'micronutrients', name:'micro_sodium_ai_male',              description:'Sodium adequate intake (AI) for male — FSSAI/WHO 2020 upper limit',                                          value:'2000', unit:'mg/day',   source:'FSSAI/WHO 2020' },
        { id:'micro_sodium_ai_female',            category:'micronutrients', name:'micro_sodium_ai_female',            description:'Sodium adequate intake (AI) for female — FSSAI/WHO 2020 upper limit',                                        value:'2000', unit:'mg/day',   source:'FSSAI/WHO 2020' },

        // ── FSSAI/ICMR-NIN 2020 AI Reference — Potassium ────────────────────
        { id:'micro_potassium_ai_male',             category:'micronutrients', name:'micro_potassium_ai_male',             description:'Potassium adequate intake (AI) for male — FSSAI/ICMR-NIN 2020',                    value:'3500', unit:'mg/day',   source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_potassium_ai_female',           category:'micronutrients', name:'micro_potassium_ai_female',           description:'Potassium adequate intake (AI) for female — FSSAI/ICMR-NIN 2020',                  value:'3500', unit:'mg/day',   source:'FSSAI/ICMR-NIN 2020' },

        // ── FSSAI/ICMR-NIN 2020 RDA Reference — Pantothenic Acid (B5) ────────
        { id:'micro_pantothenic_rda_male',          category:'micronutrients', name:'micro_pantothenic_rda_male',          description:'Pantothenic acid (B5) AI for male — FSSAI/ICMR-NIN 2020',                         value:'5',    unit:'mg/day',   source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_pantothenic_rda_female',        category:'micronutrients', name:'micro_pantothenic_rda_female',        description:'Pantothenic acid (B5) AI for female — FSSAI/ICMR-NIN 2020',                       value:'5',    unit:'mg/day',   source:'FSSAI/ICMR-NIN 2020' },

        // ── FSSAI/ICMR-NIN 2020 RDA Reference — Phosphorus ──────────────────
        { id:'micro_phosphorus_rda_male',           category:'micronutrients', name:'micro_phosphorus_rda_male',           description:'Phosphorus RDA for male — FSSAI/ICMR-NIN 2020',                                   value:'600',  unit:'mg/day',   source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_phosphorus_rda_female',         category:'micronutrients', name:'micro_phosphorus_rda_female',         description:'Phosphorus RDA for female — FSSAI/ICMR-NIN 2020',                                 value:'600',  unit:'mg/day',   source:'FSSAI/ICMR-NIN 2020' },

        // ── FSSAI/ICMR-NIN 2020 RDA Reference — Copper ───────────────────────
        { id:'micro_copper_rda_male',               category:'micronutrients', name:'micro_copper_rda_male',               description:'Copper RDA for male — FSSAI/ICMR-NIN 2020',                                       value:'900',  unit:'mcg/day',  source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_copper_rda_female',             category:'micronutrients', name:'micro_copper_rda_female',             description:'Copper RDA for female — FSSAI/ICMR-NIN 2020',                                     value:'900',  unit:'mcg/day',  source:'FSSAI/ICMR-NIN 2020' },

        // ── FSSAI/ICMR-NIN 2020 AI Reference — Chloride ──────────────────────
        { id:'micro_chloride_ai_male',              category:'micronutrients', name:'micro_chloride_ai_male',              description:'Chloride AI for male — FSSAI/WHO 2020 (follows sodium chloride intake)',           value:'2300', unit:'mg/day',   source:'FSSAI/WHO 2020' },
        { id:'micro_chloride_ai_female',            category:'micronutrients', name:'micro_chloride_ai_female',            description:'Chloride AI for female — FSSAI/WHO 2020 (follows sodium chloride intake)',         value:'2300', unit:'mg/day',   source:'FSSAI/WHO 2020' },

        // ── FSSAI/ICMR-NIN 2020 RDA Reference — Molybdenum ──────────────────
        { id:'micro_molybdenum_rda_male',           category:'micronutrients', name:'micro_molybdenum_rda_male',           description:'Molybdenum RDA for male — FSSAI/ICMR-NIN 2020',                                   value:'45',   unit:'mcg/day',  source:'FSSAI/ICMR-NIN 2020' },
        { id:'micro_molybdenum_rda_female',         category:'micronutrients', name:'micro_molybdenum_rda_female',         description:'Molybdenum RDA for female — FSSAI/ICMR-NIN 2020',                                 value:'45',   unit:'mcg/day',  source:'FSSAI/ICMR-NIN 2020' },

        // ── Serving Frequency ─────────────────────────────────────────────────
        { id:'servings_base',             category:'servings',     name:'servings_base',             description:'Standard servings per day (baseline)',                                                           value:'3',    unit:'servings',     source:'Clinical' },
        { id:'servings_high_threshold',   category:'servings',     name:'servings_high_threshold',   description:'Daily calorie level above which servings increase to 4 (to reduce per-serving volume)',         value:'1800', unit:'kcal',         source:'Clinical' },
        { id:'servings_high_count',       category:'servings',     name:'servings_high_count',       description:'Servings per day when calories ≥1800 or appetite loss/nausea present',                         value:'4',    unit:'servings',     source:'Clinical' },
        { id:'servings_very_high_threshold',category:'servings',   name:'servings_very_high_threshold','description':'Daily calorie level above which servings increase to 5',                                     value:'2400', unit:'kcal',         source:'Clinical' },
        // ── Pricing ───────────────────────────────────────────────────────────
        { id:'review_interval_days',      category:'monitoring',   name:'review_interval_days',      description:'Days between weekly assessments: first one is due this many days after the product is dispatched, then this many days after each entry', value:'5', unit:'days', source:'Clinical' },
        { id:'platform_markup_pct',       category:'pricing',      name:'platform_markup_pct',       description:'Default markup % suggested to the admin when a store price arrives (the admin can change it per product)', value:'40', unit:'%', source:'Commercial' },
        { id:'servings_very_high_count',  category:'servings',     name:'servings_very_high_count',  description:'Servings per day when calories ≥2400',                                                          value:'5',    unit:'servings',     source:'Clinical' },
      ];
      for (const f of formulas) {
        await pool.query(
          `INSERT INTO engine_formulas (id, category, name, description, value, unit, source, editable)
           VALUES ($1,$2,$3,$4,$5,$6,$7,true) ON CONFLICT (id) DO NOTHING`,
          [f.id, f.category, f.name, f.description, f.value, f.unit, f.source]
        );
      }
      console.log(`Engine formulas seeded: ${formulas.length} constants.`);
      await pool.query("UPDATE engine_formulas SET category='monitoring' WHERE id='review_interval_days' AND category<>'monitoring'").catch(() => {});

      // ── Force-correct WBC thresholds to /µL units (fix for ON CONFLICT DO NOTHING leaving stale values) ──
      await pool.query(`UPDATE engine_formulas SET value = '3500', unit = '/µL' WHERE id = 'wbc_neutropenia'`);
      await pool.query(`UPDATE engine_formulas SET value = '2000', unit = '/µL' WHERE id = 'wbc_severe_neutropenia'`);
      await pool.query(`UPDATE engine_formulas SET value = '45', unit = 'mg/dL' WHERE id = 'urea_high'`);

      // ── One-time migrations: remove deprecated / orphaned parameters ────────
      await pool.query(`DELETE FROM engine_formulas WHERE id IN (
        'micro_vitc_rda',
        'micro_vitb12_deficiency','micro_vitb12_deficiency_threshold',
        'micro_vitb12_insufficiency','micro_vitb12_insufficiency_threshold',
        'micro_zinc_maintenance','micro_magnesium_maintenance',
        'micro_zinc_correction_min','micro_zinc_correction_max',
        'micro_omega3_high_min','micro_omega3_high_max',
        'micro_calcium_myeloma_min','micro_calcium_myeloma_max',
        'micro_vitb12_maintenance_low','micro_vitb12_maintenance_high',
        'micro_selenium_physio_min','micro_selenium_physio_max',
        'micro_folate_maintenance','micro_vite_dose','micro_vitb12_maintenance',
        'micro_vitd_deficiency_dose','micro_vitd_insufficient_dose','micro_vitd_maintenance','micro_vitd_renal_cap',
        'micro_vitc_high','micro_vitc_standard','micro_vitc_chemo_cap',
        'micro_zinc_correction','micro_zinc_lab_threshold',
        'micro_magnesium_correction',
        'micro_calcium_myeloma','micro_calcium_bone_mets','micro_calcium_steroid_high','micro_calcium_steroid'
      ) OR category = 'refeeding'`);

      // Move clinical/correction params out of micronutrients → clinical_protocols
      await pool.query(`UPDATE engine_formulas SET category = 'clinical_protocols' WHERE id IN (
        'micro_vitd_deficiency_dose','micro_vitd_insufficient_dose','micro_vitd_maintenance','micro_vitd_renal_cap',
        'micro_vitc_high','micro_vitc_standard','micro_vitc_chemo_cap',
        'micro_zinc_correction','micro_zinc_lab_threshold',
        'micro_folate_protocol','micro_folate_correction','micro_folate_lab_threshold',
        'micro_magnesium_correction',
        'micro_omega3_standard','micro_omega3_high','micro_epa_low','micro_epa_high',
        'micro_leucine_standard','micro_leucine_high','micro_glutamine_daily',
        'micro_bcaa_hepatic','micro_bcaa_sarcopenia',
        'micro_iron_correction',
        'micro_selenium_physio','micro_chromium_diabetic',
        'micro_chromium_diabetic','micro_ala_low','micro_ala_high',
        'micro_vitb12_protocol','micro_vitb12_deficiency','micro_vitb12_insufficiency',
        'micro_vitb12_deficiency_threshold','micro_vitb12_insufficiency_threshold',
        'micro_calcium_myeloma','micro_calcium_bone_mets','micro_calcium_steroid_high','micro_calcium_steroid'
      )`);

    }
    console.log('Rule Engine tables ready.');

  } catch (e) {
    console.error('Rule Engine table init error:', e.message);
  }
})();

// AI Corrections: Save (called automatically from patient profile when AI corrects)
app.post('/api/ai-corrections', authenticateToken, async (req, res) => {
  const { id, patientId, planId, patientName, cancer, regimen, changes, reason, patientContext } = req.body;
  try {
    await pool.query(
      `INSERT INTO ai_corrections (id, patient_id, plan_id, patient_name, cancer, regimen, changes, reason, patient_context)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       ON CONFLICT (id) DO NOTHING`,
      [
        id || `corr_${Date.now()}`,
        patientId, planId, patientName, cancer, regimen,
        JSON.stringify(changes || []),
        reason,
        JSON.stringify(patientContext || {})
      ]
    );
    res.status(201).json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// AI Corrections: Get All (admin)
app.get('/api/ai-corrections', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM ai_corrections ORDER BY created_at DESC');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// AI Corrections: Update status (dismiss/acknowledge)
app.put('/api/ai-corrections/:id', authenticateToken, async (req, res) => {
  const { status } = req.body;
  try {
    await pool.query('UPDATE ai_corrections SET status=$1 WHERE id=$2', [status, req.params.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Engine Rules: Get All
app.get('/api/engine-rules', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM engine_rules ORDER BY created_at DESC');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Engine Rules: Get Active only (used by engine at runtime)
app.get('/api/engine-rules/active', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM engine_rules WHERE status='active' ORDER BY created_at DESC");
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Engine Rules: Create (admin promotes a correction to a rule)
app.post('/api/engine-rules', authenticateToken, async (req, res) => {
  const { ruleName, conditionDescription, targetField, operator, value, reason, sourceCorrectionId } = req.body;
  try {
    const id = `rule_${Date.now()}`;
    const result = await pool.query(
      `INSERT INTO engine_rules (id, rule_name, condition_description, target_field, operator, value, reason, source_correction_id, confirmed_by, status, confirmed_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'active',NOW()) RETURNING *`,
      [id, ruleName, conditionDescription, targetField, operator, String(value), reason, sourceCorrectionId || null, req.user.id]
    );
    // Mark source correction as promoted
    if (sourceCorrectionId) {
      await pool.query("UPDATE ai_corrections SET status='promoted' WHERE id=$1", [sourceCorrectionId]);
    }
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Engine Rules: Update (confirm active / reject / edit)
app.put('/api/engine-rules/:id', authenticateToken, async (req, res) => {
  const { status, ruleName, conditionDescription, targetField, operator, value, reason } = req.body;
  try {
    await pool.query(
      `UPDATE engine_rules SET status=$1, rule_name=$2, condition_description=$3,
       target_field=$4, operator=$5, value=$6, reason=$7,
       confirmed_by=$8, confirmed_at=NOW() WHERE id=$9`,
      [status, ruleName, conditionDescription, targetField, operator, String(value), reason, req.user.id, req.params.id]
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Engine Rules: Delete
app.delete('/api/engine-rules/:id', authenticateToken, async (req, res) => {
  try {
    await pool.query('DELETE FROM engine_rules WHERE id=$1', [req.params.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Engine Formulas: Get All
app.get('/api/engine-formulas', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM engine_formulas ORDER BY category, id');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Engine Formulas: Update value (admin edits a constant)
app.put('/api/engine-formulas/:id', authenticateToken, async (req, res) => {
  const { value } = req.body;
  if (!value && value !== 0) return res.status(400).json({ error: 'value required' });
  // Commercial settings are admin-only (clinical constants keep their existing rule).
  if (/^platform_/.test(req.params.id)) {
    const role = req.user && req.user.role;
    if (role !== 'ADMIN' && role !== 'SUPER_ADMIN') return res.status(403).json({ error: 'Admin only' });
    const n = parseFloat(value);
    if (!(n >= 0 && n <= 500)) return res.status(400).json({ error: 'Markup must be a percentage between 0 and 500.' });
  }
  try {
    await pool.query(
      'UPDATE engine_formulas SET value=$1, updated_at=NOW() WHERE id=$2',
      [String(value), req.params.id]
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Clean URL routing — serve HTML files without .html extension
const cleanRoutes = {
  '/login':            'index.html',
  '/dashboard':        'doctor.html',
  '/patients/create':  'Patient-Create-STABLE-V3.html',
  '/patients/profile': 'Patient-Profile-STABLE-V3.html',
  '/store':            'store.html',
  '/store/job':        'store-patient.html',
  '/patient-view':     'patient-view.html',
  '/patient-qr':       'patient-qr.html',
  '/admin':            'admin.html',
  '/admin/stores':     'admin-stores.html',
  '/admin/users':      'admin-users.html',
  '/admin/mapping':    'admin-mapping.html',
  '/admin/tracking':   'admin-tracking.html',
  '/admin/trials':     'admin-trials.html',
  '/admin/trials/journey':  'admin-trial-journey.html',
  '/admin/trials/patient':  'admin-trial-patient.html',
  '/admin/trials/cohort': 'admin-trial-cohort.html',
  '/admin/trials/outcomes': 'admin-trial-outcomes.html',
  '/admin/trials/formula': 'admin-trial-formula.html',
  '/admin/trials/impact':  'admin-trial-impact.html',
  '/admin/trials/analytics': 'admin-trial-analytics.html',
  '/admin/trials/export': 'admin-trial-export.html',
  '/admin/reports':    'admin-reports.html',
  '/admin/rules':      'admin-rules.html',
  '/coordinator':      'coordinator.html',
};
const _noCacheHtml = (res) => {
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
};
Object.entries(cleanRoutes).forEach(([route, file]) => {
  app.get(route, (req, res) => { _noCacheHtml(res); res.sendFile(path.join(__dirname, '..', file)); });
});
// Root → login page
app.get('/', (req, res) => { _noCacheHtml(res); res.sendFile(path.join(__dirname, '..', 'index.html')); });

// Seed SUPER_ADMIN into DB on startup if not present
async function seedSuperAdmin() {
  try {
    // Remove old admin@onvilox.com if it exists
    await pool.query("DELETE FROM users WHERE email = $1 AND role = 'SUPER_ADMIN'", ['admin@onvilox.com']);

    // The password comes ONLY from the SUPER_ADMIN_PASSWORD environment
    // variable. It used to be hard-coded here and re-applied on every start,
    // which meant anyone who saw this file could sign in as super admin.
    const envPw = process.env.SUPER_ADMIN_PASSWORD;
    if (envPw && envPw.length >= 10) {
      const hash = await bcrypt.hash(envPw, 10);
      await pool.query(
        `INSERT INTO users (id, name, email, password_hash, role, created_at)
         VALUES ($1, $2, $3, $4, $5, NOW())
         ON CONFLICT (id) DO UPDATE SET email=$3, password_hash=$4, role=$5`,
        ['superadmin_001', 'System Admin', 'admin@gquence.in', hash, 'SUPER_ADMIN']
      );
      console.log('SUPER_ADMIN ensured: admin@gquence.in (password from SUPER_ADMIN_PASSWORD)');
    } else {
      // No env password: create the account only if it is missing, with a
      // random password nobody knows (set SUPER_ADMIN_PASSWORD to take it over).
      // An existing account's password is left exactly as it is.
      const hash = await bcrypt.hash(require('crypto').randomBytes(24).toString('hex'), 10);
      await pool.query(
        `INSERT INTO users (id, name, email, password_hash, role, created_at)
         VALUES ($1, $2, $3, $4, $5, NOW())
         ON CONFLICT (id) DO NOTHING`,
        ['superadmin_001', 'System Admin', 'admin@gquence.in', hash, 'SUPER_ADMIN']
      );
      console.warn('SUPER_ADMIN_PASSWORD is not set (or shorter than 10 characters) — super admin password left unchanged. '
                 + 'Set it in the environment to rotate the password.');
    }
  } catch(e) {
    console.warn('seedSuperAdmin error:', e.message);
  }
}

// Start Server
const PORT = process.env.PORT || 3000;
app.listen(PORT, async () => {
  console.log(`Server running on port ${PORT}`);
  await seedSuperAdmin();
});
